import 'package:flutter/material.dart';
import '../services/simple_auth_service.dart';
import 'meditation_timer_screen.dart';
import 'journal_screen.dart';
import 'auth_screen.dart';

class JournalTabContainer extends StatefulWidget {
  const JournalTabContainer({Key? key}) : super(key: key);

  @override
  State<JournalTabContainer> createState() => _JournalTabContainerState();
}

class _JournalTabContainerState extends State<JournalTabContainer>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final SimpleAuthService _authService = SimpleAuthService.instance;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        automaticallyImplyLeading: false,
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: theme.colorScheme.primary,
          indicatorWeight: 3,
          labelColor: isDark ? Colors.white : Colors.black87,
          unselectedLabelColor: (isDark ? Colors.white : Colors.black87).withOpacity(0.6),
          labelStyle: const TextStyle(
            fontWeight: FontWeight.w600,
            fontSize: 16,
          ),
          tabs: const [
            Tab(
              text: 'Practice',
              icon: Icon(Icons.self_improvement),
            ),
            Tab(
              text: 'Journal',
              icon: Icon(Icons.book),
            ),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          // Practice tab - Meditation Timer
          const MeditationTimerScreen(),

          // Journal tab - Check authentication
          StreamBuilder<bool>(
            stream: _authService.authStateChanges,
            builder: (context, snapshot) {
              final isAuthenticated = snapshot.data ?? false;

              if (!isAuthenticated) {
                // Show auth prompt for journal
                return _buildAuthPrompt(context);
              }

              return const JournalScreen();
            },
          ),
        ],
      ),
    );
  }

  Widget _buildAuthPrompt(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.lock_outline,
              size: 80,
              color: theme.colorScheme.primary.withOpacity(0.5),
            ),
            const SizedBox(height: 24),
            Text(
              'Sign in to access Journal',
              style: theme.textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.w600,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            Text(
              'Your journal entries are private and synced across devices',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: (isDark ? Colors.white : Colors.black87).withOpacity(0.7),
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),

            // Sign in button
            ElevatedButton.icon(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const AuthScreen(),
                    fullscreenDialog: true,
                  ),
                );
              },
              icon: const Icon(Icons.login),
              label: const Text('Sign In'),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
            ),

            const SizedBox(height: 16),

            // Continue as guest option
            TextButton(
              onPressed: () async {
                await _authService.signInAnonymously();
              },
              child: Text(
                'Continue as Guest',
                style: TextStyle(
                  color: theme.colorScheme.primary,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}