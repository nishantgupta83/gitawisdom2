// lib/screens/search_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/search_service.dart';
import '../models/search_result.dart';
import '../widgets/search_result_card.dart';
import '../widgets/search_suggestions.dart';
import '../screens/verse_list_view.dart';

class SearchScreen extends StatefulWidget {
  final String? initialQuery;

  const SearchScreen({super.key, this.initialQuery});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen>
    with TickerProviderStateMixin {
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _focusNode = FocusNode();
  
  late TabController _tabController;
  List<SearchType> _selectedTypes = [SearchType.verse, SearchType.chapter, SearchType.scenario];
  bool _showSuggestions = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    
    if (widget.initialQuery != null) {
      _searchController.text = widget.initialQuery!;
      _performSearch();
    }
    
    _focusNode.addListener(() {
      setState(() {
        _showSuggestions = _focusNode.hasFocus && _searchController.text.isEmpty;
      });
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    _focusNode.dispose();
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      body: Consumer<SearchService>(
        builder: (context, searchService, child) {
          return CustomScrollView(
            slivers: [
              _buildSearchAppBar(theme, searchService),
              if (_showSuggestions) ...[
                _buildSearchSuggestions(searchService, theme),
              ] else ...[
                if (searchService.lastQuery.isNotEmpty) ...[
                  _buildSearchTabs(theme, searchService),
                  _buildSearchResults(theme, searchService),
                ] else ...[
                  _buildRecentSearches(searchService, theme),
                ],
              ],
            ],
          );
        },
      ),
    );
  }

  Widget _buildSearchAppBar(ThemeData theme, SearchService searchService) {
    return SliverAppBar(
      expandedHeight: 120,
      floating: true,
      pinned: true,
      backgroundColor: theme.colorScheme.surface,
      elevation: 0,
      flexibleSpace: FlexibleSpaceBar(
        background: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                theme.colorScheme.primaryContainer.withOpacity(0.3),
                theme.colorScheme.surface,
              ],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
        ),
      ),
      title: _buildSearchBar(theme, searchService),
      actions: [
        if (searchService.lastQuery.isNotEmpty)
          IconButton(
            icon: const Icon(Icons.clear),
            onPressed: () {
              _searchController.clear();
              searchService.clearResults();
              setState(() => _showSuggestions = false);
            },
            tooltip: 'Clear search',
          ),
      ],
    );
  }

  Widget _buildSearchBar(ThemeData theme, SearchService searchService) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      child: TextField(
        controller: _searchController,
        focusNode: _focusNode,
        decoration: InputDecoration(
          hintText: 'Search verses, chapters, scenarios...',
          prefixIcon: searchService.isLoading
              ? const Padding(
                  padding: EdgeInsets.all(12),
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Icon(Icons.search),
          suffixIcon: _searchController.text.isNotEmpty
              ? IconButton(
                  icon: const Icon(Icons.clear),
                  onPressed: () {
                    _searchController.clear();
                    setState(() => _showSuggestions = _focusNode.hasFocus);
                  },
                )
              : null,
          filled: true,
          fillColor: theme.colorScheme.surfaceVariant.withOpacity(0.5),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(25),
            borderSide: BorderSide.none,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(25),
            borderSide: BorderSide(
              color: theme.colorScheme.primary,
              width: 2,
            ),
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        ),
        onChanged: (value) {
          setState(() {
            _showSuggestions = value.isEmpty && _focusNode.hasFocus;
          });
        },
        onSubmitted: (value) {
          if (value.trim().isNotEmpty) {
            _performSearch();
          }
        },
        textInputAction: TextInputAction.search,
      ),
    );
  }

  Widget _buildSearchSuggestions(SearchService searchService, ThemeData theme) {
    return SliverToBoxAdapter(
      child: SearchSuggestions(
        suggestions: searchService.searchSuggestions.take(20).toList(),
        recentSearches: searchService.recentSearches.take(10).toList(),
        onSuggestionTap: (suggestion) {
          _searchController.text = suggestion;
          _focusNode.unfocus();
          _performSearch();
        },
        onRecentSearchTap: (query) {
          _searchController.text = query;
          _focusNode.unfocus();
          _performSearch();
        },
        onClearRecentSearches: () {
          searchService.clearRecentSearches();
        },
      ),
    );
  }

  Widget _buildSearchTabs(ThemeData theme, SearchService searchService) {
    final results = searchService.currentResults;
    final verseCount = results.where((r) => r.resultType == SearchType.verse).length;
    final chapterCount = results.where((r) => r.resultType == SearchType.chapter).length;
    final scenarioCount = results.where((r) => r.resultType == SearchType.scenario).length;

    return SliverToBoxAdapter(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    'Found ${results.length} results for "${searchService.lastQuery}"',
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.filter_list),
                  onPressed: _showFilterDialog,
                  tooltip: 'Filter results',
                ),
              ],
            ),
            const SizedBox(height: 8),
            TabBar(
              controller: _tabController,
              labelColor: theme.colorScheme.primary,
              unselectedLabelColor: theme.colorScheme.onSurface.withOpacity(0.6),
              indicatorColor: theme.colorScheme.primary,
              isScrollable: true,
              tabs: [
                Tab(text: 'All (${results.length})'),
                Tab(text: 'Verses ($verseCount)'),
                Tab(text: 'Chapters ($chapterCount)'),
                Tab(text: 'Scenarios ($scenarioCount)'),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSearchResults(ThemeData theme, SearchService searchService) {
    return SliverFillRemaining(
      child: TabBarView(
        controller: _tabController,
        children: [
          _buildResultsList(searchService.currentResults, theme, searchService),
          _buildResultsList(searchService.getResultsByType(SearchType.verse), theme, searchService),
          _buildResultsList(searchService.getResultsByType(SearchType.chapter), theme, searchService),
          _buildResultsList(searchService.getResultsByType(SearchType.scenario), theme, searchService),
        ],
      ),
    );
  }

  Widget _buildResultsList(List<SearchResult> results, ThemeData theme, SearchService searchService) {
    if (searchService.isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (searchService.error != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.error_outline,
              size: 64,
              color: theme.colorScheme.error,
            ),
            const SizedBox(height: 16),
            Text(
              'Search Error',
              style: theme.textTheme.titleLarge,
            ),
            const SizedBox(height: 8),
            Text(
              searchService.error!,
              style: theme.textTheme.bodyMedium?.copyWith(
                color: theme.colorScheme.onSurface.withOpacity(0.7),
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _performSearch,
              child: const Text('Retry'),
            ),
          ],
        ),
      );
    }

    if (results.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.search_off,
              size: 64,
              color: theme.colorScheme.onSurface.withOpacity(0.4),
            ),
            const SizedBox(height: 16),
            Text(
              'No results found',
              style: theme.textTheme.titleLarge?.copyWith(
                color: theme.colorScheme.onSurface.withOpacity(0.7),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Try different keywords or check your spelling',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: theme.colorScheme.onSurface.withOpacity(0.5),
              ),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: results.length,
      itemBuilder: (context, index) {
        final result = results[index];
        return SearchResultCard(
          result: result,
          query: searchService.lastQuery,
          onTap: () => _onResultTap(result),
        );
      },
    );
  }

  Widget _buildRecentSearches(SearchService searchService, ThemeData theme) {
    if (searchService.recentSearches.isEmpty) {
      return SliverFillRemaining(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.search,
                size: 64,
                color: theme.colorScheme.primary.withOpacity(0.5),
              ),
              const SizedBox(height: 16),
              Text(
                'Search the Gita',
                style: theme.textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Find verses, chapters, and wisdom for any situation',
                style: theme.textTheme.bodyLarge?.copyWith(
                  color: theme.colorScheme.onSurface.withOpacity(0.7),
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      );
    }

    return SliverToBoxAdapter(
      child: Container(
        margin: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Recent Searches',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                TextButton(
                  onPressed: searchService.clearRecentSearches,
                  child: const Text('Clear all'),
                ),
              ],
            ),
            const SizedBox(height: 8),
            ...searchService.recentSearches.take(10).map((search) {
              return ListTile(
                leading: const Icon(Icons.history),
                title: Text(search.searchQuery),
                subtitle: Text(search.snippet),
                onTap: () {
                  _searchController.text = search.searchQuery;
                  _performSearch();
                },
                trailing: IconButton(
                  icon: const Icon(Icons.north_west),
                  onPressed: () {
                    _searchController.text = search.searchQuery;
                  },
                ),
              );
            }).toList(),
          ],
        ),
      ),
    );
  }

  void _performSearch() {
    final query = _searchController.text.trim();
    if (query.isEmpty) return;

    _focusNode.unfocus();
    setState(() => _showSuggestions = false);

    final searchService = context.read<SearchService>();
    searchService.search(query, types: _selectedTypes);
  }

  void _showFilterDialog() {
    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setStateDialog) {
            return AlertDialog(
              title: const Text('Filter Search Results'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Search in:'),
                  const SizedBox(height: 8),
                  CheckboxListTile(
                    title: const Text('Verses'),
                    value: _selectedTypes.contains(SearchType.verse),
                    onChanged: (value) {
                      setStateDialog(() {
                        if (value == true) {
                          _selectedTypes.add(SearchType.verse);
                        } else {
                          _selectedTypes.remove(SearchType.verse);
                        }
                      });
                    },
                  ),
                  CheckboxListTile(
                    title: const Text('Chapters'),
                    value: _selectedTypes.contains(SearchType.chapter),
                    onChanged: (value) {
                      setStateDialog(() {
                        if (value == true) {
                          _selectedTypes.add(SearchType.chapter);
                        } else {
                          _selectedTypes.remove(SearchType.chapter);
                        }
                      });
                    },
                  ),
                  CheckboxListTile(
                    title: const Text('Scenarios'),
                    value: _selectedTypes.contains(SearchType.scenario),
                    onChanged: (value) {
                      setStateDialog(() {
                        if (value == true) {
                          _selectedTypes.add(SearchType.scenario);
                        } else {
                          _selectedTypes.remove(SearchType.scenario);
                        }
                      });
                    },
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Cancel'),
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                    if (_searchController.text.trim().isNotEmpty) {
                      _performSearch();
                    }
                  },
                  child: const Text('Apply'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  void _onResultTap(SearchResult result) {
    switch (result.resultType) {
      case SearchType.verse:
        if (result.chapterId != null) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => VerseListView(chapterId: result.chapterId!),
            ),
          );
        }
        break;
      case SearchType.chapter:
        if (result.chapterId != null) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => VerseListView(chapterId: result.chapterId!),
            ),
          );
        }
        break;
      case SearchType.scenario:
        if (result.scenarioId != null) {
          // Navigate to scenario detail - you'll need to implement this
          // Navigator.push(context, MaterialPageRoute(builder: (context) => ScenarioDetailScreen(scenarioId: result.scenarioId!)));
        }
        break;
      default:
        break;
    }
  }
}