// lib/screens/meditation_screen.dart

import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/meditation_service.dart';

class MeditationScreen extends StatefulWidget {
  final MeditationTemplate template;
  
  const MeditationScreen({
    Key? key,
    required this.template,
  }) : super(key: key);

  @override
  State<MeditationScreen> createState() => _MeditationScreenState();
}

class _MeditationScreenState extends State<MeditationScreen> 
    with TickerProviderStateMixin {
  
  late AnimationController _breathingController;
  late AnimationController _rippleController;
  late Animation<double> _breathingAnimation;
  late Animation<double> _rippleAnimation;
  
  bool _hasStarted = false;
  int _currentGuidanceStep = 0;
  
  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _ensureMeditationServiceInitialized();
  }
  
  Future<void> _ensureMeditationServiceInitialized() async {
    if (!MeditationService.instance.isInitialized) {
      await MeditationService.instance.initialize();
      if (mounted) setState(() {});
    }
  }
  
  void _initializeAnimations() {
    _breathingController = AnimationController(
      duration: const Duration(seconds: 8), // 4 in, 4 out
      vsync: this,
    );
    
    _rippleController = AnimationController(
      duration: const Duration(seconds: 3),
      vsync: this,
    );
    
    _breathingAnimation = Tween<double>(
      begin: 0.8,
      end: 1.2,
    ).animate(CurvedAnimation(
      parent: _breathingController,
      curve: Curves.easeInOut,
    ));
    
    _rippleAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _rippleController,
      curve: Curves.easeOut,
    ));
    
    // Start breathing animation
    _breathingController.repeat(reverse: true);
    
    // Start ripple animation periodically
    _startRipples();
  }
  
  void _startRipples() {
    Timer.periodic(const Duration(seconds: 4), (timer) {
      if (mounted && _hasStarted) {
        _rippleController.forward().then((_) => _rippleController.reset());
      } else if (!mounted) {
        timer.cancel();
      }
    });
  }
  
  @override
  void dispose() {
    _breathingController.dispose();
    _rippleController.dispose();
    super.dispose();
  }
  
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider.value(
      value: MeditationService.instance,
      child: Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.close, color: Colors.white),
            onPressed: () => _showExitConfirmation(),
          ),
          title: Text(
            widget.template.title,
            style: const TextStyle(color: Colors.white),
          ),
          centerTitle: true,
        ),
        body: Consumer<MeditationService>(
          builder: (context, meditationService, child) {
            return Stack(
              children: [
                _buildBackground(),
                _buildContent(meditationService),
                if (meditationService.isSessionActive)
                  _buildControls(meditationService),
              ],
            );
          },
        ),
      ),
    );
  }
  
  Widget _buildBackground() {
    return Container(
      decoration: const BoxDecoration(
        gradient: RadialGradient(
          center: Alignment.center,
          radius: 1.0,
          colors: [
            Color(0xFF2D1B69),
            Color(0xFF11052C),
            Colors.black,
          ],
          stops: [0.0, 0.7, 1.0],
        ),
      ),
    );
  }
  
  Widget _buildContent(MeditationService meditationService) {
    if (!_hasStarted) {
      return _buildStartScreen();
    }
    
    if (meditationService.isSessionActive) {
      return _buildMeditationSession(meditationService);
    }
    
    return _buildCompletionScreen(meditationService);
  }
  
  Widget _buildStartScreen() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _buildBreathingCircle(showTimer: false),
            const SizedBox(height: 40),
            Text(
              widget.template.title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            Text(
              widget.template.description,
              style: TextStyle(
                color: Colors.white.withOpacity(0.8),
                fontSize: 16,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),
            _buildSessionDetails(),
            const SizedBox(height: 40),
            ElevatedButton(
              onPressed: _startMeditation,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.purple,
                padding: const EdgeInsets.symmetric(horizontal: 48, vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: const [
                  Icon(Icons.play_arrow, color: Colors.white),
                  SizedBox(width: 8),
                  Text(
                    'Begin Meditation',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildSessionDetails() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.white.withOpacity(0.2),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildDetailItem(
                icon: Icons.timer,
                label: 'Duration',
                value: '${widget.template.durationMinutes} min',
              ),
              _buildDetailItem(
                icon: Icons.music_note,
                label: 'Music',
                value: widget.template.musicTheme.toString().split('.').last,
              ),
              _buildDetailItem(
                icon: Icons.self_improvement,
                label: 'Theme',
                value: widget.template.theme,
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            'Guided Steps: ${widget.template.guidanceSteps.length}',
            style: TextStyle(
              color: Colors.white.withOpacity(0.7),
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildDetailItem({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Column(
      children: [
        Icon(icon, color: Colors.white, size: 24),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            color: Colors.white.withOpacity(0.7),
            fontSize: 12,
          ),
        ),
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }
  
  Widget _buildMeditationSession(MeditationService meditationService) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _buildBreathingCircle(showTimer: true, meditationService: meditationService),
            const SizedBox(height: 40),
            _buildCurrentGuidance(),
            const SizedBox(height: 40),
            _buildProgressIndicator(meditationService),
          ],
        ),
      ),
    );
  }
  
  Widget _buildBreathingCircle({
    bool showTimer = true,
    MeditationService? meditationService,
  }) {
    return AnimatedBuilder(
      animation: Listenable.merge([_breathingAnimation, _rippleAnimation]),
      builder: (context, child) {
        return SizedBox(
          width: 300,
          height: 300,
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Ripple effects
              for (int i = 0; i < 3; i++)
                Transform.scale(
                  scale: _rippleAnimation.value * (1 + i * 0.3),
                  child: Container(
                    width: 300,
                    height: 300,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: Colors.purple.withOpacity(
                          (1 - _rippleAnimation.value) * 0.3,
                        ),
                        width: 2,
                      ),
                    ),
                  ),
                ),
              
              // Main breathing circle
              Transform.scale(
                scale: _breathingAnimation.value,
                child: Container(
                  width: 200,
                  height: 200,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [
                        Color(0xFF9C27B0),
                        Color(0xFF673AB7),
                        Color(0xFF3F51B5),
                      ],
                    ),
                  ),
                  child: showTimer && meditationService != null
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                meditationService.getFormattedRemainingTime(),
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 32,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'monospace',
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                meditationService.isPaused ? 'PAUSED' : 'remaining',
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.8),
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                        )
                      : const Center(
                          child: Icon(
                            Icons.self_improvement,
                            color: Colors.white,
                            size: 60,
                          ),
                        ),
                ),
              ),
              
              // Breathing instruction
              if (_hasStarted && meditationService?.isSessionActive == true)
                Positioned(
                  bottom: -60,
                  child: AnimatedBuilder(
                    animation: _breathingAnimation,
                    builder: (context, child) {
                      final isInhaling = _breathingController.status == AnimationStatus.forward;
                      return Text(
                        isInhaling ? 'Breathe In' : 'Breathe Out',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.8),
                          fontSize: 18,
                          fontWeight: FontWeight.w500,
                        ),
                      );
                    },
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
  
  Widget _buildCurrentGuidance() {
    if (widget.template.guidanceSteps.isEmpty) return const SizedBox.shrink();
    
    final step = widget.template.guidanceSteps[_currentGuidanceStep];
    
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.white.withOpacity(0.2),
        ),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.lightbulb_outline,
                color: Colors.yellow.shade300,
                size: 20,
              ),
              const SizedBox(width: 8),
              Text(
                'Guidance ${_currentGuidanceStep + 1}/${widget.template.guidanceSteps.length}',
                style: TextStyle(
                  color: Colors.white.withOpacity(0.7),
                  fontSize: 12,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            step,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w500,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
  
  Widget _buildProgressIndicator(MeditationService meditationService) {
    return Column(
      children: [
        LinearProgressIndicator(
          value: meditationService.getMeditationProgress(),
          backgroundColor: Colors.white.withOpacity(0.2),
          valueColor: const AlwaysStoppedAnimation<Color>(Colors.purple),
        ),
        const SizedBox(height: 8),
        Text(
          '${(meditationService.getMeditationProgress() * 100).round()}% Complete',
          style: TextStyle(
            color: Colors.white.withOpacity(0.7),
            fontSize: 14,
          ),
        ),
      ],
    );
  }
  
  Widget _buildControls(MeditationService meditationService) {
    return Positioned(
      bottom: 40,
      left: 0,
      right: 0,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          // Previous guidance
          IconButton(
            onPressed: _currentGuidanceStep > 0 ? () {
              setState(() => _currentGuidanceStep--);
            } : null,
            icon: const Icon(
              Icons.skip_previous,
              color: Colors.white,
              size: 32,
            ),
          ),
          
          // Play/Pause
          Container(
            width: 80,
            height: 80,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.purple,
            ),
            child: IconButton(
              onPressed: () {
                if (meditationService.isPaused) {
                  meditationService.resumeMeditation();
                } else {
                  meditationService.pauseMeditation();
                }
              },
              icon: Icon(
                meditationService.isPaused ? Icons.play_arrow : Icons.pause,
                color: Colors.white,
                size: 40,
              ),
            ),
          ),
          
          // Next guidance
          IconButton(
            onPressed: _currentGuidanceStep < widget.template.guidanceSteps.length - 1 ? () {
              setState(() => _currentGuidanceStep++);
            } : null,
            icon: const Icon(
              Icons.skip_next,
              color: Colors.white,
              size: 32,
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildCompletionScreen(MeditationService meditationService) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.check_circle,
              color: Colors.green,
              size: 100,
            ),
            const SizedBox(height: 24),
            const Text(
              'Meditation Complete!',
              style: TextStyle(
                color: Colors.white,
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'You meditated for ${meditationService.currentSession?.actualDurationSeconds ?? 0 ~/ 60} minutes',
              style: TextStyle(
                color: Colors.white.withOpacity(0.8),
                fontSize: 16,
              ),
            ),
            const SizedBox(height: 32),
            _buildRatingSection(meditationService),
            const SizedBox(height: 32),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.grey.shade600,
                    padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                  ),
                  child: const Text('Finish', style: TextStyle(color: Colors.white)),
                ),
                ElevatedButton(
                  onPressed: _startMeditation,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.purple,
                    padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                  ),
                  child: const Text('Meditate Again', style: TextStyle(color: Colors.white)),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildRatingSection(MeditationService meditationService) {
    double rating = 0;
    
    return StatefulBuilder(
      builder: (context, setRatingState) {
        return Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.1),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            children: [
              const Text(
                'How was your meditation?',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(5, (index) {
                  return IconButton(
                    onPressed: () {
                      setRatingState(() => rating = index + 1.0);
                      if (meditationService.currentSession != null) {
                        meditationService.rateSession(
                          meditationService.currentSession!.id,
                          rating,
                          null,
                        );
                      }
                    },
                    icon: Icon(
                      rating > index ? Icons.star : Icons.star_outline,
                      color: Colors.amber,
                      size: 32,
                    ),
                  );
                }),
              ),
            ],
          ),
        );
      },
    );
  }
  
  Future<void> _startMeditation() async {
    setState(() {
      _hasStarted = true;
      _currentGuidanceStep = 0;
    });
    
    await MeditationService.instance.startMeditation(
      templateId: widget.template.id,
    );
  }
  
  void _showExitConfirmation() {
    if (!_hasStarted || !MeditationService.instance.isSessionActive) {
      Navigator.pop(context);
      return;
    }
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('End Meditation?'),
        content: const Text('Your progress will be saved if you\'ve meditated for more than 1 minute.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Continue'),
          ),
          TextButton(
            onPressed: () async {
              await MeditationService.instance.stopMeditation();
              if (context.mounted) {
                Navigator.pop(context); // Close dialog
                Navigator.pop(context); // Close meditation screen
              }
            },
            child: const Text('End Session'),
          ),
        ],
      ),
    );
  }
}