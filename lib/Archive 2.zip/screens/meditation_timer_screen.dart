import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/simple_audio_service.dart';

class MeditationTimerScreen extends StatefulWidget {
  const MeditationTimerScreen({Key? key}) : super(key: key);

  @override
  State<MeditationTimerScreen> createState() => _MeditationTimerScreenState();
}

class _MeditationTimerScreenState extends State<MeditationTimerScreen>
    with TickerProviderStateMixin {
  final SimpleAudioService _musicService = SimpleAudioService();

  Timer? _timer;
  int _selectedMinutes = 10;
  int _remainingSeconds = 600; // 10 minutes default
  bool _isRunning = false;
  bool _isPaused = false;
  bool _musicEnabled = true;

  late AnimationController _breathingController;
  late Animation<double> _breathingAnimation;

  final List<int> _presetMinutes = [5, 10, 15, 20, 30];

  @override
  void initState() {
    super.initState();
    _initializeAnimation();
    _musicService.initialize();
  }

  void _initializeAnimation() {
    _breathingController = AnimationController(
      duration: const Duration(seconds: 8),
      vsync: this,
    );

    _breathingAnimation = Tween<double>(
      begin: 0.8,
      end: 1.2,
    ).animate(CurvedAnimation(
      parent: _breathingController,
      curve: Curves.easeInOut,
    ));

    _breathingController.repeat(reverse: true);
  }

  @override
  void dispose() {
    _timer?.cancel();
    _breathingController.dispose();
    _musicService.stop();
    super.dispose();
  }

  void _startMeditation() async {
    if (_musicEnabled) {
      // Check if we should attempt to play music (could be disabled globally)
      try {
        final musicLoaded = await _musicService.play('assets/music/meditation_music.mp3');
        if (!musicLoaded) {
          // Disable music for this session if asset fails to load
          debugPrint('🎵 Meditation music disabled due to loading failure');
          setState(() {
            _musicEnabled = false;
          });
          // Show a brief message to user
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: const Text('Background music unavailable - continuing in silence'),
                duration: const Duration(seconds: 2),
                behavior: SnackBarBehavior.floating,
              ),
            );
          }
        }
      } catch (e) {
        // Complete fallback in case of any audio system errors
        debugPrint('🎵 Audio system error: $e');
        setState(() {
          _musicEnabled = false;
        });
      }
    }

    setState(() {
      _isRunning = true;
      _isPaused = false;
    });

    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_remainingSeconds > 0) {
        setState(() {
          _remainingSeconds--;
        });
      } else {
        _completeMeditation();
      }
    });

    HapticFeedback.lightImpact();
  }

  void _pauseMeditation() {
    _timer?.cancel();
    if (_musicEnabled) {
      _musicService.pause();
    }
    setState(() {
      _isPaused = true;
    });
    HapticFeedback.lightImpact();
  }

  void _resumeMeditation() {
    if (_musicEnabled) {
      _musicService.resume();
    }
    setState(() {
      _isPaused = false;
    });
    _startMeditation();
  }

  void _stopMeditation() {
    _timer?.cancel();
    _musicService.stop();
    setState(() {
      _isRunning = false;
      _isPaused = false;
      _remainingSeconds = _selectedMinutes * 60;
    });
    HapticFeedback.mediumImpact();
  }

  void _completeMeditation() {
    _timer?.cancel();
    _musicService.stop();

    HapticFeedback.heavyImpact();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Meditation Complete'),
        content: Text('You completed $_selectedMinutes minutes of meditation.'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              setState(() {
                _isRunning = false;
                _isPaused = false;
                _remainingSeconds = _selectedMinutes * 60;
              });
            },
            child: const Text('Done'),
          ),
        ],
      ),
    );
  }

  String _formatTime(int seconds) {
    final minutes = seconds ~/ 60;
    final secs = seconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${secs.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: isDark
              ? [
                  const Color(0xFF1a237e),
                  const Color(0xFF0d47a1),
                ]
              : [
                  const Color(0xFFE3F2FD),
                  const Color(0xFFBBDEFB),
                ],
        ),
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            children: [
              const SizedBox(height: 20),
              Text(
                'Meditation Timer',
                style: theme.textTheme.headlineMedium?.copyWith(
                  fontWeight: FontWeight.w300,
                  letterSpacing: 1.5,
                  color: isDark ? Colors.white : Colors.black87,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Find your inner peace',
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: (isDark ? Colors.white : Colors.black87).withOpacity(0.7),
                ),
              ),
              const Spacer(),

              // Breathing circle with timer
              AnimatedBuilder(
                animation: _breathingAnimation,
                builder: (context, child) {
                  return Transform.scale(
                    scale: _isRunning ? _breathingAnimation.value : 1.0,
                    child: Container(
                      width: 250,
                      height: 250,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(
                          colors: [
                            (isDark ? Colors.blue[200] : Colors.blue[400])!.withOpacity(0.3),
                            (isDark ? Colors.blue[400] : Colors.blue[600])!.withOpacity(0.1),
                          ],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.blue.withOpacity(0.3),
                            blurRadius: 30,
                            spreadRadius: 10,
                          ),
                        ],
                      ),
                      child: Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              _formatTime(_remainingSeconds),
                              style: theme.textTheme.displayLarge?.copyWith(
                                fontWeight: FontWeight.w200,
                                color: isDark ? Colors.white : Colors.black87,
                                letterSpacing: 2,
                              ),
                            ),
                            if (_isRunning && !_isPaused)
                              Text(
                                _breathingAnimation.value > 1.0 ? 'Breathe In' : 'Breathe Out',
                                style: theme.textTheme.bodyLarge?.copyWith(
                                  color: (isDark ? Colors.white : Colors.black87).withOpacity(0.7),
                                ),
                              ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),

              const Spacer(),

              // Timer presets
              if (!_isRunning)
                Wrap(
                  spacing: 12,
                  children: _presetMinutes.map((minutes) {
                    return ChoiceChip(
                      label: Text('$minutes min'),
                      selected: _selectedMinutes == minutes,
                      onSelected: (selected) {
                        if (selected) {
                          setState(() {
                            _selectedMinutes = minutes;
                            _remainingSeconds = minutes * 60;
                          });
                        }
                      },
                    );
                  }).toList(),
                ),

              const SizedBox(height: 40),

              // Control buttons
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Music toggle
                  IconButton(
                    icon: Icon(
                      _musicEnabled ? Icons.music_note : Icons.music_off,
                      color: isDark ? Colors.white70 : Colors.black54,
                    ),
                    onPressed: () async {
                      setState(() {
                        _musicEnabled = !_musicEnabled;
                      });

                      if (!_musicEnabled && _isRunning) {
                        _musicService.stop();
                      } else if (_musicEnabled && _isRunning && !_isPaused) {
                        final musicLoaded = await _musicService.play('assets/music/meditation_music.mp3');
                        if (!musicLoaded) {
                          // If music fails to load, disable it again
                          setState(() {
                            _musicEnabled = false;
                          });
                        }
                      }
                    },
                  ),

                  const SizedBox(width: 20),

                  // Main control button
                  if (!_isRunning)
                    _buildControlButton(
                      icon: Icons.play_arrow,
                      label: 'Start',
                      onPressed: _startMeditation,
                      isPrimary: true,
                    )
                  else if (_isPaused)
                    Row(
                      children: [
                        _buildControlButton(
                          icon: Icons.play_arrow,
                          label: 'Resume',
                          onPressed: _resumeMeditation,
                          isPrimary: true,
                        ),
                        const SizedBox(width: 16),
                        _buildControlButton(
                          icon: Icons.stop,
                          label: 'Stop',
                          onPressed: _stopMeditation,
                          isPrimary: false,
                        ),
                      ],
                    )
                  else
                    Row(
                      children: [
                        _buildControlButton(
                          icon: Icons.pause,
                          label: 'Pause',
                          onPressed: _pauseMeditation,
                          isPrimary: true,
                        ),
                        const SizedBox(width: 16),
                        _buildControlButton(
                          icon: Icons.stop,
                          label: 'Stop',
                          onPressed: _stopMeditation,
                          isPrimary: false,
                        ),
                      ],
                    ),
                ],
              ),

              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildControlButton({
    required IconData icon,
    required String label,
    required VoidCallback onPressed,
    required bool isPrimary,
  }) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return ElevatedButton.icon(
      onPressed: onPressed,
      icon: Icon(icon),
      label: Text(label),
      style: ElevatedButton.styleFrom(
        backgroundColor: isPrimary
            ? (isDark ? Colors.blue[700] : Colors.blue)
            : (isDark ? Colors.grey[800] : Colors.grey[300]),
        foregroundColor: isPrimary
            ? Colors.white
            : (isDark ? Colors.white : Colors.black87),
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30),
        ),
      ),
    );
  }
}