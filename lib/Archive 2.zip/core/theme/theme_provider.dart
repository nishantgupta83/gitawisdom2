// lib/core/theme/theme_provider.dart

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../app_config.dart';
import '../../services/settings_service.dart';
import '../../services/widget_service.dart';
import 'app_theme.dart';

/// Theme provider that manages app theme state and settings
/// Replaces complex ValueListenableBuilder logic from main.dart
class ThemeProvider extends ChangeNotifier {
  late Box _settingsBox;
  WidgetService? _widgetService;
  
  // Current theme settings
  bool _isDark = AppConfig.defaultDarkMode;
  String _fontPref = AppConfig.defaultFontSize;
  bool _shadowEnabled = AppConfig.defaultShadowEnabled;
  double _backgroundOpacity = AppConfig.defaultBackgroundOpacity;

  // Getters for current theme settings
  bool get isDark => _isDark;
  String get fontPref => _fontPref;
  bool get shadowEnabled => _shadowEnabled;
  double get backgroundOpacity => _backgroundOpacity;
  double get textScale => AppConfig.getTextScale(_fontPref);
  ThemeMode get themeMode => AppTheme.getThemeMode(_isDark);
  
  /// Initialize theme provider with settings box
  Future<void> initialize({WidgetService? widgetService}) async {
    try {
      _settingsBox = Hive.box(SettingsService.boxName);
      _widgetService = widgetService;
      _loadSettings();
      _settingsBox.listenable().addListener(_onSettingsChanged);
      debugPrint('✅ ThemeProvider initialized');
    } catch (e) {
      debugPrint('❌ ThemeProvider initialization failed: $e');
      rethrow;
    }
  }

  /// Load current settings from Hive box
  void _loadSettings() {
    _isDark = _settingsBox.get(SettingsService.darkKey, defaultValue: AppConfig.defaultDarkMode) as bool;
    _fontPref = _settingsBox.get(SettingsService.fontKey, defaultValue: AppConfig.defaultFontSize) as String;
    _shadowEnabled = _settingsBox.get(SettingsService.shadowKey, defaultValue: AppConfig.defaultShadowEnabled) as bool;
    _backgroundOpacity = _settingsBox.get(SettingsService.opacityKey, defaultValue: AppConfig.defaultBackgroundOpacity) as double;
  }

  /// Handle settings changes from Hive box (with debouncing to prevent UI hangs)
  Timer? _themeUpdateTimer;
  static const Duration _themeDebounce = Duration(milliseconds: 100);

  void _onSettingsChanged() {
    // Cancel previous timer to debounce rapid theme changes
    _themeUpdateTimer?.cancel();
    _themeUpdateTimer = Timer(_themeDebounce, () {
      final newIsDark = _settingsBox.get(SettingsService.darkKey, defaultValue: AppConfig.defaultDarkMode) as bool;
      final newFontPref = _settingsBox.get(SettingsService.fontKey, defaultValue: AppConfig.defaultFontSize) as String;
      final newShadowEnabled = _settingsBox.get(SettingsService.shadowKey, defaultValue: AppConfig.defaultShadowEnabled) as bool;
      final newBackgroundOpacity = _settingsBox.get(SettingsService.opacityKey, defaultValue: AppConfig.defaultBackgroundOpacity) as double;
      
      if (newIsDark != _isDark || 
          newFontPref != _fontPref || 
          newShadowEnabled != _shadowEnabled || 
          newBackgroundOpacity != _backgroundOpacity) {
        
        // Notify widget service about theme transition
        _widgetService?.setThemeTransitioning(true);
        
        _isDark = newIsDark;
        _fontPref = newFontPref;
        _shadowEnabled = newShadowEnabled;
        _backgroundOpacity = newBackgroundOpacity;
        
        // Use microtask to prevent main thread blocking
        Future.microtask(() => notifyListeners());
        debugPrint('🎨 Theme updated: dark=$newIsDark, shadow=$newShadowEnabled');
      }
    });
  }

  /// Get light theme with current settings
  ThemeData get lightTheme => AppTheme.buildLightTheme(shadowEnabled: _shadowEnabled);
  
  /// Get dark theme with current settings
  ThemeData get darkTheme => AppTheme.buildDarkTheme(shadowEnabled: _shadowEnabled);
  
  /// Get current theme based on dark mode setting
  ThemeData get currentTheme => _isDark ? darkTheme : lightTheme;

  /// Update theme settings
  Future<void> updateTheme({
    bool? isDark,
    String? fontPref,
    bool? shadowEnabled,
    double? backgroundOpacity,
  }) async {
    try {
      if (isDark != null && isDark != _isDark) {
        await _settingsBox.put(SettingsService.darkKey, isDark);
      }
      if (fontPref != null && fontPref != _fontPref) {
        await _settingsBox.put(SettingsService.fontKey, fontPref);
      }
      if (shadowEnabled != null && shadowEnabled != _shadowEnabled) {
        await _settingsBox.put(SettingsService.shadowKey, shadowEnabled);
      }
      if (backgroundOpacity != null && backgroundOpacity != _backgroundOpacity) {
        await _settingsBox.put(SettingsService.opacityKey, backgroundOpacity);
      }
      // Settings change will be handled by _onSettingsChanged
    } catch (e) {
      debugPrint('❌ Failed to update theme settings: $e');
    }
  }

  /// Toggle dark mode
  Future<void> toggleDarkMode() async {
    await updateTheme(isDark: !_isDark);
  }

  /// Set font size
  Future<void> setFontSize(String size) async {
    await updateTheme(fontPref: size);
  }

  /// Toggle shadow enabled
  Future<void> toggleShadow() async {
    await updateTheme(shadowEnabled: !_shadowEnabled);
  }

  /// Set background opacity
  Future<void> setBackgroundOpacity(double opacity) async {
    await updateTheme(backgroundOpacity: opacity);
  }

  @override
  void dispose() {
    _themeUpdateTimer?.cancel();
    _settingsBox.listenable().removeListener(_onSettingsChanged);
    super.dispose();
  }
}