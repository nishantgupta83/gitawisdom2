// lib/core/app_initializer.dart

import 'dart:io' show Platform, Directory;
import 'dart:async' show unawaited, TimeoutException;
import 'dart:isolate';
import 'package:flutter/foundation.dart' show compute;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:path_provider/path_provider.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../config/environment.dart';
import '../services/settings_service.dart';
import '../services/daily_verse_service.dart';
import '../services/scenario_service.dart';
import '../services/journal_service.dart';
// import '../services/audio_service.dart'; // Removed - using EnhancedAudioService with lazy loading
import '../services/app_lifecycle_manager.dart';
import '../services/service_locator.dart';
import '../services/simple_meditation_service.dart';
// import 'hive_manager.dart'; // Removed for simplification
import 'performance_monitor.dart';
import '../models/journal_entry.dart';
import '../models/scenario.dart';
import '../models/chapter.dart';
import '../models/verse.dart';
import '../models/chapter_summary.dart';
import '../models/daily_verse_set.dart';
import '../models/bookmark.dart';

/// Handles all app initialization logic
/// Separated from main.dart for better maintainability and testing
class AppInitializer {
  static Future<void> initializeCriticalServices() async {
    // Set full-screen app layout - ensure app uses full device size
    // Modern edge-to-edge handling compatible with Android 15
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    
    // Only set SystemUiOverlayStyle on platforms where it's still effective (not Android 15+)
    // Android 15+ handles this through styles.xml configuration
    try {
      if (Platform.isIOS || Platform.isMacOS) {
        SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: Brightness.light,
          systemNavigationBarColor: Colors.transparent,
          systemNavigationBarDividerColor: Colors.transparent,
        ));
      }
    } catch (e) {
      // Platform operations not supported on web
      debugPrint('⚠️ Platform operations skipped for web: $e');
    }

    try {
      // ✅ Critical initialization only - everything else will be lazy loaded
      Environment.validateConfiguration();

      // ✅ Initialize Supabase (essential for app functionality)
      await Supabase.initialize(
        url: Environment.supabaseUrl,
        anonKey: Environment.supabaseAnonKey,
      );

      // ✅ Basic Hive setup only
      final appDocDir = await getApplicationDocumentsDirectory();
      Hive.init(appDocDir.path);
      await SettingsService.init();

      // ✅ Initialize performance monitoring (debug builds only)
      PerformanceMonitor.instance.initialize();

      debugPrint('✅ Critical services initialized successfully');
    } catch (error, stackTrace) {
      debugPrint('❌ Critical initialization failed: $error');
      debugPrint('Stack trace: $stackTrace');
      rethrow;
    }
  }

  /// Lazy initialization function called after app starts
  /// Non-critical services that can be loaded in background with timeout
  static Future<void> initializeSecondaryServices() async {
    try {
      // Add timeout to prevent hanging on slow devices - reduced for faster startup
      await Future.any([
        _performSecondaryInitialization(),
        Future.delayed(const Duration(seconds: 6)).then((_) {
          debugPrint('⏰ Secondary service initialization timed out after 6 seconds');
          throw TimeoutException('Secondary initialization timeout', const Duration(seconds: 6));
        }),
      ]);
    } catch (e) {
      debugPrint('⚠️ Secondary service initialization handled: $e');
      // Continue with app launch even if secondary services fail
    }
  }

  /// Perform secondary initialization with optimizations
  static Future<void> _performSecondaryInitialization() async {
    // Register Hive adapters first
    await Future.microtask(() async {
      try {
        // Clear old Hive storage to prevent typeId conflicts from removed models
        await _clearOldHiveData();

        // Register ALL required model adapters with correct typeIds
        if (!Hive.isAdapterRegistered(0)) {
          Hive.registerAdapter(JournalEntryAdapter()); // typeId: 0
        }
        if (!Hive.isAdapterRegistered(1)) {
          Hive.registerAdapter(ChapterAdapter()); // typeId: 1
        }
        if (!Hive.isAdapterRegistered(2)) {
          Hive.registerAdapter(DailyVerseSetAdapter()); // typeId: 2
        }
        if (!Hive.isAdapterRegistered(3)) {
          Hive.registerAdapter(ChapterSummaryAdapter()); // typeId: 3
        }
        if (!Hive.isAdapterRegistered(4)) {
          Hive.registerAdapter(VerseAdapter()); // typeId: 4
        }
        if (!Hive.isAdapterRegistered(5)) {
          Hive.registerAdapter(ScenarioAdapter()); // typeId: 5
        }
        if (!Hive.isAdapterRegistered(9)) {
          Hive.registerAdapter(BookmarkAdapter()); // typeId: 9
        }

        debugPrint('✅ Hive adapters registered successfully');
      } catch (e) {
        debugPrint('⚠️ Hive adapter registration warning: $e');
      }
    });

    // Initialize core services in parallel where possible
    await Future.wait([
      Future.microtask(() => _initializeCoreServices()),
      Future.microtask(() => _initializeBackgroundServices()),
    ]);

    debugPrint('✅ Secondary services initialized successfully');
  }

  static Future<void> _initializeCoreServices() async {
    // Initialize critical services first (fast ones)
    await Future.wait([
      // Journal service (fast - local only)
      JournalService.instance.initialize(),
      
      // Enhanced Supabase Service via Service Locator (fast - connection only)
      ServiceLocator.instance.initialize(),
      
      // Daily verse service (fast - cached)
      DailyVerseService.instance.initialize(),
    ]);
    
    // Initialize lightweight services immediately
    await Future.wait([
      // Practice services (fast - local Hive operations)
      // Practice service removed for Apple compliance
      SimpleMeditationService.instance.initialize(),
    ]);
    
    // Initialize notification service last (can be deferred)
    // Practice notification service removed for Apple compliance
    
    // Initialize heavy services in background with proper thread management
    unawaited(_initializeHeavyServicesInBackground());
  }
  
  /// Initialize heavy services in background with proper thread management
  /// This prevents blocking the main UI thread during heavy operations
  static Future<void> _initializeHeavyServicesInBackground() async {
    try {
      debugPrint('🚀 Starting heavy service initialization in background');
      
      // Use chunked initialization to prevent blocking
      await _initializeScenarioServiceChunked();
      
      debugPrint('✅ Heavy services initialized successfully in background');
    } catch (e) {
      debugPrint('❌ Heavy service initialization failed: $e');
      // Continue gracefully - app can still function without scenarios initially
    }
  }
  
  /// Initialize ScenarioService with chunked loading to prevent UI blocking
  static Future<void> _initializeScenarioServiceChunked() async {
    const int chunkDelayMs = 50; // Yield every 50ms
    int processedChunks = 0;
    
    try {
      // Initialize service first (lightweight operation)
      await ScenarioService.instance.initialize();
      
      debugPrint('📊 ScenarioService initialized, starting chunked data loading...');
      
      // Pre-load scenarios in chunks to prevent blocking
      await _loadScenariosInChunks(chunkDelayMs);
      
      debugPrint('✅ Scenario data loading completed');
    } catch (e) {
      debugPrint('❌ Chunked scenario initialization failed: $e');
      // Fallback: ensure service is at least initialized
      try {
        await ScenarioService.instance.initialize();
      } catch (fallbackError) {
        debugPrint('❌ Scenario service fallback initialization failed: $fallbackError');
      }
    }
  }
  
  /// Load scenarios in chunks with yielding to prevent UI blocking
  static Future<void> _loadScenariosInChunks(int chunkDelayMs) async {
    // Yield to UI thread frequently during heavy operations
    int yieldCounter = 0;
    const yieldFrequency = 10; // Yield every 10 operations
    
    try {
      // Trigger the heavy scenario loading operation
      final scenarioFuture = ScenarioService.instance.getAllScenarios();
      
      // Wait for scenarios to load completely
      await scenarioFuture;
      debugPrint('✅ Scenarios loaded successfully');
      
    } catch (e) {
      debugPrint('❌ Chunked scenario loading failed: $e');
      rethrow;
    }
  }

  static Future<void> _initializeBackgroundServices() async {
    // Test Supabase connection
    try {
      final isConnected = await ServiceLocator.instance.enhancedSupabaseService.testConnection();
      if (!isConnected) {
        debugPrint('⚠️ Warning: Supabase connection failed - app may not load content properly');
      }
    } catch (e) {
      debugPrint('❌ Supabase connection test failed: $e');
    }

    // Audio initialization is now handled lazily by EnhancedAudioService
    debugPrint('🎵 Audio system will initialize on-demand');

    // Initialize app lifecycle manager for background music control
    try {
      AppLifecycleManager.instance.initialize();
      debugPrint('🎵 App lifecycle manager initialized successfully');
    } catch (e) {
      debugPrint('❌ App lifecycle manager initialization failed: $e');
    }
  }

  /// Clear old Hive data that may have incompatible typeIds
  static Future<void> _clearOldHiveData() async {
    try {
      final appDocDir = await getApplicationDocumentsDirectory();

      // Close all open boxes first to ensure clean deletion
      await Hive.close();

      // Comprehensive list of ALL possible box names that could contain old data
      const allPossibleBoxes = [
        // Core content boxes
        'daily_verses',
        'scenarios',
        'chapters',
        'chapter_summaries',
        'verses',
        'bookmarks',
        // Removed feature boxes
        'daily_practice',
        'user_favorites',
        'progress',
        'achievements',
        'streaks',
        'challenges',
        'notifications',
        'practice_sessions',
        'meditation_sessions',
        // Cache boxes
        'search_cache',
        'verse_cache',
        'scenario_cache',
        'chapter_cache',
        // Settings and user data
        'user_settings',
        'app_settings',
        'theme_settings',
        'audio_settings',
        // Analytics and logs
        'analytics_events',
        'performance_logs',
        'error_logs'
      ];

      int clearedCount = 0;
      for (final boxName in allPossibleBoxes) {
        try {
          if (await Hive.boxExists(boxName)) {
            await Hive.deleteBoxFromDisk(boxName);
            clearedCount++;
            debugPrint('🗑️ Cleared Hive box: $boxName');
          }
        } catch (e) {
          debugPrint('⚠️ Failed to clear box $boxName: $e');
        }
      }

      // Additional cleanup: try to clear any remaining .hive files
      try {
        final hiveDir = Directory('${appDocDir.path}');
        if (await hiveDir.exists()) {
          await for (final file in hiveDir.list()) {
            if (file.path.endsWith('.hive') || file.path.endsWith('.lock')) {
              try {
                await file.delete();
                debugPrint('🗑️ Deleted Hive file: ${file.path}');
              } catch (e) {
                debugPrint('⚠️ Could not delete ${file.path}: $e');
              }
            }
          }
        }
      } catch (e) {
        debugPrint('⚠️ Directory cleanup warning: $e');
      }

      debugPrint('✅ Comprehensive Hive cleanup completed - cleared $clearedCount boxes');
    } catch (e) {
      debugPrint('⚠️ Hive cleanup warning: $e');
    }
  }

}