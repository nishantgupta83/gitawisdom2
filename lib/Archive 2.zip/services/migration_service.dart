// lib/services/migration_service.dart
import 'dart:convert';
import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../services/firebase_service.dart';

class MigrationService {
  static const int batchSize = 100;
  
  // ==========================================
  // MAIN MIGRATION PROCESS
  // ==========================================
  
  static Future<void> performFullMigration() async {
    print('🚀 Starting full migration from Supabase to Firebase...');
    
    try {
      // Step 1: Export data from Supabase
      print('📤 Exporting data from Supabase...');
      final exportedData = await _exportFromSupabase();
      
      // Step 2: Create local backup
      print('💾 Creating local backup...');
      await _createLocalBackup(exportedData);
      
      // Step 3: Import to Firebase
      print('📥 Importing data to Firebase...');
      await _importToFirebase(exportedData);
      
      // Step 4: Validate migration
      print('✅ Validating migration...');
      await _validateMigration(exportedData);
      
      // Step 5: Performance test
      print('⚡ Testing performance...');
      await _performanceTest();
      
      print('🎉 Migration completed successfully!');
      
    } catch (e, stackTrace) {
      print('❌ Migration failed: $e');
      print('Stack trace: $stackTrace');
      rethrow;
    }
  }
  
  // ==========================================
  // EXPORT FROM SUPABASE
  // ==========================================
  
  static Future<Map<String, List<Map<String, dynamic>>>> _exportFromSupabase() async {
    final supabase = Supabase.instance.client;
    final Map<String, List<Map<String, dynamic>>> exportedData = {};
    
    // Export chapters
    print('  📖 Exporting chapters...');
    try {
      final chaptersResponse = await supabase.from('chapters').select();
      exportedData['chapters'] = List<Map<String, dynamic>>.from(chaptersResponse);
      print('  ✅ Exported ${exportedData['chapters']!.length} chapters');
    } catch (e) {
      throw Exception('Failed to export chapters: $e');
    }
    
    // Export scenarios in batches
    print('  📝 Exporting scenarios...');
    List<Map<String, dynamic>> allScenarios = [];
    int offset = 0;
    
    try {
      while (true) {
        final scenariosResponse = await supabase
            .from('scenarios')
            .select()
            .range(offset, offset + batchSize - 1);
        
        if (scenariosResponse.isEmpty) break;
        
        allScenarios.addAll(List<Map<String, dynamic>>.from(scenariosResponse));
        offset += batchSize;
        print('  📊 Exported ${allScenarios.length} scenarios so far...');
      }
      
      exportedData['scenarios'] = allScenarios;
      print('  ✅ Exported ${exportedData['scenarios']!.length} scenarios total');
    } catch (e) {
      throw Exception('Failed to export scenarios: $e');
    }
    
    // Export verses
    print('  📜 Exporting gita verses...');
    try {
      final versesResponse = await supabase.from('gita_verses').select();
      exportedData['gita_verses'] = List<Map<String, dynamic>>.from(versesResponse);
      print('  ✅ Exported ${exportedData['gita_verses']!.length} verses');
    } catch (e) {
      throw Exception('Failed to export verses: $e');
    }
    
    // Export chapter summaries
    print('  📋 Exporting chapter summaries...');
    try {
      final summariesResponse = await supabase.from('chapter_summary').select();
      exportedData['chapter_summary'] = List<Map<String, dynamic>>.from(summariesResponse);
      print('  ✅ Exported ${exportedData['chapter_summary']!.length} summaries');
    } catch (e) {
      throw Exception('Failed to export chapter summaries: $e');
    }
    
    // Export daily quotes
    print('  💬 Exporting daily quotes...');
    try {
      final quotesResponse = await supabase.from('daily_quote').select();
      exportedData['daily_quotes'] = List<Map<String, dynamic>>.from(quotesResponse);
      print('  ✅ Exported ${exportedData['daily_quotes']!.length} daily quotes');
    } catch (e) {
      print('  ⚠️ Warning: Failed to export daily quotes, continuing... ($e)');
      exportedData['daily_quotes'] = [];
    }
    
    return exportedData;
  }
  
  // ==========================================
  // CREATE LOCAL BACKUP
  // ==========================================
  
  static Future<void> _createLocalBackup(Map<String, List<Map<String, dynamic>>> data) async {
    final timestamp = DateTime.now().toIso8601String().replaceAll(':', '-');
    
    try {
      // Create migration_backups directory if it doesn't exist
      final backupsDir = Directory('migration_backups');
      if (!await backupsDir.exists()) {
        await backupsDir.create();
      }
      
      // Create main backup file
      final backupFile = File('migration_backups/supabase_backup_$timestamp.json');
      await backupFile.writeAsString(
        JsonEncoder.withIndent('  ').convert(data),
      );
      
      // Create summary file
      final summaryFile = File('migration_backups/backup_summary_$timestamp.txt');
      final summary = StringBuffer();
      summary.writeln('Supabase Backup Summary');
      summary.writeln('Created: $timestamp');
      summary.writeln('Total Tables: ${data.keys.length}');
      summary.writeln('');
      
      for (final entry in data.entries) {
        summary.writeln('${entry.key}: ${entry.value.length} records');
      }
      
      await summaryFile.writeAsString(summary.toString());
      
      print('  💾 Backup saved to: ${backupFile.path}');
      print('  📄 Summary saved to: ${summaryFile.path}');
      
    } catch (e) {
      throw Exception('Failed to create local backup: $e');
    }
  }
  
  // ==========================================
  // IMPORT TO FIREBASE
  // ==========================================
  
  static Future<void> _importToFirebase(Map<String, List<Map<String, dynamic>>> data) async {
    final firestore = FirebaseFirestore.instance;
    
    // Import chapters
    await _importChapters(firestore, data['chapters'] ?? []);
    
    // Import scenarios (most important)
    await _importScenarios(firestore, data['scenarios'] ?? []);
    
    // Import verses
    await _importVerses(firestore, data['gita_verses'] ?? []);
    
    // Import daily quotes
    await _importDailyQuotes(firestore, data['daily_quotes'] ?? []);
    
    print('  🎉 All data imported successfully!');
  }
  
  static Future<void> _importChapters(FirebaseFirestore firestore, List<Map<String, dynamic>> chapters) async {
    if (chapters.isEmpty) return;
    
    print('  📖 Importing ${chapters.length} chapters to Firebase...');
    
    final batch = firestore.batch();
    
    for (final chapter in chapters) {
      final docRef = firestore.collection('chapters').doc();
      batch.set(docRef, {
        'ch_chapter_id': chapter['ch_chapter_id'],
        'ch_title': chapter['ch_title'],
        'ch_summary': chapter['ch_summary'],
        'ch_verse_count': chapter['ch_verse_count'],
        'created_at': FieldValue.serverTimestamp(),
        'updated_at': FieldValue.serverTimestamp(),
      });
    }
    
    await batch.commit();
    print('  ✅ Imported ${chapters.length} chapters');
  }
  
  static Future<void> _importScenarios(FirebaseFirestore firestore, List<Map<String, dynamic>> scenarios) async {
    if (scenarios.isEmpty) return;
    
    print('  📝 Importing ${scenarios.length} scenarios to Firebase...');
    
    // Import in batches due to Firestore batch size limits (500 operations per batch)
    for (int i = 0; i < scenarios.length; i += 450) {
      final batch = firestore.batch();
      final endIndex = (i + 450 > scenarios.length) ? scenarios.length : i + 450;
      
      for (int j = i; j < endIndex; j++) {
        final scenario = scenarios[j];
        final docRef = firestore.collection('scenarios').doc();
        
        // Clean and validate data
        final cleanedScenario = {
          'sc_title': _cleanString(scenario['sc_title']),
          'sc_description': _cleanString(scenario['sc_description']),
          'sc_heart_response': _cleanString(scenario['sc_heart_response']),
          'sc_duty_response': _cleanString(scenario['sc_duty_response']),
          'sc_gita_wisdom': _cleanString(scenario['sc_gita_wisdom']),
          'sc_verse': _cleanString(scenario['sc_verse']),
          'sc_chapter': scenario['sc_chapter'] ?? 1,
          'sc_category': _cleanString(scenario['sc_category']),
          'sc_tags': _cleanTags(scenario['sc_tags']),
          'sc_action_steps': _cleanActionSteps(scenario['sc_action_steps']),
          'quality_score': scenario['quality_score'] ?? _calculateQualityScore(scenario),
          'created_at': FieldValue.serverTimestamp(),
          'updated_at': FieldValue.serverTimestamp(),
        };
        
        batch.set(docRef, cleanedScenario);
      }
      
      await batch.commit();
      print('  📊 Imported ${endIndex} / ${scenarios.length} scenarios');
    }
    
    print('  ✅ Imported ${scenarios.length} scenarios total');
  }
  
  static Future<void> _importVerses(FirebaseFirestore firestore, List<Map<String, dynamic>> verses) async {
    if (verses.isEmpty) return;
    
    print('  📜 Importing ${verses.length} verses to Firebase...');
    
    // Import in batches
    for (int i = 0; i < verses.length; i += 450) {
      final batch = firestore.batch();
      final endIndex = (i + 450 > verses.length) ? verses.length : i + 450;
      
      for (int j = i; j < endIndex; j++) {
        final verse = verses[j];
        final docRef = firestore.collection('gita_verses').doc();
        
        batch.set(docRef, {
          'gv_chapter_id': verse['gv_chapter_id'],
          'gv_verse_number': verse['gv_verse_number'],
          'gv_verse_text': _cleanString(verse['gv_verse_text']),
          'gv_meaning': _cleanString(verse['gv_meaning']),
          'gv_commentary': _cleanString(verse['gv_commentary']),
          'created_at': FieldValue.serverTimestamp(),
          'updated_at': FieldValue.serverTimestamp(),
        });
      }
      
      await batch.commit();
      print('  📊 Imported ${endIndex} / ${verses.length} verses');
    }
    
    print('  ✅ Imported ${verses.length} verses total');
  }
  
  static Future<void> _importDailyQuotes(FirebaseFirestore firestore, List<Map<String, dynamic>> quotes) async {
    if (quotes.isEmpty) return;
    
    print('  💬 Importing ${quotes.length} daily quotes to Firebase...');
    
    final batch = firestore.batch();
    
    for (final quote in quotes) {
      final docRef = firestore.collection('daily_quotes').doc();
      batch.set(docRef, {
        'quote': _cleanString(quote['dq_quote']),
        'author': _cleanString(quote['dq_author']) ?? 'Bhagavad Gita',
        'date': quote['dq_date'],
        'chapter': quote['dq_chapter'],
        'verse': quote['dq_verse'],
        'created_at': FieldValue.serverTimestamp(),
      });
    }
    
    await batch.commit();
    print('  ✅ Imported ${quotes.length} daily quotes');
  }
  
  // ==========================================
  // DATA VALIDATION
  // ==========================================
  
  static Future<void> _validateMigration(Map<String, List<Map<String, dynamic>>> originalData) async {
    print('  🔍 Validating data integrity...');
    
    final firestore = FirebaseFirestore.instance;
    
    // Validate chapters
    final chaptersSnapshot = await firestore.collection('chapters').get();
    final importedChaptersCount = chaptersSnapshot.docs.length;
    final originalChaptersCount = originalData['chapters']?.length ?? 0;
    
    if (importedChaptersCount != originalChaptersCount) {
      throw Exception('Chapter count mismatch: Original $originalChaptersCount, Imported $importedChaptersCount');
    }
    
    // Validate scenarios
    final scenariosSnapshot = await firestore.collection('scenarios').get();
    final importedScenariosCount = scenariosSnapshot.docs.length;
    final originalScenariosCount = originalData['scenarios']?.length ?? 0;
    
    if (importedScenariosCount != originalScenariosCount) {
      throw Exception('Scenario count mismatch: Original $originalScenariosCount, Imported $importedScenariosCount');
    }
    
    // Validate verses
    final versesSnapshot = await firestore.collection('gita_verses').get();
    final importedVersesCount = versesSnapshot.docs.length;
    final originalVersesCount = originalData['gita_verses']?.length ?? 0;
    
    if (importedVersesCount != originalVersesCount) {
      throw Exception('Verse count mismatch: Original $originalVersesCount, Imported $importedVersesCount');
    }
    
    // Sample data validation
    await _validateSampleData(firestore);
    
    print('  ✅ Validation successful:');
    print('    📖 Chapters: $importedChaptersCount');
    print('    📝 Scenarios: $importedScenariosCount');
    print('    📜 Verses: $importedVersesCount');
  }
  
  static Future<void> _validateSampleData(FirebaseFirestore firestore) async {
    print('  🔍 Validating sample data quality...');
    
    // Check first chapter
    final chapterQuery = await firestore.collection('chapters')
        .where('ch_chapter_id', isEqualTo: 1)
        .limit(1)
        .get();
    
    if (chapterQuery.docs.isEmpty) {
      throw Exception('Chapter 1 not found in Firebase');
    }
    
    final chapterData = chapterQuery.docs.first.data();
    if (chapterData['ch_title'] == null || chapterData['ch_title'].toString().isEmpty) {
      throw Exception('Chapter 1 has invalid title');
    }
    
    // Check sample scenario
    final scenarioQuery = await firestore.collection('scenarios')
        .limit(1)
        .get();
    
    if (scenarioQuery.docs.isEmpty) {
      throw Exception('No scenarios found in Firebase');
    }
    
    final scenarioData = scenarioQuery.docs.first.data();
    final requiredFields = ['sc_title', 'sc_description', 'sc_heart_response', 'sc_duty_response'];
    
    for (final field in requiredFields) {
      if (scenarioData[field] == null || scenarioData[field].toString().isEmpty) {
        throw Exception('Scenario has invalid $field');
      }
    }
    
    print('  ✅ Sample data validation passed');
  }
  
  // ==========================================
  // PERFORMANCE TESTING
  // ==========================================
  
  static Future<void> _performanceTest() async {
    print('  ⚡ Testing Firebase performance...');
    
    final stopwatch = Stopwatch();
    
    // Test 1: Get chapters
    stopwatch.reset();
    stopwatch.start();
    await FirebaseService.getChapters();
    stopwatch.stop();
    final chaptersTime = stopwatch.elapsedMilliseconds;
    
    // Test 2: Get scenarios by chapter
    stopwatch.reset();
    stopwatch.start();
    await FirebaseService.getScenariosByChapter(2, limit: 20);
    stopwatch.stop();
    final scenariosTime = stopwatch.elapsedMilliseconds;
    
    // Test 3: Get verses by chapter
    stopwatch.reset();
    stopwatch.start();
    await FirebaseService.getVersesByChapter(1);
    stopwatch.stop();
    final versesTime = stopwatch.elapsedMilliseconds;
    
    // Test 4: Search scenarios
    stopwatch.reset();
    stopwatch.start();
    await FirebaseService.searchScenarios('work', limit: 10);
    stopwatch.stop();
    final searchTime = stopwatch.elapsedMilliseconds;
    
    print('  📊 Performance Results:');
    print('    Chapters: ${chaptersTime}ms');
    print('    Scenarios by Chapter: ${scenariosTime}ms');
    print('    Verses by Chapter: ${versesTime}ms');
    print('    Search: ${searchTime}ms');
    
    // Performance benchmarks (should be faster than Supabase)
    if (chaptersTime > 1000) {
      print('  ⚠️ Warning: Chapters query slower than expected');
    }
    
    if (scenariosTime > 1000) {
      print('  ⚠️ Warning: Scenarios query slower than expected');
    }
    
    print('  ✅ Performance test completed');
  }
  
  // ==========================================
  // UTILITY FUNCTIONS
  // ==========================================
  
  static String _cleanString(dynamic value) {
    if (value == null) return '';
    return value.toString().trim();
  }
  
  static List<String> _cleanTags(dynamic tags) {
    if (tags == null) return [];
    
    if (tags is List) {
      return tags.map((tag) => tag.toString().trim()).where((tag) => tag.isNotEmpty).toList();
    }
    
    if (tags is String) {
      // Handle comma-separated string
      return tags.split(',').map((tag) => tag.trim()).where((tag) => tag.isNotEmpty).toList();
    }
    
    return [];
  }
  
  static List<String> _cleanActionSteps(dynamic steps) {
    if (steps == null) return [];
    
    if (steps is List) {
      return steps.map((step) => step.toString().trim()).where((step) => step.isNotEmpty).toList();
    }
    
    if (steps is String) {
      // Handle newline-separated string
      return steps.split('\n').map((step) => step.trim()).where((step) => step.isNotEmpty).toList();
    }
    
    return [];
  }
  
  static int _calculateQualityScore(Map<String, dynamic> scenario) {
    int score = 0;
    
    // Title quality (25 points)
    final title = scenario['sc_title']?.toString() ?? '';
    if (title.length >= 10 && title.length <= 100) {
      score += 25;
    }
    
    // Description quality (25 points)
    final description = scenario['sc_description']?.toString() ?? '';
    if (description.length >= 100 && description.length <= 500) {
      score += 25;
    }
    
    // Heart response quality (25 points)
    final heartResponse = scenario['sc_heart_response']?.toString() ?? '';
    if (heartResponse.length >= 100) {
      score += 25;
    }
    
    // Duty response quality (25 points)
    final dutyResponse = scenario['sc_duty_response']?.toString() ?? '';
    if (dutyResponse.length >= 120) {
      score += 25;
    }
    
    return score;
  }
  
  // ==========================================
  // MIGRATION STATUS
  // ==========================================
  
  static Future<Map<String, dynamic>> getMigrationStatus() async {
    try {
      final firestore = FirebaseFirestore.instance;
      
      final [chaptersSnap, scenariosSnap, versesSnap] = await Future.wait([
        firestore.collection('chapters').get(),
        firestore.collection('scenarios').get(),
        firestore.collection('gita_verses').get(),
      ]);
      
      return {
        'status': 'completed',
        'timestamp': DateTime.now().toIso8601String(),
        'counts': {
          'chapters': chaptersSnap.size,
          'scenarios': scenariosSnap.size,
          'verses': versesSnap.size,
        },
        'last_validated': DateTime.now().toIso8601String(),
      };
    } catch (e) {
      return {
        'status': 'error',
        'error': e.toString(),
        'timestamp': DateTime.now().toIso8601String(),
      };
    }
  }
  
  // ==========================================
  // ROLLBACK FUNCTIONALITY
  // ==========================================
  
  static Future<void> rollbackMigration() async {
    print('🔄 Rolling back Firebase migration...');
    
    try {
      final firestore = FirebaseFirestore.instance;
      
      // Delete all migrated collections
      await _deleteCollection(firestore, 'chapters');
      await _deleteCollection(firestore, 'scenarios');
      await _deleteCollection(firestore, 'gita_verses');
      await _deleteCollection(firestore, 'daily_quotes');
      
      print('✅ Migration rollback completed');
      
    } catch (e) {
      throw Exception('Rollback failed: $e');
    }
  }
  
  static Future<void> _deleteCollection(FirebaseFirestore firestore, String collectionName) async {
    print('  🗑️ Deleting $collectionName collection...');
    
    final snapshot = await firestore.collection(collectionName).get();
    
    for (final doc in snapshot.docs) {
      await doc.reference.delete();
    }
    
    print('  ✅ Deleted ${snapshot.docs.length} documents from $collectionName');
  }
}