// lib/services/narration_service.dart

import 'package:flutter/foundation.dart';
import 'package:flutter_tts/flutter_tts.dart';
import '../models/verse.dart';
import '../models/scenario.dart';

/// Service for handling text-to-speech narration of verses and scenarios
/// Provides voice control, speed adjustment, and smart playback features
class NarrationService extends ChangeNotifier {
  static final NarrationService _instance = NarrationService._internal();
  factory NarrationService() => _instance;
  NarrationService._internal();

  static NarrationService get instance => _instance;

  FlutterTts? _tts;
  bool _isInitialized = false;
  bool _isPlaying = false;
  bool _isPaused = false;
  double _speechRate = 1.0;
  double _speechPitch = 1.0;
  double _volume = 0.8;
  String? _currentLanguage;
  List<dynamic> _availableVoices = [];

  // Current narration state
  String? _currentText;
  String? _currentId; // verse ID or scenario title
  
  // Getters
  bool get isInitialized => _isInitialized;
  bool get isPlaying => _isPlaying;
  bool get isPaused => _isPaused;
  double get speechRate => _speechRate;
  double get speechPitch => _speechPitch;
  double get volume => _volume;
  String? get currentLanguage => _currentLanguage;
  List<dynamic> get availableVoices => _availableVoices;
  String? get currentText => _currentText;
  String? get currentId => _currentId;

  /// Initialize the TTS service
  Future<void> initialize() async {
    if (_isInitialized) return;

    try {
      _tts = FlutterTts();
      
      // Set up TTS callbacks
      _tts!.setStartHandler(() {
        _isPlaying = true;
        _isPaused = false;
        notifyListeners();
        debugPrint('🎤 TTS Started');
      });

      _tts!.setCompletionHandler(() {
        _isPlaying = false;
        _isPaused = false;
        _currentText = null;
        _currentId = null;
        notifyListeners();
        debugPrint('🎤 TTS Completed');
      });

      _tts!.setPauseHandler(() {
        _isPaused = true;
        _isPlaying = false;
        notifyListeners();
        debugPrint('🎤 TTS Paused');
      });

      _tts!.setContinueHandler(() {
        _isPaused = false;
        _isPlaying = true;
        notifyListeners();
        debugPrint('🎤 TTS Continued');
      });

      _tts!.setErrorHandler((message) {
        _isPlaying = false;
        _isPaused = false;
        debugPrint('❌ TTS Error: $message');
        notifyListeners();
      });

      // Initialize settings
      await _loadAvailableVoices();
      await _setDefaultSettings();

      _isInitialized = true;
      debugPrint('✅ NarrationService initialized');
      notifyListeners();
    } catch (e) {
      debugPrint('❌ Failed to initialize NarrationService: $e');
    }
  }

  /// Load available voices from the system
  Future<void> _loadAvailableVoices() async {
    try {
      _availableVoices = await _tts!.getVoices;
      
      // Try to find English voices
      final englishVoices = _availableVoices.where((voice) {
        final locale = voice['locale'] as String? ?? '';
        return locale.startsWith('en');
      }).toList();

      if (englishVoices.isNotEmpty) {
        final voice = englishVoices.first;
        _currentLanguage = voice['locale'];
        await _tts!.setVoice(voice);
        debugPrint('🎤 Set voice: ${voice['name']} (${voice['locale']})');
      }
    } catch (e) {
      debugPrint('⚠️ Failed to load voices: $e');
    }
  }

  /// Set default TTS settings
  Future<void> _setDefaultSettings() async {
    try {
      await _tts!.setSpeechRate(_speechRate);
      await _tts!.setPitch(_speechPitch);
      await _tts!.setVolume(_volume);
      await _tts!.setLanguage(_currentLanguage ?? 'en-US');
    } catch (e) {
      debugPrint('⚠️ Failed to set TTS defaults: $e');
    }
  }

  /// Play narration for a verse
  Future<bool> playVerse(Verse verse) async {
    if (!_isInitialized) {
      await initialize();
    }

    try {
      await stop(); // Stop any current playback
      
      final text = _formatVerseForSpeech(verse);
      _currentText = text;
      _currentId = '${verse.chapterId}.${verse.verseId}';
      
      await _tts!.speak(text);
      debugPrint('🎤 Playing verse ${verse.chapterId}.${verse.verseId}');
      return true;
    } catch (e) {
      debugPrint('❌ Failed to play verse: $e');
      return false;
    }
  }

  /// Play narration for a scenario
  Future<bool> playScenario(Scenario scenario) async {
    if (!_isInitialized) {
      await initialize();
    }

    try {
      await stop(); // Stop any current playback
      
      final text = _formatScenarioForSpeech(scenario);
      _currentText = text;
      _currentId = scenario.title;
      
      await _tts!.speak(text);
      debugPrint('🎤 Playing scenario: ${scenario.title}');
      return true;
    } catch (e) {
      debugPrint('❌ Failed to play scenario: $e');
      return false;
    }
  }

  /// Play custom text
  Future<bool> playText(String text, {String? id}) async {
    if (!_isInitialized) {
      await initialize();
    }

    try {
      await stop(); // Stop any current playback
      
      _currentText = text;
      _currentId = id;
      
      await _tts!.speak(text);
      debugPrint('🎤 Playing custom text');
      return true;
    } catch (e) {
      debugPrint('❌ Failed to play text: $e');
      return false;
    }
  }

  /// Pause current narration
  Future<void> pause() async {
    if (_isPlaying && _tts != null) {
      await _tts!.pause();
    }
  }

  /// Resume paused narration
  Future<void> resume() async {
    if (_isPaused && _tts != null) {
      // Note: FlutterTts doesn't have resume, we need to speak again
      if (_currentText != null) {
        await _tts!.speak(_currentText!);
      }
    }
  }

  /// Stop current narration
  Future<void> stop() async {
    if (_tts != null) {
      await _tts!.stop();
      _isPlaying = false;
      _isPaused = false;
      _currentText = null;
      _currentId = null;
      notifyListeners();
    }
  }

  /// Set speech rate (0.0 to 1.0)
  Future<void> setSpeechRate(double rate) async {
    if (_tts != null) {
      _speechRate = rate.clamp(0.1, 2.0);
      await _tts!.setSpeechRate(_speechRate);
      notifyListeners();
      debugPrint('🎤 Speech rate set to: $_speechRate');
    }
  }

  /// Set speech pitch (0.0 to 1.0) 
  Future<void> setSpeechPitch(double pitch) async {
    if (_tts != null) {
      _speechPitch = pitch.clamp(0.5, 2.0);
      await _tts!.setPitch(_speechPitch);
      notifyListeners();
      debugPrint('🎤 Speech pitch set to: $_speechPitch');
    }
  }

  /// Set volume (0.0 to 1.0)
  Future<void> setVolume(double volume) async {
    if (_tts != null) {
      _volume = volume.clamp(0.0, 1.0);
      await _tts!.setVolume(_volume);
      notifyListeners();
      debugPrint('🎤 Volume set to: $_volume');
    }
  }

  /// Set voice by index from available voices
  Future<void> setVoice(int voiceIndex) async {
    if (_tts != null && voiceIndex < _availableVoices.length) {
      final voice = _availableVoices[voiceIndex];
      await _tts!.setVoice(voice);
      _currentLanguage = voice['locale'];
      notifyListeners();
      debugPrint('🎤 Voice changed to: ${voice['name']}');
    }
  }

  /// Format verse text for natural speech
  String _formatVerseForSpeech(Verse verse) {
    final chapterText = verse.chapterId != null 
        ? 'Chapter ${verse.chapterId}, Verse ${verse.verseId}. ' 
        : 'Verse ${verse.verseId}. ';
    
    // Clean up the verse text for natural speech
    String cleanText = verse.description
        .replaceAll(RegExp(r'\s+'), ' ') // Normalize whitespace
        .replaceAll(RegExp(r'["""]'), '"') // Normalize quotes
        .trim();
    
    return '$chapterText$cleanText';
  }

  /// Format scenario text for natural speech
  String _formatScenarioForSpeech(Scenario scenario) {
    String text = '${scenario.title}. ${scenario.description}';
    
    // Clean up text for natural speech
    text = text
        .replaceAll(RegExp(r'\s+'), ' ') // Normalize whitespace
        .replaceAll(RegExp(r'["""]'), '"') // Normalize quotes
        .trim();
    
    return text;
  }

  /// Dispose of resources
  void dispose() {
    _tts?.stop();
    _isInitialized = false;
    debugPrint('🎤 NarrationService disposed');
    super.dispose();
  }
}