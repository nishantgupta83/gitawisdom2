// lib/services/enhanced_audio_service.dart

import 'package:flutter/foundation.dart';
import 'package:hive/hive.dart';
import 'narration_service.dart';
import 'background_music_service.dart';
import 'settings_service.dart';
import '../models/simple_meditation.dart' show MusicTheme;
import '../models/verse.dart';
import '../models/scenario.dart';

/// Enhanced audio service that coordinates narration and background music
/// Handles smart audio ducking and unified audio controls
class EnhancedAudioService extends ChangeNotifier {
  static final EnhancedAudioService _instance = EnhancedAudioService._internal();
  factory EnhancedAudioService() => _instance;
  EnhancedAudioService._internal();

  static EnhancedAudioService get instance => _instance;

  // Service instances - nullable to prevent late initialization errors
  NarrationService? _narrationService;
  BackgroundMusicService? _backgroundMusicService;

  bool _isInitialized = false;
  bool _narrationEnabled = true;
  bool _backgroundMusicEnabled = true;

  // Getters for service access with null safety
  NarrationService? get narration => _narrationService;
  BackgroundMusicService? get backgroundMusic => _backgroundMusicService;
  
  bool get isInitialized => _isInitialized;
  bool get narrationEnabled => _narrationEnabled;
  bool get backgroundMusicEnabled => _backgroundMusicEnabled;

  /// Initialize the enhanced audio service (lazy loading)
  Future<void> initialize() async {
    if (_isInitialized) return;

    try {
      // Initialize individual services lazily - don't auto-start
      _narrationService ??= NarrationService.instance;
      _backgroundMusicService ??= BackgroundMusicService.instance;

      // Load saved settings first (no audio initialization yet)
      await _loadSettings();

      // Set up narration listeners for smart ducking (with null check)
      _narrationService?.addListener(_onNarrationStateChanged);

      _isInitialized = true;
      debugPrint('✅ EnhancedAudioService initialized (lazy mode)');
      
      // Auto-start background music if enabled
      if (_backgroundMusicEnabled) {
        Future.delayed(const Duration(milliseconds: 500), () async {
          await startBackgroundMusic();
        });
      }
      
      notifyListeners();
    } catch (e) {
      debugPrint('❌ Failed to initialize EnhancedAudioService: $e');
    }
  }

  /// Initialize audio systems only when first needed
  Future<void> _ensureAudioInitialized() async {
    if ((_narrationService?.isInitialized ?? false) && (_backgroundMusicService?.isInitialized ?? false)) {
      return;
    }

    try {
      if (!(_narrationService?.isInitialized ?? false)) {
        await _narrationService?.initialize();
      }
      if (!(_backgroundMusicService?.isInitialized ?? false)) {
        await _backgroundMusicService?.initialize();
      }
      debugPrint('✅ Audio systems initialized on-demand');
    } catch (e) {
      debugPrint('❌ Failed to initialize audio systems: $e');
    }
  }

  /// Load audio settings from storage
  Future<void> _loadSettings() async {
    try {
      final box = Hive.box(SettingsService.boxName);
      _narrationEnabled = box.get('narration_enabled', defaultValue: true) as bool;
      _backgroundMusicEnabled = box.get('background_music_enabled', defaultValue: true) as bool;

      // Apply loaded settings
      await _backgroundMusicService?.setEnabled(_backgroundMusicEnabled);
      
      debugPrint('📚 Audio settings loaded - Narration: $_narrationEnabled, Music: $_backgroundMusicEnabled');
    } catch (e) {
      debugPrint('⚠️ Failed to load audio settings: $e');
    }
  }

  /// Save audio settings to storage
  Future<void> _saveSettings() async {
    try {
      final box = Hive.box(SettingsService.boxName);
      await box.put('narration_enabled', _narrationEnabled);
      await box.put('background_music_enabled', _backgroundMusicEnabled);
    } catch (e) {
      debugPrint('⚠️ Failed to save audio settings: $e');
    }
  }

  /// Handle narration state changes for smart ducking
  void _onNarrationStateChanged() {
    final narration = _narrationService;
    final backgroundMusic = _backgroundMusicService;
    
    if (narration?.isPlaying == true) {
      // Duck background music when narration starts
      backgroundMusic?.duck();
    } else if (narration?.isPlaying == false && narration?.isPaused == false) {
      // Unduck when narration stops (not just paused)
      backgroundMusic?.unduck();
    }
  }

  /// Play narration for a verse with smart audio management
  Future<bool> playVerseNarration(Verse verse) async {
    if (!_narrationEnabled) {
      debugPrint('🎤 Narration disabled - skipping verse playback');
      return false;
    }

    if (!_isInitialized) {
      await initialize();
    }

    // Initialize audio systems only when needed
    await _ensureAudioInitialized();

    try {
      final narration = _narrationService;
      if (narration == null) {
        debugPrint('❌ Narration service not initialized');
        return false;
      }
      
      final result = await narration?.playVerse(verse) ?? false;
      if (result) {
        debugPrint('🎤 Playing verse narration: ${verse.chapterId}.${verse.verseId}');
      }
      return result;
    } catch (e) {
      debugPrint('❌ Failed to play verse narration: $e');
      return false;
    }
  }

  /// Play narration for a scenario with smart audio management
  Future<bool> playScenarioNarration(Scenario scenario) async {
    if (!_narrationEnabled) {
      debugPrint('🎤 Narration disabled - skipping scenario playbook');
      return false;
    }

    if (!_isInitialized) {
      await initialize();
    }

    // Initialize audio systems only when needed
    await _ensureAudioInitialized();

    try {
      final narration = _narrationService;
      if (narration == null) {
        debugPrint('❌ Narration service not initialized');
        return false;
      }
      
      final result = await narration?.playScenario(scenario) ?? false;
      if (result) {
        debugPrint('🎤 Playing scenario narration: ${scenario.title}');
      }
      return result;
    } catch (e) {
      debugPrint('❌ Failed to play scenario narration: $e');
      return false;
    }
  }

  /// Start background music for reading/meditation
  Future<void> startBackgroundMusic() async {
    if (!_backgroundMusicEnabled) {
      debugPrint('🎵 Background music disabled - skipping start');
      return;
    }

    if (!_isInitialized) {
      await initialize();
    }

    // Initialize audio systems only when needed
    await _ensureAudioInitialized();
    final backgroundMusic = _backgroundMusicService;
    if (backgroundMusic != null) {
      await backgroundMusic.startMusic();
      debugPrint('🎵 Background music started');
    } else {
      debugPrint('❌ Background music service not initialized');
    }
  }

  /// Stop background music
  Future<void> stopBackgroundMusic() async {
    final backgroundMusic = _backgroundMusicService;
    if (backgroundMusic != null) {
      await backgroundMusic.stopMusic();
      debugPrint('🎵 Background music stopped');
    } else {
      debugPrint('❌ Background music service not initialized');
    }
  }

  /// Enable/disable narration
  Future<void> setNarrationEnabled(bool enabled) async {
    _narrationEnabled = enabled;
    
    final narration = _narrationService;
    if (!enabled && narration?.isPlaying == true) {
      await narration!.stop();
    }
    
    await _saveSettings();
    notifyListeners();
    debugPrint('🎤 Narration enabled: $enabled');
  }

  /// Enable/disable background music
  Future<void> setBackgroundMusicEnabled(bool enabled) async {
    _backgroundMusicEnabled = enabled;
    final backgroundMusic = _backgroundMusicService;
    if (backgroundMusic != null) {
      await backgroundMusic.setEnabled(enabled);
    } else {
      debugPrint('❌ Background music service not initialized for setEnabled');
    }
    await _saveSettings();
    notifyListeners();
    debugPrint('🎵 Background music enabled: $enabled');
  }

  /// Set background music theme
  Future<void> setMusicTheme(MusicTheme theme) async {
    final backgroundMusic = _backgroundMusicService;
    if (backgroundMusic != null) {
      await backgroundMusic.setTheme(theme);
      debugPrint('🎵 Music theme changed: $theme');
    } else {
      debugPrint('❌ Background music service not initialized for theme');
    }
  }

  /// Set narration speech rate
  Future<void> setNarrationSpeed(double rate) async {
    final narration = _narrationService;
    if (narration != null) {
      await narration?.setSpeechRate(rate);
      debugPrint('🎤 Narration speed: $rate');
    } else {
      debugPrint('❌ Narration service not initialized for speed');
    }
  }

  /// Set narration volume
  Future<void> setNarrationVolume(double volume) async {
    final narration = _narrationService;
    if (narration != null) {
      await narration?.setVolume(volume);
      debugPrint('🎤 Narration volume: $volume');
    } else {
      debugPrint('❌ Narration service not initialized for volume');
    }
  }

  /// Set background music volume
  Future<void> setBackgroundMusicVolume(double volume) async {
    final backgroundMusic = _backgroundMusicService;
    if (backgroundMusic != null) {
      await backgroundMusic.setVolume(volume);
      debugPrint('🎵 Background music volume: $volume');
    } else {
      debugPrint('❌ Background music service not initialized for volume');
    }
  }

  /// Stop all audio (narration + background music)
  Future<void> stopAll() async {
    final narration = _narrationService;
    final backgroundMusic = _backgroundMusicService;
    
    if (narration != null) {
      await narration?.stop();
    }
    if (backgroundMusic != null) {
      await backgroundMusic.stopMusic();
    }
    debugPrint('🔇 All audio stopped');
  }

  /// Pause all audio
  Future<void> pauseAll() async {
    final narration = _narrationService;
    final backgroundMusic = _backgroundMusicService;
    
    if (narration != null) {
      await narration?.pause();
    }
    if (backgroundMusic != null) {
      await backgroundMusic.pauseMusic();
    }
    debugPrint('⏸️ All audio paused');
  }

  /// Resume all audio
  Future<void> resumeAll() async {
    final narration = _narrationService;
    final backgroundMusic = _backgroundMusicService;
    
    if (narration != null) {
      await narration?.resume();
    }
    if (_backgroundMusicEnabled && backgroundMusic != null) {
      await backgroundMusic.resumeMusic();
    }
    debugPrint('▶️ All audio resumed');
  }

  /// Get current playback status
  Map<String, dynamic> getStatus() {
    final narration = _narrationService;
    final backgroundMusic = _backgroundMusicService;
    
    return {
      'initialized': _isInitialized,
      'narrationEnabled': _narrationEnabled,
      'backgroundMusicEnabled': _backgroundMusicEnabled,
      'narrationPlaying': narration?.isPlaying ?? false,
      'backgroundMusicPlaying': backgroundMusic?.isPlaying ?? false,
      'currentNarration': narration?.currentId,
      'musicTheme': backgroundMusic?.currentTheme,
      'isDucking': backgroundMusic?.isDucking ?? false,
    };
  }

  /// Dispose of resources
  @override
  void dispose() {
    final narration = _narrationService;
    final backgroundMusic = _backgroundMusicService;
    
    if (narration != null) {
      narration?.removeListener(_onNarrationStateChanged);
      narration?.dispose();
    }
    if (backgroundMusic != null) {
      backgroundMusic.dispose();
    }
    
    _isInitialized = false;
    debugPrint('🔇 EnhancedAudioService disposed');
    super.dispose();
  }
}