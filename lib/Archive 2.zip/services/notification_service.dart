// lib/services/notification_service.dart

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:permission_handler/permission_handler.dart';
import 'dart:math';
import 'scenario_service.dart';
import '../models/scenario.dart';

/// Notification service for daily verses and progress reminders
class NotificationService extends ChangeNotifier {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  final FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();

  bool _isInitialized = false;
  bool _notificationsEnabled = false;
  bool _dailyVerseEnabled = true;
  bool _dailyDilemmaEnabled = true; // NEW: Daily dilemma notifications
  bool _streakRemindersEnabled = true;
  bool _achievementNotificationsEnabled = true;

  // Notification IDs
  static const int dailyVerseNotificationId = 1000;
  static const int dailyDilemmaNotificationId = 1004; // NEW: Daily dilemma ID
  static const int streakReminderNotificationId = 1001;
  static const int achievementNotificationId = 1002;

  // Default notification times
  int _dailyVerseHour = 8;
  int _dailyVerseMinute = 0;
  int _dailyDilemmaHour = 12; // NEW: Noon for dilemmas
  int _dailyDilemmaMinute = 0;
  int _streakReminderHour = 20;
  int _streakReminderMinute = 0;

  // Getters
  bool get isInitialized => _isInitialized;
  bool get notificationsEnabled => _notificationsEnabled;
  bool get dailyVerseEnabled => _dailyVerseEnabled;
  bool get dailyDilemmaEnabled => _dailyDilemmaEnabled; // NEW
  bool get streakRemindersEnabled => _streakRemindersEnabled;
  bool get achievementNotificationsEnabled => _achievementNotificationsEnabled;
  int get dailyVerseHour => _dailyVerseHour;
  int get dailyVerseMinute => _dailyVerseMinute;
  int get dailyDilemmaHour => _dailyDilemmaHour; // NEW
  int get dailyDilemmaMinute => _dailyDilemmaMinute; // NEW
  int get streakReminderHour => _streakReminderHour;
  int get streakReminderMinute => _streakReminderMinute;

  /// Initialize notification service
  Future<void> initialize() async {
    try {
      // Android initialization settings
      const AndroidInitializationSettings initializationSettingsAndroid =
          AndroidInitializationSettings('@mipmap/ic_launcher');

      // iOS initialization settings
      const DarwinInitializationSettings initializationSettingsIOS =
          DarwinInitializationSettings(
        requestAlertPermission: true,
        requestBadgePermission: true,
        requestSoundPermission: true,
      );

      const InitializationSettings initializationSettings =
          InitializationSettings(
        android: initializationSettingsAndroid,
        iOS: initializationSettingsIOS,
      );

      await _flutterLocalNotificationsPlugin.initialize(
        initializationSettings,
        onDidReceiveNotificationResponse: _onDidReceiveNotificationResponse,
      );

      // Request permissions
      _notificationsEnabled = await _requestPermissions();
      _isInitialized = true;
      
      if (_notificationsEnabled) {
        await _scheduleDefaultNotifications();
      }

      notifyListeners();
    } catch (e) {
      if (kDebugMode) print('Failed to initialize notifications: $e');
      _isInitialized = false;
    }
  }

  /// Request notification permissions
  Future<bool> _requestPermissions() async {
    try {
      final status = await Permission.notification.request();
      
      if (status.isGranted) {
        return true;
      } else if (status.isDenied) {
        // Show dialog to explain why we need permissions
        return false;
      } else if (status.isPermanentlyDenied) {
        // Direct user to settings
        await openAppSettings();
        return false;
      }
      
      return false;
    } catch (e) {
      if (kDebugMode) print('Permission request error: $e');
      return false;
    }
  }

  /// Handle notification taps
  void _onDidReceiveNotificationResponse(NotificationResponse response) {
    if (kDebugMode) print('Notification tapped: ${response.payload}');
    
    final payload = response.payload;
    if (payload != null) {
      // Handle different notification types
      if (payload.contains('daily_verse')) {
        // Navigate to daily verse or home screen
      } else if (payload.contains('daily_dilemma')) {
        // Navigate to scenarios screen or specific scenario
        if (payload.contains(':')) {
          final scenarioHash = payload.split(':')[1];
          // Navigate to specific scenario based on hash
        } else {
          // Navigate to scenarios screen
        }
      } else if (payload.contains('streak_reminder')) {
        // Navigate to progress screen
      } else if (payload.contains('achievement')) {
        // Navigate to achievements
      }
    }
  }

  /// Schedule daily verse notification
  Future<void> scheduleDailyVerseNotification() async {
    if (!_isInitialized || !_notificationsEnabled || !_dailyVerseEnabled) return;

    try {
      // Cancel existing daily verse notifications
      await _flutterLocalNotificationsPlugin.cancel(dailyVerseNotificationId);

      // Schedule new daily notification
      await _flutterLocalNotificationsPlugin.zonedSchedule(
        dailyVerseNotificationId,
        'Daily Gita Wisdom 🕉️',
        'Discover today\'s verse for guidance and inspiration',
        _nextInstanceOfTime(_dailyVerseHour, _dailyVerseMinute),
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'daily_verse',
            'Daily Verse',
            channelDescription: 'Daily verse from Bhagavad Gita',
            importance: Importance.high,
            priority: Priority.high,
            icon: '@mipmap/ic_launcher',
            color: const Color(0xFF6750A4),
          ),
          iOS: DarwinNotificationDetails(
            categoryIdentifier: 'daily_verse',
            threadIdentifier: 'daily_verse',
          ),
        ),
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        matchDateTimeComponents: DateTimeComponents.time,
        payload: 'daily_verse',
      );

      if (kDebugMode) {
        print('Daily verse notification scheduled for ${_dailyVerseHour}:${_dailyVerseMinute.toString().padLeft(2, '0')}');
      }
    } catch (e) {
      if (kDebugMode) print('Failed to schedule daily verse notification: $e');
    }
  }

  /// Schedule daily dilemma notification with random scenario
  Future<void> scheduleDailyDilemmaNotification() async {
    if (!_isInitialized || !_notificationsEnabled || !_dailyDilemmaEnabled) return;

    try {
      // Cancel existing daily dilemma notifications
      await _flutterLocalNotificationsPlugin.cancel(dailyDilemmaNotificationId);

      // Get a random scenario for the notification
      final scenario = await _getRandomScenarioForNotification();
      final title = scenario != null
          ? '🎭 Daily Dilemma: ${scenario.title}'
          : '🎭 Daily Dilemma Awaits';
      final body = scenario != null
          ? 'Heart vs Duty: ${scenario.description.length > 60 ? "${scenario.description.substring(0, 57)}..." : scenario.description}'
          : 'Explore today\'s moral dilemma and find your guidance';

      // Schedule new daily dilemma notification
      await _flutterLocalNotificationsPlugin.zonedSchedule(
        dailyDilemmaNotificationId,
        title,
        body,
        _nextInstanceOfTime(_dailyDilemmaHour, _dailyDilemmaMinute),
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'daily_dilemma',
            'Daily Dilemma',
            channelDescription: 'Daily moral dilemmas from real life scenarios',
            importance: Importance.high,
            priority: Priority.high,
            icon: '@mipmap/ic_launcher',
            color: Color(0xFF9C27B0), // Purple for dilemmas
            playSound: true,
          ),
          iOS: DarwinNotificationDetails(
            categoryIdentifier: 'daily_dilemma',
            threadIdentifier: 'daily_dilemma',
            sound: 'default',
          ),
        ),
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        matchDateTimeComponents: DateTimeComponents.time,
        payload: scenario != null ? 'daily_dilemma:${scenario.hashCode}' : 'daily_dilemma',
      );

      if (kDebugMode) {
        print('Daily dilemma notification scheduled for ${_dailyDilemmaHour}:${_dailyDilemmaMinute.toString().padLeft(2, '0')}');
        if (scenario != null) {
          print('Scenario: ${scenario.title}');
        }
      }
    } catch (e) {
      if (kDebugMode) print('Failed to schedule daily dilemma notification: $e');
    }
  }

  /// Get a random scenario for notification
  Future<Scenario?> _getRandomScenarioForNotification() async {
    try {
      // Ensure scenario service is initialized
      if (!ScenarioService.instance.hasScenarios) {
        await ScenarioService.instance.initialize();
        // Try to load scenarios if they're not available
        final scenarios = await ScenarioService.instance.getAllScenarios();
        if (scenarios.isEmpty) {
          return null;
        }
      }

      // Get a random scenario from popular categories
      final preferredCategories = [
        'work', 'family', 'relationships', 'career', 'personal growth',
        'ethics', 'friendship', 'parenting', 'health', 'social'
      ];

      final scenarios = ScenarioService.instance.fetchScenariosByCategories(
        preferredCategories,
        limit: 20
      );

      if (scenarios.isNotEmpty) {
        return scenarios[Random().nextInt(scenarios.length)];
      }

      // Fallback: get any random scenario
      return ScenarioService.instance.getRandomScenario();
    } catch (e) {
      if (kDebugMode) print('Error getting random scenario for notification: $e');
      return null;
    }
  }

  /// Schedule streak reminder notification
  Future<void> scheduleStreakReminderNotification() async {
    if (!_isInitialized || !_notificationsEnabled || !_streakRemindersEnabled) return;

    try {
      // Cancel existing streak reminder notifications
      await _flutterLocalNotificationsPlugin.cancel(streakReminderNotificationId);

      // Schedule new streak reminder
      await _flutterLocalNotificationsPlugin.zonedSchedule(
        streakReminderNotificationId,
        'Keep Your Reading Streak! 🔥',
        'Don\'t break your streak. Read a verse today!',
        _nextInstanceOfTime(_streakReminderHour, _streakReminderMinute),
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'streak_reminder',
            'Reading Streak',
            channelDescription: 'Reminders to maintain reading streak',
            importance: Importance.high,
            priority: Priority.high,
            icon: '@mipmap/ic_launcher',
            color: const Color(0xFFFF5722),
          ),
          iOS: DarwinNotificationDetails(
            categoryIdentifier: 'streak_reminder',
            threadIdentifier: 'streak_reminder',
          ),
        ),
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        matchDateTimeComponents: DateTimeComponents.time,
        payload: 'streak_reminder',
      );

      if (kDebugMode) {
        print('Streak reminder scheduled for ${_streakReminderHour}:${_streakReminderMinute.toString().padLeft(2, '0')}');
      }
    } catch (e) {
      if (kDebugMode) print('Failed to schedule streak reminder: $e');
    }
  }

  /// Show achievement notification immediately
  Future<void> showAchievementNotification({
    required String title,
    required String description,
    String? payload,
  }) async {
    if (!_isInitialized || !_notificationsEnabled || !_achievementNotificationsEnabled) return;

    try {
      await _flutterLocalNotificationsPlugin.show(
        achievementNotificationId + Random().nextInt(1000), // Unique ID for each achievement
        '🏆 Achievement Unlocked!',
        '$title - $description',
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'achievements',
            'Achievements',
            channelDescription: 'Achievement unlock notifications',
            importance: Importance.high,
            priority: Priority.high,
            icon: '@mipmap/ic_launcher',
            color: const Color(0xFFFFD700),
            playSound: true,
          ),
          iOS: DarwinNotificationDetails(
            categoryIdentifier: 'achievement',
            threadIdentifier: 'achievement',
            sound: 'default',
          ),
        ),
        payload: payload ?? 'achievement:$title',
      );
    } catch (e) {
      if (kDebugMode) print('Failed to show achievement notification: $e');
    }
  }

  /// Show motivational quote notification
  Future<void> showMotivationalNotification() async {
    if (!_isInitialized || !_notificationsEnabled) return;

    final quotes = [
      'The soul is neither born, nor does it die. - Bhagavad Gita 2.20',
      'You have the right to perform your actions, but not to the fruits of action. - Bhagavad Gita 2.47',
      'A person can rise through the efforts of his own mind. - Bhagavad Gita 6.5',
      'The wise sees knowledge and action as one. - Bhagavad Gita 4.18',
      'What is not real, never was and never will be. - Bhagavad Gita 2.16',
    ];

    final randomQuote = quotes[Random().nextInt(quotes.length)];

    try {
      await _flutterLocalNotificationsPlugin.show(
        1003,
        'Wisdom from the Gita ✨',
        randomQuote,
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'motivation',
            'Motivation',
            channelDescription: 'Motivational quotes and wisdom',
            importance: Importance.defaultImportance,
            priority: Priority.defaultPriority,
            icon: '@mipmap/ic_launcher',
            color: const Color(0xFF4CAF50),
          ),
          iOS: DarwinNotificationDetails(
            categoryIdentifier: 'motivation',
            threadIdentifier: 'motivation',
          ),
        ),
        payload: 'motivation',
      );
    } catch (e) {
      if (kDebugMode) print('Failed to show motivational notification: $e');
    }
  }

  /// Update notification settings
  Future<void> updateSettings({
    bool? dailyVerseEnabled,
    bool? dailyDilemmaEnabled, // NEW
    bool? streakRemindersEnabled,
    bool? achievementNotificationsEnabled,
    int? dailyVerseHour,
    int? dailyVerseMinute,
    int? dailyDilemmaHour, // NEW
    int? dailyDilemmaMinute, // NEW
    int? streakReminderHour,
    int? streakReminderMinute,
  }) async {
    bool shouldReschedule = false;

    if (dailyVerseEnabled != null) {
      _dailyVerseEnabled = dailyVerseEnabled;
      shouldReschedule = true;
    }

    if (dailyDilemmaEnabled != null) { // NEW
      _dailyDilemmaEnabled = dailyDilemmaEnabled;
      shouldReschedule = true;
    }

    if (streakRemindersEnabled != null) {
      _streakRemindersEnabled = streakRemindersEnabled;
      shouldReschedule = true;
    }

    if (achievementNotificationsEnabled != null) {
      _achievementNotificationsEnabled = achievementNotificationsEnabled;
    }

    if (dailyVerseHour != null && dailyVerseMinute != null) {
      _dailyVerseHour = dailyVerseHour;
      _dailyVerseMinute = dailyVerseMinute;
      shouldReschedule = true;
    }

    if (dailyDilemmaHour != null && dailyDilemmaMinute != null) { // NEW
      _dailyDilemmaHour = dailyDilemmaHour;
      _dailyDilemmaMinute = dailyDilemmaMinute;
      shouldReschedule = true;
    }

    if (streakReminderHour != null && streakReminderMinute != null) {
      _streakReminderHour = streakReminderHour;
      _streakReminderMinute = streakReminderMinute;
      shouldReschedule = true;
    }

    if (shouldReschedule) {
      await _scheduleDefaultNotifications();
    }

    notifyListeners();
  }

  /// Schedule default notifications
  Future<void> _scheduleDefaultNotifications() async {
    if (_dailyVerseEnabled) {
      await scheduleDailyVerseNotification();
    }

    if (_dailyDilemmaEnabled) { // NEW
      await scheduleDailyDilemmaNotification();
    }

    if (_streakRemindersEnabled) {
      await scheduleStreakReminderNotification();
    }
  }

  /// Calculate next instance of specific time
  tz.TZDateTime _nextInstanceOfTime(int hour, int minute) {
    final tz.TZDateTime now = tz.TZDateTime.now(tz.local);
    tz.TZDateTime scheduledDate = tz.TZDateTime(
      tz.local,
      now.year,
      now.month,
      now.day,
      hour,
      minute,
    );

    if (scheduledDate.isBefore(now)) {
      scheduledDate = scheduledDate.add(const Duration(days: 1));
    }

    return scheduledDate;
  }

  /// Cancel all notifications
  Future<void> cancelAllNotifications() async {
    await _flutterLocalNotificationsPlugin.cancelAll();
  }

  /// Cancel specific notification
  Future<void> cancelNotification(int id) async {
    await _flutterLocalNotificationsPlugin.cancel(id);
  }

  /// Get pending notifications (for debugging)
  Future<List<PendingNotificationRequest>> getPendingNotifications() async {
    return await _flutterLocalNotificationsPlugin.pendingNotificationRequests();
  }

  /// Enable notifications after permission granted
  Future<void> enableNotifications() async {
    _notificationsEnabled = true;
    await _scheduleDefaultNotifications();
    notifyListeners();
  }

  /// Disable all notifications
  Future<void> disableNotifications() async {
    _notificationsEnabled = false;
    await cancelAllNotifications();
    notifyListeners();
  }
}