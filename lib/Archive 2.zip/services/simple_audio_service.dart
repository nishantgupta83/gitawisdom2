// Simple audio service for meditation timer
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';

class SimpleAudioService {
  static final SimpleAudioService _instance = SimpleAudioService._internal();
  factory SimpleAudioService() => _instance;
  SimpleAudioService._internal();

  AudioPlayer? _player;
  bool _isInitialized = false;

  Future<void> initialize() async {
    if (_isInitialized) return;

    try {
      _player = AudioPlayer();
      _isInitialized = true;
      debugPrint('✅ Simple audio service initialized');
    } catch (e) {
      debugPrint('❌ Simple audio service initialization failed: $e');
    }
  }

  Future<bool> play(String assetPath) async {
    if (!_isInitialized || _player == null) {
      await initialize();
    }

    try {
      await _player!.setAsset(assetPath);
      await _player!.setLoopMode(LoopMode.one);
      await _player!.setVolume(0.3);
      await _player!.play();
      debugPrint('🎵 Playing: $assetPath');
      return true;
    } catch (e) {
      debugPrint('❌ Audio playback failed: $e');
      debugPrint('ℹ️ Continuing meditation without background music');
      return false;
    }
  }

  Future<void> pause() async {
    if (_player != null) {
      await _player!.pause();
      debugPrint('⏸️ Audio paused');
    }
  }

  Future<void> resume() async {
    if (_player != null) {
      await _player!.play();
      debugPrint('▶️ Audio resumed');
    }
  }

  Future<void> stop() async {
    if (_player != null) {
      await _player!.stop();
      debugPrint('⏹️ Audio stopped');
    }
  }

  void dispose() {
    _player?.dispose();
    _player = null;
    _isInitialized = false;
  }
}