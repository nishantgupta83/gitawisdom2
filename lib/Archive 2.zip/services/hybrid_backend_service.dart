// lib/services/hybrid_backend_service.dart
import 'package:shared_preferences/shared_preferences.dart';
import '../models/chapter.dart';
import '../models/scenario.dart';
import '../models/verse.dart';
import '../models/journal_entry.dart';
import '../models/daily_practice.dart';
import 'firebase_service.dart';
import 'supabase_service.dart';

/// Hybrid backend service that can switch between Firebase and Supabase
/// during the migration process with feature flags and A/B testing
class HybridBackendService {
  static const String _backendPreferenceKey = 'preferred_backend';
  static const String _migrationStatusKey = 'migration_status';
  
  // Backend types
  static const String backendFirebase = 'firebase';
  static const String backendSupabase = 'supabase';
  
  // Migration phases
  static const String migrationNotStarted = 'not_started';
  static const String migrationInProgress = 'in_progress';
  static const String migrationCompleted = 'completed';
  
  // Feature flag percentages for gradual rollout
  static const Map<String, int> rolloutPercentages = {
    'phase1': 10,  // 10% of users
    'phase2': 25,  // 25% of users
    'phase3': 50,  // 50% of users
    'phase4': 100, // All users
  };
  
  static String _currentBackend = backendSupabase;
  static String _migrationPhase = 'phase1';
  
  // ==========================================
  // INITIALIZATION & BACKEND SELECTION
  // ==========================================
  
  static Future<void> initialize() async {
    await _loadPreferences();
    await _determineBackend();
  }
  
  static Future<void> _loadPreferences() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      _currentBackend = prefs.getString(_backendPreferenceKey) ?? backendSupabase;
      
      // Check if user has manually set preference
      if (prefs.containsKey(_backendPreferenceKey)) {
        print('🎯 Using saved backend preference: $_currentBackend');
        return;
      }
    } catch (e) {
      print('⚠️ Failed to load backend preferences: $e');
    }
  }
  
  static Future<void> _determineBackend() async {
    try {
      // Check if we're in a specific migration phase
      final migrationStatus = await getMigrationStatus();
      
      if (migrationStatus == migrationCompleted) {
        _currentBackend = backendFirebase;
        print('✅ Migration completed - using Firebase');
        return;
      }
      
      if (migrationStatus == migrationNotStarted) {
        _currentBackend = backendSupabase;
        print('📱 Migration not started - using Supabase');
        return;
      }
      
      // Migration in progress - use A/B testing
      final shouldUseFirebase = _shouldUseFirebaseForUser();
      _currentBackend = shouldUseFirebase ? backendFirebase : backendSupabase;
      
      print('🧪 A/B testing - using $_currentBackend (phase: $_migrationPhase)');
      
    } catch (e) {
      print('⚠️ Backend determination failed, defaulting to Supabase: $e');
      _currentBackend = backendSupabase;
    }
  }
  
  static bool _shouldUseFirebaseForUser() {
    // Simple hash-based A/B testing
    final userId = DateTime.now().millisecondsSinceEpoch.toString();
    final hash = userId.hashCode.abs();
    final percentage = hash % 100;
    
    final rolloutPercentage = rolloutPercentages[_migrationPhase] ?? 0;
    return percentage < rolloutPercentage;
  }
  
  // ==========================================
  // BACKEND CONTROL
  // ==========================================
  
  static String get currentBackend => _currentBackend;
  
  static Future<void> setBackend(String backend, {bool persistent = false}) async {
    if (backend != backendFirebase && backend != backendSupabase) {
      throw ArgumentError('Invalid backend: $backend');
    }
    
    _currentBackend = backend;
    
    if (persistent) {
      try {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString(_backendPreferenceKey, backend);
        print('💾 Backend preference saved: $backend');
      } catch (e) {
        print('⚠️ Failed to save backend preference: $e');
      }
    }
    
    print('🔄 Backend switched to: $backend');
  }
  
  static Future<void> setMigrationPhase(String phase) async {
    if (!rolloutPercentages.containsKey(phase)) {
      throw ArgumentError('Invalid migration phase: $phase');
    }
    
    _migrationPhase = phase;
    await _determineBackend();
    print('📊 Migration phase set to: $phase (${rolloutPercentages[phase]}% rollout)');
  }
  
  static Future<void> resetBackendPreference() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_backendPreferenceKey);
      await _determineBackend();
      print('🔄 Backend preference reset');
    } catch (e) {
      print('⚠️ Failed to reset backend preference: $e');
    }
  }
  
  // ==========================================
  // MIGRATION STATUS
  // ==========================================
  
  static Future<String> getMigrationStatus() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getString(_migrationStatusKey) ?? migrationNotStarted;
    } catch (e) {
      return migrationNotStarted;
    }
  }
  
  static Future<void> setMigrationStatus(String status) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_migrationStatusKey, status);
      print('📊 Migration status updated: $status');
    } catch (e) {
      print('⚠️ Failed to update migration status: $e');
    }
  }
  
  // ==========================================
  // CHAPTERS API
  // ==========================================
  
  static Future<List<Chapter>> getChapters() async {
    final stopwatch = Stopwatch()..start();
    
    try {
      final chapters = _currentBackend == backendFirebase
          ? await FirebaseService.getChapters()
          : await SupabaseService.getChapters();
      
      stopwatch.stop();
      await _logPerformanceMetric('getChapters', stopwatch.elapsedMilliseconds);
      
      return chapters;
    } catch (e) {
      stopwatch.stop();
      await _logError('getChapters', e.toString());
      
      // Fallback to other backend
      return await _fallbackOperation(() async {
        if (_currentBackend == backendFirebase) {
          return await SupabaseService.getChapters();
        } else {
          return await FirebaseService.getChapters();
        }
      }, 'getChapters');
    }
  }
  
  static Future<Chapter?> getChapter(int chapterId) async {
    final stopwatch = Stopwatch()..start();
    
    try {
      final chapter = _currentBackend == backendFirebase
          ? await FirebaseService.getChapter(chapterId)
          : await SupabaseService.getChapter(chapterId);
      
      stopwatch.stop();
      await _logPerformanceMetric('getChapter', stopwatch.elapsedMilliseconds);
      
      return chapter;
    } catch (e) {
      stopwatch.stop();
      await _logError('getChapter', e.toString());
      
      return await _fallbackOperation(() async {
        if (_currentBackend == backendFirebase) {
          return await SupabaseService.getChapter(chapterId);
        } else {
          return await FirebaseService.getChapter(chapterId);
        }
      }, 'getChapter');
    }
  }
  
  // ==========================================
  // SCENARIOS API
  // ==========================================
  
  static Future<List<Scenario>> getAllScenarios({int? limit}) async {
    final stopwatch = Stopwatch()..start();
    
    try {
      final scenarios = _currentBackend == backendFirebase
          ? await FirebaseService.getAllScenarios(limit: limit)
          : await SupabaseService.getAllScenarios(limit: limit);
      
      stopwatch.stop();
      await _logPerformanceMetric('getAllScenarios', stopwatch.elapsedMilliseconds);
      
      return scenarios;
    } catch (e) {
      stopwatch.stop();
      await _logError('getAllScenarios', e.toString());
      
      return await _fallbackOperation(() async {
        if (_currentBackend == backendFirebase) {
          return await SupabaseService.getAllScenarios(limit: limit);
        } else {
          return await FirebaseService.getAllScenarios(limit: limit);
        }
      }, 'getAllScenarios');
    }
  }
  
  static Future<List<Scenario>> getScenariosByChapter(int chapter, {int? limit}) async {
    final stopwatch = Stopwatch()..start();
    
    try {
      final scenarios = _currentBackend == backendFirebase
          ? await FirebaseService.getScenariosByChapter(chapter, limit: limit)
          : await SupabaseService.getScenariosByChapter(chapter, limit: limit);
      
      stopwatch.stop();
      await _logPerformanceMetric('getScenariosByChapter', stopwatch.elapsedMilliseconds);
      
      return scenarios;
    } catch (e) {
      stopwatch.stop();
      await _logError('getScenariosByChapter', e.toString());
      
      return await _fallbackOperation(() async {
        if (_currentBackend == backendFirebase) {
          return await SupabaseService.getScenariosByChapter(chapter, limit: limit);
        } else {
          return await FirebaseService.getScenariosByChapter(chapter, limit: limit);
        }
      }, 'getScenariosByChapter');
    }
  }
  
  static Future<List<Scenario>> getScenariosByCategory(String category, {int? limit}) async {
    final stopwatch = Stopwatch()..start();
    
    try {
      final scenarios = _currentBackend == backendFirebase
          ? await FirebaseService.getScenariosByCategory(category, limit: limit)
          : await SupabaseService.getScenariosByCategory(category, limit: limit);
      
      stopwatch.stop();
      await _logPerformanceMetric('getScenariosByCategory', stopwatch.elapsedMilliseconds);
      
      return scenarios;
    } catch (e) {
      stopwatch.stop();
      await _logError('getScenariosByCategory', e.toString());
      
      return await _fallbackOperation(() async {
        if (_currentBackend == backendFirebase) {
          return await SupabaseService.getScenariosByCategory(category, limit: limit);
        } else {
          return await FirebaseService.getScenariosByCategory(category, limit: limit);
        }
      }, 'getScenariosByCategory');
    }
  }
  
  static Future<List<Scenario>> searchScenarios(String query, {int? limit}) async {
    final stopwatch = Stopwatch()..start();
    
    try {
      final scenarios = _currentBackend == backendFirebase
          ? await FirebaseService.searchScenarios(query, limit: limit)
          : await SupabaseService.searchScenarios(query, limit: limit);
      
      stopwatch.stop();
      await _logPerformanceMetric('searchScenarios', stopwatch.elapsedMilliseconds);
      
      return scenarios;
    } catch (e) {
      stopwatch.stop();
      await _logError('searchScenarios', e.toString());
      
      return await _fallbackOperation(() async {
        if (_currentBackend == backendFirebase) {
          return await SupabaseService.searchScenarios(query, limit: limit);
        } else {
          return await FirebaseService.searchScenarios(query, limit: limit);
        }
      }, 'searchScenarios');
    }
  }
  
  // ==========================================
  // VERSES API
  // ==========================================
  
  static Future<List<Verse>> getVersesByChapter(int chapterId) async {
    final stopwatch = Stopwatch()..start();
    
    try {
      final verses = _currentBackend == backendFirebase
          ? await FirebaseService.getVersesByChapter(chapterId)
          : await SupabaseService.getVersesByChapter(chapterId);
      
      stopwatch.stop();
      await _logPerformanceMetric('getVersesByChapter', stopwatch.elapsedMilliseconds);
      
      return verses;
    } catch (e) {
      stopwatch.stop();
      await _logError('getVersesByChapter', e.toString());
      
      return await _fallbackOperation(() async {
        if (_currentBackend == backendFirebase) {
          return await SupabaseService.getVersesByChapter(chapterId);
        } else {
          return await FirebaseService.getVersesByChapter(chapterId);
        }
      }, 'getVersesByChapter');
    }
  }
  
  static Future<List<Verse>> getTodaysVerses({int count = 3}) async {
    final stopwatch = Stopwatch()..start();
    
    try {
      final verses = _currentBackend == backendFirebase
          ? await FirebaseService.getRandomVerses(count: count)
          : await SupabaseService.getTodaysVerses(count: count);
      
      stopwatch.stop();
      await _logPerformanceMetric('getTodaysVerses', stopwatch.elapsedMilliseconds);
      
      return verses;
    } catch (e) {
      stopwatch.stop();
      await _logError('getTodaysVerses', e.toString());
      
      return await _fallbackOperation(() async {
        if (_currentBackend == backendFirebase) {
          return await SupabaseService.getTodaysVerses(count: count);
        } else {
          return await FirebaseService.getRandomVerses(count: count);
        }
      }, 'getTodaysVerses');
    }
  }
  
  // ==========================================
  // JOURNAL API (Firebase only - user-specific)
  // ==========================================
  
  static Future<void> addJournalEntry(JournalEntry entry) async {
    // Always use Firebase for user-specific data
    return await FirebaseService.addJournalEntry(entry);
  }
  
  static Future<List<JournalEntry>> getUserJournalEntries() async {
    // Always use Firebase for user-specific data
    return await FirebaseService.getUserJournalEntries();
  }
  
  static Future<void> updateJournalEntry(JournalEntry entry) async {
    return await FirebaseService.updateJournalEntry(entry);
  }
  
  static Future<void> deleteJournalEntry(String entryId) async {
    return await FirebaseService.deleteJournalEntry(entryId);
  }
  
  // ==========================================
  // DAILY PRACTICE API (Firebase only)
  // ==========================================
  
  static Future<void> saveDailyPractice(DailyChallenge challenge) async {
    return await FirebaseService.saveDailyPractice(challenge);
  }
  
  static Future<void> saveMeditationSession(MeditationSession session) async {
    return await FirebaseService.saveMeditationSession(session);
  }
  
  static Future<List<DailyChallenge>> getUserDailyPractices() async {
    return await FirebaseService.getUserDailyPractices();
  }
  
  static Future<List<MeditationSession>> getUserMeditationSessions() async {
    return await FirebaseService.getUserMeditationSessions();
  }
  
  // ==========================================
  // HEALTH CHECK & CONNECTION TESTING
  // ==========================================
  
  static Future<Map<String, dynamic>> testBothBackends() async {
    final results = <String, dynamic>{};
    
    // Test Firebase
    try {
      final firebaseStopwatch = Stopwatch()..start();
      await FirebaseService.testConnection();
      firebaseStopwatch.stop();
      
      results['firebase'] = {
        'status': 'success',
        'response_time': firebaseStopwatch.elapsedMilliseconds,
      };
    } catch (e) {
      results['firebase'] = {
        'status': 'error',
        'error': e.toString(),
      };
    }
    
    // Test Supabase
    try {
      final supabaseStopwatch = Stopwatch()..start();
      await SupabaseService.testConnection();
      supabaseStopwatch.stop();
      
      results['supabase'] = {
        'status': 'success',
        'response_time': supabaseStopwatch.elapsedMilliseconds,
      };
    } catch (e) {
      results['supabase'] = {
        'status': 'error',
        'error': e.toString(),
      };
    }
    
    results['current_backend'] = _currentBackend;
    results['migration_phase'] = _migrationPhase;
    results['timestamp'] = DateTime.now().toIso8601String();
    
    return results;
  }
  
  static Future<bool> testConnection() async {
    return _currentBackend == backendFirebase
        ? await FirebaseService.testConnection()
        : await SupabaseService.testConnection();
  }
  
  // ==========================================
  // FALLBACK & ERROR HANDLING
  // ==========================================
  
  static Future<T> _fallbackOperation<T>(Future<T> Function() operation, String operationName) async {
    try {
      final result = await operation();
      print('✅ Fallback successful for $operationName');
      return result;
    } catch (e) {
      print('❌ Fallback failed for $operationName: $e');
      rethrow;
    }
  }
  
  static Future<void> _logPerformanceMetric(String operation, int durationMs) async {
    try {
      // Log to current backend
      if (_currentBackend == backendFirebase) {
        await FirebaseService.logPerformanceMetric(operation, durationMs);
      }
      
      // Also store locally for analysis
      final prefs = await SharedPreferences.getInstance();
      final metricsKey = 'performance_metrics_${DateTime.now().toIso8601String().split('T')[0]}';
      final existingMetrics = prefs.getStringList(metricsKey) ?? [];
      
      existingMetrics.add('$operation:$durationMs:$_currentBackend:${DateTime.now().millisecondsSinceEpoch}');
      await prefs.setStringList(metricsKey, existingMetrics);
      
    } catch (e) {
      print('⚠️ Failed to log performance metric: $e');
    }
  }
  
  static Future<void> _logError(String operation, String error) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final errorsKey = 'errors_${DateTime.now().toIso8601String().split('T')[0]}';
      final existingErrors = prefs.getStringList(errorsKey) ?? [];
      
      existingErrors.add('$operation:$error:$_currentBackend:${DateTime.now().millisecondsSinceEpoch}');
      await prefs.setStringList(errorsKey, existingErrors);
      
    } catch (e) {
      print('⚠️ Failed to log error: $e');
    }
  }
  
  // ==========================================
  // ANALYTICS & REPORTING
  // ==========================================
  
  static Future<Map<String, dynamic>> getPerformanceReport() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final today = DateTime.now().toIso8601String().split('T')[0];
      final metricsKey = 'performance_metrics_$today';
      final errorsKey = 'errors_$today';
      
      final metrics = prefs.getStringList(metricsKey) ?? [];
      final errors = prefs.getStringList(errorsKey) ?? [];
      
      final firebaseMetrics = metrics.where((m) => m.contains(':firebase:')).toList();
      final supabaseMetrics = metrics.where((m) => m.contains(':supabase:')).toList();
      
      return {
        'date': today,
        'total_operations': metrics.length,
        'total_errors': errors.length,
        'firebase_operations': firebaseMetrics.length,
        'supabase_operations': supabaseMetrics.length,
        'current_backend': _currentBackend,
        'migration_phase': _migrationPhase,
        'avg_response_time_firebase': _calculateAverageResponseTime(firebaseMetrics),
        'avg_response_time_supabase': _calculateAverageResponseTime(supabaseMetrics),
      };
    } catch (e) {
      return {'error': e.toString()};
    }
  }
  
  static double _calculateAverageResponseTime(List<String> metrics) {
    if (metrics.isEmpty) return 0.0;
    
    final times = metrics.map((m) {
      final parts = m.split(':');
      return parts.length >= 2 ? int.tryParse(parts[1]) ?? 0 : 0;
    }).where((t) => t > 0).toList();
    
    if (times.isEmpty) return 0.0;
    
    return times.reduce((a, b) => a + b) / times.length;
  }
}