// lib/services/annotation_service.dart

import 'package:flutter/foundation.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../models/annotation.dart';

class AnnotationService extends ChangeNotifier {
  static const String _boxName = 'annotations';
  Box<Annotation>? _annotationBox;
  List<Annotation> _annotations = [];

  List<Annotation> get annotations => List.unmodifiable(_annotations);

  /// Initialize the annotation service
  Future<void> initialize() async {
    try {
      if (!Hive.isAdapterRegistered(5)) {
        Hive.registerAdapter(AnnotationAdapter());
      }
      
      _annotationBox = await Hive.openBox<Annotation>(_boxName);
      await _loadAnnotations();
      debugPrint('✅ AnnotationService initialized with ${_annotations.length} annotations');
    } catch (e) {
      debugPrint('❌ AnnotationService initialization failed: $e');
    }
  }

  /// Load all annotations from local storage
  Future<void> _loadAnnotations() async {
    if (_annotationBox == null) return;

    try {
      _annotations = _annotationBox!.values.toList()
        ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
      notifyListeners();
    } catch (e) {
      debugPrint('❌ Failed to load annotations: $e');
    }
  }

  /// Get annotations for a specific verse
  List<Annotation> getAnnotationsForVerse(String verseId) {
    return _annotations.where((annotation) => annotation.verseId == verseId).toList()
      ..sort((a, b) => a.startIndex.compareTo(b.startIndex));
  }

  /// Add a new annotation
  Future<bool> addAnnotation({
    required String verseId,
    required String selectedText,
    required int startIndex,
    required int endIndex,
    required String highlightColor,
    String? note,
  }) async {
    if (_annotationBox == null) return false;

    try {
      final now = DateTime.now();
      final annotation = Annotation(
        id: '${verseId}_${now.millisecondsSinceEpoch}',
        verseId: verseId,
        selectedText: selectedText,
        startIndex: startIndex,
        endIndex: endIndex,
        highlightColor: highlightColor,
        note: note,
        createdAt: now,
        updatedAt: now,
      );

      await _annotationBox!.put(annotation.id, annotation);
      _annotations.add(annotation);
      _annotations.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      
      notifyListeners();
      debugPrint('✅ Added annotation for verse $verseId');
      return true;
    } catch (e) {
      debugPrint('❌ Failed to add annotation: $e');
      return false;
    }
  }

  /// Update an existing annotation
  Future<bool> updateAnnotation({
    required String annotationId,
    String? highlightColor,
    String? note,
  }) async {
    if (_annotationBox == null) return false;

    try {
      final annotation = _annotationBox!.get(annotationId);
      if (annotation == null) return false;

      final updatedAnnotation = annotation.copyWith(
        highlightColor: highlightColor ?? annotation.highlightColor,
        note: note ?? annotation.note,
        updatedAt: DateTime.now(),
      );

      await _annotationBox!.put(annotationId, updatedAnnotation);
      
      final index = _annotations.indexWhere((a) => a.id == annotationId);
      if (index != -1) {
        _annotations[index] = updatedAnnotation;
        notifyListeners();
      }

      debugPrint('✅ Updated annotation $annotationId');
      return true;
    } catch (e) {
      debugPrint('❌ Failed to update annotation: $e');
      return false;
    }
  }

  /// Delete an annotation
  Future<bool> deleteAnnotation(String annotationId) async {
    if (_annotationBox == null) return false;

    try {
      await _annotationBox!.delete(annotationId);
      _annotations.removeWhere((annotation) => annotation.id == annotationId);
      
      notifyListeners();
      debugPrint('✅ Deleted annotation $annotationId');
      return true;
    } catch (e) {
      debugPrint('❌ Failed to delete annotation: $e');
      return false;
    }
  }

  /// Clear all annotations for a specific verse
  Future<bool> clearAnnotationsForVerse(String verseId) async {
    if (_annotationBox == null) return false;

    try {
      final verseAnnotations = getAnnotationsForVerse(verseId);
      for (final annotation in verseAnnotations) {
        await _annotationBox!.delete(annotation.id);
      }
      
      _annotations.removeWhere((annotation) => annotation.verseId == verseId);
      notifyListeners();
      
      debugPrint('✅ Cleared ${verseAnnotations.length} annotations for verse $verseId');
      return true;
    } catch (e) {
      debugPrint('❌ Failed to clear annotations for verse: $e');
      return false;
    }
  }

  /// Get total annotation count
  int get totalAnnotations => _annotations.length;

  /// Get annotation count for a specific verse
  int getAnnotationCountForVerse(String verseId) {
    return getAnnotationsForVerse(verseId).length;
  }

  /// Search annotations by text content
  List<Annotation> searchAnnotations(String query) {
    if (query.trim().isEmpty) return [];

    final lowerQuery = query.toLowerCase();
    return _annotations.where((annotation) {
      return annotation.selectedText.toLowerCase().contains(lowerQuery) ||
             (annotation.note?.toLowerCase().contains(lowerQuery) ?? false);
    }).toList();
  }

  /// Export annotations to JSON
  Map<String, dynamic> exportAnnotations() {
    return {
      'annotations': _annotations.map((a) => a.toJson()).toList(),
      'exportedAt': DateTime.now().toIso8601String(),
      'totalCount': _annotations.length,
    };
  }

  /// Import annotations from JSON
  Future<bool> importAnnotations(Map<String, dynamic> data) async {
    if (_annotationBox == null) return false;

    try {
      final annotationsList = data['annotations'] as List;
      int importedCount = 0;

      for (final annotationData in annotationsList) {
        final annotation = Annotation.fromJson(annotationData);
        
        // Check if annotation already exists
        if (!_annotations.any((a) => a.id == annotation.id)) {
          await _annotationBox!.put(annotation.id, annotation);
          _annotations.add(annotation);
          importedCount++;
        }
      }

      if (importedCount > 0) {
        _annotations.sort((a, b) => b.createdAt.compareTo(a.createdAt));
        notifyListeners();
        debugPrint('✅ Imported $importedCount new annotations');
      }

      return true;
    } catch (e) {
      debugPrint('❌ Failed to import annotations: $e');
      return false;
    }
  }
}