// lib/services/verse_audio_service.dart

import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import 'dart:async';
import 'enhanced_audio_service.dart';

/// Chapter-based audio service with verse-level control and background music coordination
class VerseAudioService extends ChangeNotifier {
  static final VerseAudioService _instance = VerseAudioService._internal();
  factory VerseAudioService() => _instance;
  VerseAudioService._internal();

  static VerseAudioService get instance => _instance;

  final AudioPlayer _player = AudioPlayer();
  final EnhancedAudioService _backgroundMusicService = EnhancedAudioService.instance;
  
  bool _isPlaying = false;
  bool _isLoading = false;
  String? _currentVerseId;
  double _currentSpeed = 1.0;
  String? _loadedChapterUrl;
  Timer? _verseEndTimer;
  bool _wasBackgroundMusicPlaying = false;

  bool get isPlaying => _isPlaying;
  bool get isLoading => _isLoading;
  String? get currentVerseId => _currentVerseId;
  double get currentSpeed => _currentSpeed;

  /// Initialize the audio service
  Future<void> initialize() async {
    try {
      // Listen to player state changes
      _player.playerStateStream.listen((state) {
        _isPlaying = state.playing;
        _isLoading = state.processingState == ProcessingState.loading ||
                     state.processingState == ProcessingState.buffering;
        notifyListeners();
      });
      
      // Listen to completion
      _player.playerStateStream.listen((state) {
        if (state.processingState == ProcessingState.completed) {
          _isPlaying = false;
          _currentVerseId = null;
          notifyListeners();
        }
      });

      debugPrint('✅ VerseAudioService initialized');
    } catch (e) {
      debugPrint('❌ Failed to initialize VerseAudioService: $e');
    }
  }

  /// Play specific verse using chapter-based audio with timestamps
  Future<bool> playVerse({
    required String verseId,
    required int chapterId,
    required int verseNumber,
  }) async {
    try {
      // Cancel any existing verse timer
      _verseEndTimer?.cancel();
      
      // Stop current playback if any
      if (_isPlaying) {
        await stop();
      }

      _isLoading = true;
      _currentVerseId = verseId;
      notifyListeners();

      // 1. PAUSE background music first
      final status = _backgroundMusicService.getStatus();
      if (status['backgroundMusicPlaying'] == true) {
        await _backgroundMusicService.stopBackgroundMusic();
        _wasBackgroundMusicPlaying = true;
        debugPrint('🎵 Background music paused for verse playback');
      }

      // 2. Get chapter audio data
      final chapterData = _getChapterAudioData(chapterId);
      if (chapterData == null) {
        debugPrint('⚠️ No chapter audio data for Chapter $chapterId');
        await _handleVersePlaybackError();
        return false;
      }

      final chapterUrl = chapterData['url'] as String;
      final verseTimingData = _getVerseTimingData(chapterId, verseNumber);
      
      if (verseTimingData == null) {
        debugPrint('⚠️ No timing data for Chapter $chapterId, Verse $verseNumber');
        await _handleVersePlaybackError();
        return false;
      }

      // 3. Load chapter audio if not already loaded
      if (_loadedChapterUrl != chapterUrl) {
        debugPrint('📖 Loading chapter $chapterId audio from Archive.org');
        await _player.setUrl(chapterUrl);
        _loadedChapterUrl = chapterUrl;
      }

      // 4. Seek to verse start position
      final startTime = Duration(seconds: verseTimingData['start']!);
      final duration = Duration(seconds: verseTimingData['duration']!);
      
      await _player.seek(startTime);
      await _player.play();

      // 5. Set up auto-stop timer for verse end
      _setupVerseEndTimer(duration);

      debugPrint('🎤 Playing verse $chapterId.$verseNumber from ${startTime.inSeconds}s for ${duration.inSeconds}s');
      return true;
    } catch (e) {
      debugPrint('❌ Failed to play verse audio: $e');
      await _handleVersePlaybackError();
      return false;
    }
  }

  /// Set up timer to auto-stop verse at the end
  void _setupVerseEndTimer(Duration verseDuration) {
    _verseEndTimer = Timer(verseDuration, () async {
      await _onVerseEnded();
    });
  }

  /// Handle verse playback completion
  Future<void> _onVerseEnded() async {
    debugPrint('🎤 Verse playback completed');
    await stop();
    
    // Resume background music if it was playing and setting is enabled
    if (_wasBackgroundMusicPlaying && _backgroundMusicService.backgroundMusicEnabled) {
      await _backgroundMusicService.startBackgroundMusic();
      debugPrint('🎵 Background music resumed after verse');
    }
    _wasBackgroundMusicPlaying = false;
  }

  /// Handle errors and restore background music state
  Future<void> _handleVersePlaybackError() async {
    _isLoading = false;
    _currentVerseId = null;
    
    // Restore background music if it was playing
    if (_wasBackgroundMusicPlaying && _backgroundMusicService.backgroundMusicEnabled) {
      await _backgroundMusicService.startBackgroundMusic();
      debugPrint('🎵 Background music restored after verse error');
    }
    _wasBackgroundMusicPlaying = false;
    notifyListeners();
  }

  /// Chapter-based audio mapping with verse timestamps
  /// Using Archive.org LibriVox recordings for reliable streaming
  static const Map<int, Map<String, dynamic>> _chapterAudioMap = {
    1: {
      'url': 'https://archive.org/download/bhagavad_gita_0803_librivox/bhagavadgita_01.mp3',
      'totalVerses': 47,
      'duration': 600, // 10 minutes estimated
      'verses': {
        // Chapter 1 - Arjuna's Dilemma (47 verses)
        // Estimated timestamps based on typical recitation pace
        1: {'start': 0, 'duration': 15},
        2: {'start': 15, 'duration': 12},
        3: {'start': 27, 'duration': 18},
        4: {'start': 45, 'duration': 14},
        5: {'start': 59, 'duration': 16},
        // Continue for all 47 verses...
        // For now, using calculated intervals
      }
    },
    2: {
      'url': 'https://archive.org/download/bhagavad_gita_0803_librivox/bhagavadgita_02.mp3',
      'totalVerses': 72,
      'duration': 1080, // 18 minutes estimated
      'verses': {
        // Chapter 2 - Sankhya Yoga (72 verses)
        1: {'start': 0, 'duration': 18},
        47: {'start': 720, 'duration': 20}, // Famous karma yoga verse
        62: {'start': 930, 'duration': 16}, // Contemplation verse
        70: {'start': 1050, 'duration': 18}, // Ocean analogy
        // Continue for all 72 verses...
      }
    },
    3: {
      'url': 'https://archive.org/download/bhagavad_gita_0803_librivox/bhagavadgita_03.mp3',
      'totalVerses': 43,
      'duration': 645, // 10:45 estimated
      'verses': {
        // Chapter 3 - Karma Yoga (43 verses)
        1: {'start': 0, 'duration': 15},
        21: {'start': 300, 'duration': 18}, // Leaders set examples
        27: {'start': 390, 'duration': 16}, // Actions by nature
      }
    },
    4: {
      'url': 'https://archive.org/download/bhagavad_gita_0803_librivox/bhagavadgita_04.mp3',
      'totalVerses': 42,
      'duration': 630, // 10:30 estimated
      'verses': {
        // Chapter 4 - Jnana Yoga (42 verses)
        1: {'start': 0, 'duration': 15},
        7: {'start': 90, 'duration': 20}, // Dharma declines
        8: {'start': 110, 'duration': 18}, // Protect good
        18: {'start': 255, 'duration': 16}, // Inaction in action
      }
    },
    5: {
      'url': 'https://archive.org/download/bhagavad_gita_0803_librivox/bhagavadgita_05.mp3',
      'totalVerses': 29,
      'duration': 435, // 7:15 estimated
      'verses': {
        1: {'start': 0, 'duration': 15},
        10: {'start': 135, 'duration': 18}, // Acting without attachment
        15: {'start': 210, 'duration': 16}, // Neither sin nor virtue
      }
    },
    // Continue for all 18 chapters...
    6: {
      'url': 'https://archive.org/download/bhagavad_gita_0803_librivox/bhagavadgita_06.mp3',
      'totalVerses': 47,
      'duration': 705,
      'verses': {
        1: {'start': 0, 'duration': 15},
        5: {'start': 60, 'duration': 18}, // Mind as friend/enemy
        17: {'start': 240, 'duration': 16}, // Moderate living
        35: {'start': 525, 'duration': 20}, // Restless mind
      }
    },
    7: {
      'url': 'https://archive.org/download/bhagavad_gita_0803_librivox/bhagavadgita_07.mp3',
      'totalVerses': 30,
      'duration': 450,
      'verses': {
        1: {'start': 0, 'duration': 15},
        19: {'start': 270, 'duration': 18}, // After many births
      }
    },
    8: {
      'url': 'https://archive.org/download/bhagavad_gita_0803_librivox/bhagavadgita_08.mp3',
      'totalVerses': 28,
      'duration': 420,
      'verses': {
        1: {'start': 0, 'duration': 15},
        7: {'start': 90, 'duration': 18}, // Remember me and fight
        22: {'start': 315, 'duration': 16}, // Supreme person
      }
    },
    // Complete all remaining chapters (9-18)
    9: {
      'url': 'https://archive.org/download/bhagavad_gita_0803_librivox/bhagavadgita_09.mp3',
      'totalVerses': 34,
      'duration': 510,
      'verses': {
        1: {'start': 0, 'duration': 15},
        22: {'start': 315, 'duration': 18}, // I provide for all needs
        26: {'start': 375, 'duration': 16}, // Offer leaf, flower, fruit
      }
    },
    10: {
      'url': 'https://archive.org/download/bhagavad_gita_0803_librivox/bhagavadgita_10.mp3',
      'totalVerses': 42,
      'duration': 630,
      'verses': {
        1: {'start': 0, 'duration': 15},
        8: {'start': 105, 'duration': 18}, // I am source of all
        20: {'start': 285, 'duration': 16}, // I am the Self in all beings
      }
    },
    11: {
      'url': 'https://archive.org/download/bhagavad_gita_0803_librivox/bhagavadgita_11.mp3',
      'totalVerses': 55,
      'duration': 825,
      'verses': {
        1: {'start': 0, 'duration': 15},
        7: {'start': 90, 'duration': 20}, // Behold the universal form
        32: {'start': 465, 'duration': 22}, // I am Time, destroyer of worlds
      }
    },
    12: {
      'url': 'https://archive.org/download/bhagavad_gita_0803_librivox/bhagavadgita_12.mp3',
      'totalVerses': 20,
      'duration': 300,
      'verses': {
        1: {'start': 0, 'duration': 15},
        13: {'start': 180, 'duration': 18}, // Free from hatred
        20: {'start': 285, 'duration': 15}, // Who follow this dharma
      }
    },
    13: {
      'url': 'https://archive.org/download/bhagavad_gita_0803_librivox/bhagavadgita_13.mp3',
      'totalVerses': 35,
      'duration': 525,
      'verses': {
        1: {'start': 0, 'duration': 15},
        2: {'start': 15, 'duration': 18}, // Know Me as the knower
        24: {'start': 345, 'duration': 16}, // Who know Purusa and Prakrti
      }
    },
    14: {
      'url': 'https://archive.org/download/bhagavad_gita_0803_librivox/bhagavadgita_14.mp3',
      'totalVerses': 27,
      'duration': 405,
      'verses': {
        1: {'start': 0, 'duration': 15},
        4: {'start': 45, 'duration': 18}, // I am father giving seed
        26: {'start': 375, 'duration': 16}, // Unwavering devotion
      }
    },
    15: {
      'url': 'https://archive.org/download/bhagavad_gita_0803_librivox/bhagavadgita_15.mp3',
      'totalVerses': 20,
      'duration': 300,
      'verses': {
        1: {'start': 0, 'duration': 15},
        7: {'start': 90, 'duration': 18}, // Eternal fragment of myself
        15: {'start': 210, 'duration': 16}, // Seated in everyone's heart
      }
    },
    16: {
      'url': 'https://archive.org/download/bhagavad_gita_0803_librivox/bhagavadgita_16.mp3',
      'totalVerses': 24,
      'duration': 360,
      'verses': {
        1: {'start': 0, 'duration': 15},
        21: {'start': 300, 'duration': 18}, // Triple gate of hell
      }
    },
    17: {
      'url': 'https://archive.org/download/bhagavad_gita_0803_librivox/bhagavadgita_17.mp3',
      'totalVerses': 28,
      'duration': 420,
      'verses': {
        1: {'start': 0, 'duration': 15},
        3: {'start': 30, 'duration': 18}, // Faith according to nature
        23: {'start': 330, 'duration': 16}, // Om Tat Sat designation
      }
    },
    18: {
      'url': 'https://archive.org/download/bhagavad_gita_0803_librivox/bhagavadgita_18.mp3',
      'totalVerses': 78,
      'duration': 1170, // 19:30 estimated (longest chapter)
      'verses': {
        1: {'start': 0, 'duration': 15},
        46: {'start': 675, 'duration': 18}, // Worship through duty
        58: {'start': 855, 'duration': 16}, // Consciousness on Me
        66: {'start': 975, 'duration': 20}, // Ultimate surrender verse
        78: {'start': 1150, 'duration': 20}, // Final verse
      }
    },
  };
  
  /// Get chapter audio data for verse playback
  Map<String, dynamic>? _getChapterAudioData(int chapterId) {
    return _chapterAudioMap[chapterId];
  }
  
  /// Get verse timing data within chapter audio
  Map<String, int>? _getVerseTimingData(int chapterId, int verseNumber) {
    final chapterData = _chapterAudioMap[chapterId];
    if (chapterData == null) return null;
    
    final versesData = chapterData['verses'] as Map<int, Map<String, int>>;
    return versesData[verseNumber];
  }
  
  /// Check if audio is available for a verse
  bool isAudioAvailable(int chapterId, int verseNumber) {
    final chapterData = _getChapterAudioData(chapterId);
    if (chapterData == null) return false;
    
    final verseTimingData = _getVerseTimingData(chapterId, verseNumber);
    return verseTimingData != null;
  }
  
  /// Preload audio for offline use (future enhancement)
  Future<void> preloadAudio(int chapterId, int verseNumber) async {
    // Future: Download and cache audio for offline playback
    // This would use just_audio's LockCachingAudioSource
    debugPrint('📥 Preloading audio for Chapter $chapterId, Verse $verseNumber');
  }

  /// Pause current playback and resume background music
  Future<void> pause() async {
    if (_isPlaying) {
      _verseEndTimer?.cancel();
      await _player.pause();
      
      // Resume background music when verse is paused
      if (_wasBackgroundMusicPlaying && _backgroundMusicService.backgroundMusicEnabled) {
        await _backgroundMusicService.startBackgroundMusic();
        debugPrint('🎵 Background music resumed after pause');
      }
    }
  }

  /// Resume paused playback and pause background music
  Future<void> resume() async {
    if (!_isPlaying && _currentVerseId != null) {
      // Pause background music when resuming verse
      final status = _backgroundMusicService.getStatus();
      if (status['backgroundMusicPlaying'] == true) {
        await _backgroundMusicService.stopBackgroundMusic();
        _wasBackgroundMusicPlaying = true;
        debugPrint('🎵 Background music paused for verse resume');
      }
      
      await _player.play();
      
      // Re-setup verse end timer if we have current verse data
      if (_currentVerseId != null) {
        final parts = _currentVerseId!.split('.');
        if (parts.length == 2) {
          final chapterId = int.tryParse(parts[0]);
          final verseNumber = int.tryParse(parts[1]);
          if (chapterId != null && verseNumber != null) {
            final verseTimingData = _getVerseTimingData(chapterId, verseNumber);
            if (verseTimingData != null) {
              final remainingTime = Duration(
                seconds: verseTimingData['duration']! - position.inSeconds
              );
              if (remainingTime.inSeconds > 0) {
                _setupVerseEndTimer(remainingTime);
              }
            }
          }
        }
      }
    }
  }

  /// Stop current playback and restore background music
  Future<void> stop() async {
    _verseEndTimer?.cancel();
    await _player.stop();
    _isPlaying = false;
    _currentVerseId = null;
    
    // Resume background music when stopping verse
    if (_wasBackgroundMusicPlaying && _backgroundMusicService.backgroundMusicEnabled) {
      await _backgroundMusicService.startBackgroundMusic();
      debugPrint('🎵 Background music resumed after stop');
    }
    _wasBackgroundMusicPlaying = false;
    
    notifyListeners();
  }

  /// Set playback speed
  Future<void> setSpeed(double speed) async {
    _currentSpeed = speed.clamp(0.5, 2.0);
    await _player.setSpeed(_currentSpeed);
    notifyListeners();
  }

  /// Set volume
  Future<void> setVolume(double volume) async {
    await _player.setVolume(volume.clamp(0.0, 1.0));
  }

  /// Get current position
  Duration get position => _player.position;

  /// Get total duration
  Duration? get duration => _player.duration;

  /// Seek to position
  Future<void> seek(Duration position) async {
    await _player.seek(position);
  }

  /// Dispose of resources
  @override
  void dispose() {
    _verseEndTimer?.cancel();
    _player.dispose();
    super.dispose();
  }
}