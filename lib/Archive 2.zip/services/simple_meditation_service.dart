// Simple meditation service for Apple compliance
import 'package:flutter/foundation.dart';
import '../models/simple_meditation.dart';

class SimpleMeditationService extends ChangeNotifier {
  static final SimpleMeditationService _instance = SimpleMeditationService._internal();
  static SimpleMeditationService get instance => _instance;
  SimpleMeditationService._internal();

  bool _isInitialized = false;
  bool get isInitialized => _isInitialized;

  MeditationSession? _currentSession;
  MeditationSession? get currentSession => _currentSession;

  final List<MeditationSession> _sessions = [];

  // Session statistics
  int _totalSessions = 0;
  int _totalMinutes = 0;
  double _averageRating = 0.0;

  int get totalSessions => _totalSessions;
  int get totalMinutes => _totalMinutes;
  double get averageRating => _averageRating;

  Future<void> initialize() async {
    if (_isInitialized) return;

    try {
      debugPrint('🧘 Simple meditation service initializing...');
      _isInitialized = true;
      notifyListeners();
      debugPrint('✅ Simple meditation service initialized');
    } catch (e) {
      debugPrint('❌ Meditation service initialization failed: $e');
    }
  }

  Future<void> startSession({
    required int durationMinutes,
    required MusicTheme musicTheme,
  }) async {
    if (!_isInitialized) await initialize();

    _currentSession = MeditationSession.create(
      durationSeconds: durationMinutes * 60,
      musicTheme: musicTheme,
    );

    debugPrint('🧘 Started meditation session: ${durationMinutes}min with ${musicTheme.name}');
    notifyListeners();
  }

  Future<void> completeSession({double? userRating, String? notes}) async {
    if (_currentSession == null) return;

    final completedSession = _currentSession!.copyWith(
      isCompleted: true,
      actualDurationSeconds: _currentSession!.plannedDurationSeconds,
      userRating: userRating,
      notes: notes,
    );

    _sessions.add(completedSession);
    _updateStatistics();

    debugPrint('✅ Completed meditation session: ${completedSession.actualDurationSeconds ~/ 60}min');

    _currentSession = null;
    notifyListeners();
  }

  Future<void> pauseSession() async {
    debugPrint('⏸️ Meditation session paused');
    notifyListeners();
  }

  Future<void> stopSession() async {
    if (_currentSession == null) return;

    debugPrint('⏹️ Meditation session stopped');
    _currentSession = null;
    notifyListeners();
  }

  List<MeditationSession> getMeditationHistory({int limit = 10}) {
    return _sessions
        .where((s) => s.isCompleted)
        .take(limit)
        .toList()
        ..sort((a, b) => b.startedAt.compareTo(a.startedAt));
  }

  void _updateStatistics() {
    final completedSessions = _sessions.where((s) => s.isCompleted).toList();

    _totalSessions = completedSessions.length;
    _totalMinutes = completedSessions.fold(0, (sum, session) {
      return sum + (session.actualDurationSeconds ~/ 60);
    });

    final ratedSessions = completedSessions.where((s) => s.userRating != null).toList();
    if (ratedSessions.isNotEmpty) {
      _averageRating = ratedSessions.fold(0.0, (sum, s) => sum + s.userRating!) / ratedSessions.length;
    }
  }

  void dispose() {
    _currentSession = null;
    _sessions.clear();
    debugPrint('🧘 Simple meditation service disposed');
  }
}

// Simple meditation template for compatibility
class MeditationTemplate {
  final String id;
  final String title;
  final String description;
  final int durationMinutes;
  final MusicTheme musicTheme;

  const MeditationTemplate({
    required this.id,
    required this.title,
    required this.description,
    required this.durationMinutes,
    required this.musicTheme,
  });

  static List<MeditationTemplate> getDefaultTemplates() {
    return [
      const MeditationTemplate(
        id: 'mindfulness',
        title: 'Mindfulness Meditation',
        description: 'Basic mindfulness practice with breath awareness',
        durationMinutes: 10,
        musicTheme: MusicTheme.meditation,
      ),
      const MeditationTemplate(
        id: 'loving_kindness',
        title: 'Loving Kindness',
        description: 'Cultivate compassion and loving-kindness',
        durationMinutes: 15,
        musicTheme: MusicTheme.nature,
      ),
      const MeditationTemplate(
        id: 'body_scan',
        title: 'Body Scan',
        description: 'Progressive relaxation and body awareness',
        durationMinutes: 20,
        musicTheme: MusicTheme.meditation,
      ),
    ];
  }
}