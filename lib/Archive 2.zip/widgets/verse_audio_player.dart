// lib/widgets/verse_audio_player.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/verse_audio_service.dart';
import '../models/verse.dart';
import 'dart:async';

/// Audio player widget for verses with offline support and connection awareness
class VerseAudioPlayer extends StatefulWidget {
  final Verse verse;
  final int chapterId;
  
  const VerseAudioPlayer({
    Key? key,
    required this.verse,
    required this.chapterId,
  }) : super(key: key);

  @override
  State<VerseAudioPlayer> createState() => _VerseAudioPlayerState();
}

class _VerseAudioPlayerState extends State<VerseAudioPlayer> {
  final VerseAudioService _audioService = VerseAudioService.instance;
  bool _hasConnection = true;
  StreamSubscription? _positionSubscription;
  
  @override
  void initState() {
    super.initState();
    _checkConnection();
    _audioService.initialize();
  }
  
  @override
  void dispose() {
    _positionSubscription?.cancel();
    super.dispose();
  }
  
  Future<void> _checkConnection() async {
    // Simple connection check - can be enhanced with connectivity_plus package
    try {
      // Try to resolve a reliable DNS
      // In production, use connectivity_plus package for robust checking
      setState(() {
        _hasConnection = true; // Assume connection for now
      });
    } catch (e) {
      setState(() {
        _hasConnection = false;
      });
    }
  }
  
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    
    // Check if audio is available for this verse
    final isAudioAvailable = _audioService.isAudioAvailable(
      widget.chapterId, 
      widget.verse.verseId,
    );
    
    if (!isAudioAvailable) {
      return _buildNoAudioMessage(theme, isDark);
    }
    
    if (!_hasConnection) {
      return _buildOfflineMessage(theme, isDark);
    }
    
    return ChangeNotifierProvider<VerseAudioService>.value(
      value: _audioService,
      child: Consumer<VerseAudioService>(
        builder: (context, audioService, child) {
          final isCurrentVerse = audioService.currentVerseId == 
                                '${widget.chapterId}.${widget.verse.verseId}';
          final isPlaying = isCurrentVerse && audioService.isPlaying;
          final isLoading = isCurrentVerse && audioService.isLoading;
          
          return Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: isDark 
                  ? Colors.grey[850]
                  : Colors.grey[100],
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: isPlaying 
                    ? theme.colorScheme.primary
                    : Colors.transparent,
                width: 2,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    // Play/Pause button
                    _buildPlayPauseButton(
                      isPlaying: isPlaying,
                      isLoading: isLoading,
                      isCurrentVerse: isCurrentVerse,
                      theme: theme,
                    ),
                    const SizedBox(width: 12),
                    
                    // Track info
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Verse ${widget.verse.verseId} Audio',
                            style: theme.textTheme.titleSmall?.copyWith(
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          if (isCurrentVerse && audioService.duration != null)
                            Text(
                              _formatDuration(audioService.position) + 
                              ' / ' + 
                              _formatDuration(audioService.duration!),
                              style: theme.textTheme.bodySmall,
                            )
                          else
                            Text(
                              'Tap to play narration',
                              style: theme.textTheme.bodySmall?.copyWith(
                                color: theme.textTheme.bodySmall?.color?.withOpacity(0.7),
                              ),
                            ),
                        ],
                      ),
                    ),
                    
                    // Speed control
                    if (isCurrentVerse) _buildSpeedControl(audioService, theme),
                  ],
                ),
                
                // Progress bar
                if (isCurrentVerse && audioService.duration != null)
                  Column(
                    children: [
                      const SizedBox(height: 8),
                      LinearProgressIndicator(
                        value: audioService.duration!.inSeconds > 0
                            ? audioService.position.inSeconds / 
                              audioService.duration!.inSeconds
                            : 0.0,
                        backgroundColor: isDark 
                            ? Colors.grey[700]
                            : Colors.grey[300],
                      ),
                    ],
                  ),
              ],
            ),
          );
        },
      ),
    );
  }
  
  Widget _buildPlayPauseButton({
    required bool isPlaying,
    required bool isLoading,
    required bool isCurrentVerse,
    required ThemeData theme,
  }) {
    if (isLoading) {
      return Container(
        width: 48,
        height: 48,
        padding: const EdgeInsets.all(12),
        child: CircularProgressIndicator(
          strokeWidth: 2,
          color: theme.colorScheme.primary,
        ),
      );
    }
    
    return IconButton(
      onPressed: () async {
        if (isPlaying) {
          await _audioService.pause();
        } else if (isCurrentVerse) {
          await _audioService.resume();
        } else {
          await _audioService.playVerse(
            verseId: '${widget.chapterId}.${widget.verse.verseId}',
            chapterId: widget.chapterId,
            verseNumber: widget.verse.verseId,
          );
        }
      },
      icon: Icon(
        isPlaying ? Icons.pause_circle_filled : Icons.play_circle_filled,
        size: 48,
        color: theme.colorScheme.primary,
      ),
    );
  }
  
  Widget _buildSpeedControl(VerseAudioService audioService, ThemeData theme) {
    return PopupMenuButton<double>(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          border: Border.all(color: theme.colorScheme.primary),
          borderRadius: BorderRadius.circular(4),
        ),
        child: Text(
          '${audioService.currentSpeed.toStringAsFixed(1)}x',
          style: theme.textTheme.bodySmall,
        ),
      ),
      itemBuilder: (context) => [
        PopupMenuItem(value: 0.75, child: Text('0.75x')),
        PopupMenuItem(value: 1.0, child: Text('1.0x')),
        PopupMenuItem(value: 1.25, child: Text('1.25x')),
        PopupMenuItem(value: 1.5, child: Text('1.5x')),
      ],
      onSelected: (speed) => audioService.setSpeed(speed),
    );
  }
  
  Widget _buildNoAudioMessage(ThemeData theme, bool isDark) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: isDark ? Colors.grey[850] : Colors.grey[100],
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Icon(
            Icons.volume_off,
            color: theme.textTheme.bodySmall?.color?.withOpacity(0.5),
          ),
          const SizedBox(width: 8),
          Text(
            'Audio narration coming soon',
            style: theme.textTheme.bodySmall?.copyWith(
              fontStyle: FontStyle.italic,
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildOfflineMessage(ThemeData theme, bool isDark) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.orange.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.orange.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Icon(
            Icons.wifi_off,
            color: Colors.orange,
            size: 20,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              'Audio requires internet connection',
              style: theme.textTheme.bodySmall?.copyWith(
                color: Colors.orange[800],
              ),
            ),
          ),
          TextButton(
            onPressed: _checkConnection,
            child: Text(
              'Retry',
              style: TextStyle(
                color: Colors.orange[800],
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  String _formatDuration(Duration duration) {
    final minutes = duration.inMinutes;
    final seconds = duration.inSeconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }
}