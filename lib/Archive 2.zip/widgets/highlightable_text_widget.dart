// lib/widgets/highlightable_text_widget.dart

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/gestures.dart';
import 'package:provider/provider.dart';
import '../models/annotation.dart';
import '../services/annotation_service.dart';

class HighlightableTextWidget extends StatefulWidget {
  final String text;
  final String verseId;
  final TextStyle? textStyle;
  final int? maxLines;
  final TextAlign textAlign;
  final bool selectable;

  const HighlightableTextWidget({
    Key? key,
    required this.text,
    required this.verseId,
    this.textStyle,
    this.maxLines,
    this.textAlign = TextAlign.start,
    this.selectable = true,
  }) : super(key: key);

  @override
  State<HighlightableTextWidget> createState() => _HighlightableTextWidgetState();
}

class _HighlightableTextWidgetState extends State<HighlightableTextWidget> {
  final GlobalKey _textKey = GlobalKey();
  List<Annotation> _annotations = [];

  @override
  void initState() {
    super.initState();
    _loadAnnotations();
  }

  void _loadAnnotations() {
    final annotationService = context.read<AnnotationService>();
    _annotations = annotationService.getAnnotationsForVerse(widget.verseId);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AnnotationService>(
      builder: (context, annotationService, child) {
        _annotations = annotationService.getAnnotationsForVerse(widget.verseId);

        if (!widget.selectable || _annotations.isEmpty) {
          return _buildHighlightedText();
        }

        return SelectableText.rich(
          _buildTextSpans(),
          key: _textKey,
          style: widget.textStyle,
          maxLines: widget.maxLines,
          textAlign: widget.textAlign,
          onSelectionChanged: (selection, cause) {
            if (selection.baseOffset != selection.extentOffset) {
              _handleTextSelection(selection);
            }
          },
        );
      },
    );
  }

  /// Build text with highlights (non-selectable version)
  Widget _buildHighlightedText() {
    return Text.rich(
      _buildTextSpans(),
      style: widget.textStyle,
      maxLines: widget.maxLines,
      textAlign: widget.textAlign,
    );
  }

  /// Build text spans with highlights
  TextSpan _buildTextSpans() {
    if (_annotations.isEmpty) {
      return TextSpan(text: widget.text, style: widget.textStyle);
    }

    final spans = <TextSpan>[];
    int currentIndex = 0;

    // Sort annotations by start index
    final sortedAnnotations = List<Annotation>.from(_annotations)
      ..sort((a, b) => a.startIndex.compareTo(b.startIndex));

    for (final annotation in sortedAnnotations) {
      // Add text before highlight
      if (currentIndex < annotation.startIndex) {
        spans.add(TextSpan(
          text: widget.text.substring(currentIndex, annotation.startIndex),
          style: widget.textStyle,
        ));
      }

      // Add highlighted text
      spans.add(TextSpan(
        text: widget.text.substring(annotation.startIndex, annotation.endIndex),
        style: widget.textStyle?.copyWith(
          backgroundColor: _parseColor(annotation.highlightColor),
          color: _getContrastingTextColor(_parseColor(annotation.highlightColor)),
        ),
        recognizer: widget.selectable ? null : (TapGestureRecognizer()
          ..onTap = () => _showAnnotationDetails(annotation)),
      ));

      currentIndex = annotation.endIndex;
    }

    // Add remaining text
    if (currentIndex < widget.text.length) {
      spans.add(TextSpan(
        text: widget.text.substring(currentIndex),
        style: widget.textStyle,
      ));
    }

    return TextSpan(children: spans);
  }

  /// Handle text selection for highlighting
  void _handleTextSelection(TextSelection selection) {
    if (selection.baseOffset == selection.extentOffset) return;

    final selectedText = widget.text.substring(
      selection.baseOffset,
      selection.extentOffset,
    );

    _showHighlightDialog(
      selectedText: selectedText.trim(),
      startIndex: selection.baseOffset,
      endIndex: selection.extentOffset,
    );
  }

  /// Show dialog for creating/editing highlights
  void _showHighlightDialog({
    required String selectedText,
    required int startIndex,
    required int endIndex,
    Annotation? existingAnnotation,
  }) {
    String selectedColor = existingAnnotation?.highlightColor ?? HighlightColors.yellow;
    String noteText = existingAnnotation?.note ?? '';

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: Text(existingAnnotation == null ? 'Add Highlight' : 'Edit Highlight'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Selected text preview
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surfaceVariant,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  '"$selectedText"',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ),
              const SizedBox(height: 16),

              // Color selection
              const Text('Highlight Color:'),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                children: HighlightColors.colors.map((color) {
                  return GestureDetector(
                    onTap: () => setState(() => selectedColor = color),
                    child: Container(
                      width: 32,
                      height: 32,
                      decoration: BoxDecoration(
                        color: _parseColor(color),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: selectedColor == color 
                              ? Theme.of(context).colorScheme.primary 
                              : Colors.transparent,
                          width: 2,
                        ),
                      ),
                      child: selectedColor == color 
                          ? const Icon(Icons.check, color: Colors.black54, size: 16)
                          : null,
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 16),

              // Note input
              TextField(
                controller: TextEditingController(text: noteText),
                decoration: const InputDecoration(
                  labelText: 'Note (optional)',
                  border: OutlineInputBorder(),
                ),
                maxLines: 3,
                onChanged: (value) => noteText = value,
              ),
            ],
          ),
          actions: [
            if (existingAnnotation != null)
              TextButton(
                onPressed: () {
                  _deleteAnnotation(existingAnnotation);
                  Navigator.of(context).pop();
                },
                child: Text('Delete', style: TextStyle(color: Theme.of(context).colorScheme.error)),
              ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () {
                if (existingAnnotation == null) {
                  _addHighlight(
                    selectedText: selectedText,
                    startIndex: startIndex,
                    endIndex: endIndex,
                    highlightColor: selectedColor,
                    note: noteText.trim().isEmpty ? null : noteText.trim(),
                  );
                } else {
                  _updateAnnotation(
                    existingAnnotation,
                    highlightColor: selectedColor,
                    note: noteText.trim().isEmpty ? null : noteText.trim(),
                  );
                }
                Navigator.of(context).pop();
              },
              child: Text(existingAnnotation == null ? 'Highlight' : 'Update'),
            ),
          ],
        ),
      ),
    );
  }

  /// Add new highlight
  Future<void> _addHighlight({
    required String selectedText,
    required int startIndex,
    required int endIndex,
    required String highlightColor,
    String? note,
  }) async {
    final annotationService = context.read<AnnotationService>();
    
    final success = await annotationService.addAnnotation(
      verseId: widget.verseId,
      selectedText: selectedText,
      startIndex: startIndex,
      endIndex: endIndex,
      highlightColor: highlightColor,
      note: note,
    );

    if (success && mounted) {
      HapticFeedback.lightImpact();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Highlight added successfully'),
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  /// Update existing annotation
  Future<void> _updateAnnotation(
    Annotation annotation, {
    String? highlightColor,
    String? note,
  }) async {
    final annotationService = context.read<AnnotationService>();
    
    final success = await annotationService.updateAnnotation(
      annotationId: annotation.id,
      highlightColor: highlightColor,
      note: note,
    );

    if (success && mounted) {
      HapticFeedback.lightImpact();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Highlight updated successfully'),
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  /// Delete annotation
  Future<void> _deleteAnnotation(Annotation annotation) async {
    final annotationService = context.read<AnnotationService>();
    
    final success = await annotationService.deleteAnnotation(annotation.id);

    if (success && mounted) {
      HapticFeedback.lightImpact();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Highlight deleted successfully'),
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  /// Show annotation details when tapped
  void _showAnnotationDetails(Annotation annotation) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Highlight Details'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _parseColor(annotation.highlightColor),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                '"${annotation.selectedText}"',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  fontStyle: FontStyle.italic,
                  color: _getContrastingTextColor(_parseColor(annotation.highlightColor)),
                ),
              ),
            ),
            if (annotation.note != null) ...[
              const SizedBox(height: 12),
              Text(
                'Note:',
                style: Theme.of(context).textTheme.titleSmall,
              ),
              const SizedBox(height: 4),
              Text(annotation.note!),
            ],
            const SizedBox(height: 12),
            Text(
              'Created: ${_formatDate(annotation.createdAt)}',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Close'),
          ),
          FilledButton(
            onPressed: () {
              Navigator.of(context).pop();
              _showHighlightDialog(
                selectedText: annotation.selectedText,
                startIndex: annotation.startIndex,
                endIndex: annotation.endIndex,
                existingAnnotation: annotation,
              );
            },
            child: const Text('Edit'),
          ),
        ],
      ),
    );
  }

  /// Parse color string to Color object
  Color _parseColor(String colorHex) {
    return Color(int.parse(colorHex.replaceFirst('#', '0xFF')));
  }

  /// Get contrasting text color for background
  Color _getContrastingTextColor(Color backgroundColor) {
    final luminance = backgroundColor.computeLuminance();
    return luminance > 0.5 ? Colors.black87 : Colors.white;
  }

  /// Format date for display
  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year}';
  }
}

