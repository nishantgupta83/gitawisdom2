// lib/models/daily_practice.dart

import 'package:hive/hive.dart';

part 'daily_practice.g.dart';

/// Types of daily spiritual practices
enum PracticeType {
  reading,
  meditation,
  reflection,
  chanting,
  gratitude,
  service,
  mindfulness
}

/// Daily challenge model for spiritual practice
@HiveType(typeId: 20)
class DailyChallenge {
  @HiveField(0)
  final String id;
  
  @HiveField(1)
  final String title;
  
  @HiveField(2)
  final String description;
  
  @HiveField(3)
  final String practiceTypeString;
  
  @HiveField(4)
  final int targetValue;
  
  @HiveField(5)
  final String targetUnit;
  
  @HiveField(6)
  final int currentProgress;
  
  @HiveField(7)
  final bool isCompleted;
  
  @HiveField(8)
  final DateTime createdAt;
  
  @HiveField(9)
  final DateTime? completedAt;
  
  @HiveField(10)
  final int rewardPoints;
  
  @HiveField(11)
  final String? verseReference;
  
  @HiveField(12)
  final String? iconName;
  
  PracticeType get practiceType => PracticeType.values.firstWhere(
    (e) => e.toString().split('.').last == practiceTypeString,
    orElse: () => PracticeType.reading,
  );

  DailyChallenge({
    required this.id,
    required this.title,
    required this.description,
    required this.practiceTypeString,
    required this.targetValue,
    required this.targetUnit,
    this.currentProgress = 0,
    this.isCompleted = false,
    required this.createdAt,
    this.completedAt,
    this.rewardPoints = 10,
    this.verseReference,
    this.iconName,
  });
  
  DailyChallenge copyWith({
    int? currentProgress,
    bool? isCompleted,
    DateTime? completedAt,
  }) {
    return DailyChallenge(
      id: id,
      title: title,
      description: description,
      practiceTypeString: practiceTypeString,
      targetValue: targetValue,
      targetUnit: targetUnit,
      currentProgress: currentProgress ?? this.currentProgress,
      isCompleted: isCompleted ?? this.isCompleted,
      createdAt: createdAt,
      completedAt: completedAt ?? this.completedAt,
      rewardPoints: rewardPoints,
      verseReference: verseReference,
      iconName: iconName,
    );
  }
  
  double get progressPercentage => targetValue > 0 ? (currentProgress / targetValue).clamp(0.0, 1.0) : 0.0;
}

/// Meditation session model
@HiveType(typeId: 21)
class MeditationSession {
  @HiveField(0)
  final String id;
  
  @HiveField(1)
  final String title;
  
  @HiveField(2)
  final String description;
  
  @HiveField(3)
  final int durationMinutes;
  
  @HiveField(4)
  final String themeName;
  
  @HiveField(5)
  final List<String> guidanceSteps;
  
  @HiveField(6)
  final String? backgroundMusic;
  
  @HiveField(7)
  final String? focusVerse;
  
  @HiveField(8)
  final DateTime startedAt;
  
  @HiveField(9)
  final DateTime? completedAt;
  
  @HiveField(10)
  final int actualDurationSeconds;
  
  @HiveField(11)
  final double? userRating;
  
  @HiveField(12)
  final String? reflection;
  
  MeditationSession({
    required this.id,
    required this.title,
    required this.description,
    required this.durationMinutes,
    required this.themeName,
    required this.guidanceSteps,
    this.backgroundMusic,
    this.focusVerse,
    required this.startedAt,
    this.completedAt,
    this.actualDurationSeconds = 0,
    this.userRating,
    this.reflection,
  });
  
  bool get isCompleted => completedAt != null;
  
  MeditationSession complete({
    required DateTime completedAt,
    required int actualDurationSeconds,
    double? userRating,
    String? reflection,
  }) {
    return MeditationSession(
      id: id,
      title: title,
      description: description,
      durationMinutes: durationMinutes,
      themeName: themeName,
      guidanceSteps: guidanceSteps,
      backgroundMusic: backgroundMusic,
      focusVerse: focusVerse,
      startedAt: startedAt,
      completedAt: completedAt,
      actualDurationSeconds: actualDurationSeconds,
      userRating: userRating,
      reflection: reflection,
    );
  }
}

/// Practice streak tracking
@HiveType(typeId: 22)
class PracticeStreak {
  @HiveField(0)
  final String practiceTypeString;
  
  @HiveField(1)
  final int currentStreak;
  
  @HiveField(2)
  final int bestStreak;
  
  @HiveField(3)
  final DateTime? lastPracticeDate;
  
  @HiveField(4)
  final int totalSessions;
  
  @HiveField(5)
  final int totalMinutes;
  
  @HiveField(6)
  final List<DateTime> practiceDates;
  
  PracticeType get practiceType => PracticeType.values.firstWhere(
    (e) => e.toString().split('.').last == practiceTypeString,
    orElse: () => PracticeType.reading,
  );
  
  PracticeStreak({
    required this.practiceTypeString,
    this.currentStreak = 0,
    this.bestStreak = 0,
    this.lastPracticeDate,
    this.totalSessions = 0,
    this.totalMinutes = 0,
    List<DateTime>? practiceDates,
  }) : practiceDates = practiceDates ?? [];
  
  PracticeStreak updateStreak({
    required DateTime practiceDate,
    int minutesPracticed = 0,
  }) {
    // Check if this continues the streak
    int newCurrentStreak = currentStreak;
    if (lastPracticeDate != null) {
      final daysSinceLastPractice = practiceDate.difference(lastPracticeDate!).inDays;
      if (daysSinceLastPractice == 1) {
        // Continuing streak
        newCurrentStreak = currentStreak + 1;
      } else if (daysSinceLastPractice > 1) {
        // Streak broken
        newCurrentStreak = 1;
      }
      // Same day practice doesn't change streak
    } else {
      // First practice
      newCurrentStreak = 1;
    }
    
    final newBestStreak = newCurrentStreak > bestStreak ? newCurrentStreak : bestStreak;
    
    return PracticeStreak(
      practiceTypeString: practiceTypeString,
      currentStreak: newCurrentStreak,
      bestStreak: newBestStreak,
      lastPracticeDate: practiceDate,
      totalSessions: totalSessions + 1,
      totalMinutes: totalMinutes + minutesPracticed,
      practiceDates: [...practiceDates, practiceDate],
    );
  }
  
  bool get isActiveToday {
    if (lastPracticeDate == null) return false;
    final now = DateTime.now();
    return lastPracticeDate!.year == now.year &&
           lastPracticeDate!.month == now.month &&
           lastPracticeDate!.day == now.day;
  }
}

/// Daily routine template
@HiveType(typeId: 23)
class DailyRoutine {
  @HiveField(0)
  final String id;
  
  @HiveField(1)
  final String name;
  
  @HiveField(2)
  final String timeOfDay; // morning, afternoon, evening, night
  
  @HiveField(3)
  final List<RoutineStep> steps;
  
  @HiveField(4)
  final int totalDurationMinutes;
  
  @HiveField(5)
  final bool isActive;
  
  @HiveField(6)
  final List<String> reminderTimes;
  
  @HiveField(7)
  final DateTime createdAt;
  
  @HiveField(8)
  final DateTime? lastCompletedAt;
  
  @HiveField(9)
  final int completionCount;
  
  DailyRoutine({
    required this.id,
    required this.name,
    required this.timeOfDay,
    required this.steps,
    required this.totalDurationMinutes,
    this.isActive = true,
    List<String>? reminderTimes,
    required this.createdAt,
    this.lastCompletedAt,
    this.completionCount = 0,
  }) : reminderTimes = reminderTimes ?? [];
  
  DailyRoutine markCompleted() {
    return DailyRoutine(
      id: id,
      name: name,
      timeOfDay: timeOfDay,
      steps: steps,
      totalDurationMinutes: totalDurationMinutes,
      isActive: isActive,
      reminderTimes: reminderTimes,
      createdAt: createdAt,
      lastCompletedAt: DateTime.now(),
      completionCount: completionCount + 1,
    );
  }
}

/// Individual step in a daily routine
@HiveType(typeId: 24)
class RoutineStep {
  @HiveField(0)
  final String title;
  
  @HiveField(1)
  final String description;
  
  @HiveField(2)
  final String practiceTypeString;
  
  @HiveField(3)
  final int durationMinutes;
  
  @HiveField(4)
  final String? resourceId;
  
  @HiveField(5)
  final bool isCompleted;
  
  PracticeType get practiceType => PracticeType.values.firstWhere(
    (e) => e.toString().split('.').last == practiceTypeString,
    orElse: () => PracticeType.reading,
  );
  
  RoutineStep({
    required this.title,
    required this.description,
    required this.practiceTypeString,
    required this.durationMinutes,
    this.resourceId,
    this.isCompleted = false,
  });
  
  RoutineStep complete() {
    return RoutineStep(
      title: title,
      description: description,
      practiceTypeString: practiceTypeString,
      durationMinutes: durationMinutes,
      resourceId: resourceId,
      isCompleted: true,
    );
  }
}