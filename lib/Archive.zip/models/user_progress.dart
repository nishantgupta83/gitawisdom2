// lib/models/user_progress.dart

import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';

part 'user_progress.g.dart';

/// Types of progress that can be tracked
enum ProgressType {
  chapterStarted('chapter_started'),
  chapterCompleted('chapter_completed'),
  verseRead('verse_read'),
  sessionTime('session_time'),
  dailyGoalMet('daily_goal_met'),
  streakMilestone('streak_milestone');

  const ProgressType(this.value);
  final String value;

  static ProgressType fromString(String value) {
    return ProgressType.values.firstWhere(
      (type) => type.value == value,
      orElse: () => ProgressType.verseRead,
    );
  }
}

@HiveType(typeId: 10)
class UserProgress extends HiveObject {
  /// Unique identifier for the progress entry
  @HiveField(0)
  final String id;

  /// Device identifier for offline sync
  @HiveField(1)
  final String userDeviceId;

  /// Chapter ID being tracked
  @HiveField(2)
  final int chapterId;

  /// Optional verse ID for verse-level tracking
  @HiveField(3)
  final int? verseId;

  /// Type of progress being tracked
  @HiveField(4)
  final ProgressType progressType;

  /// Progress value (percentage, time in minutes, streak count, etc.)
  @HiveField(5)
  final double? progressValue;

  /// Date of the session
  @HiveField(6)
  final DateTime sessionDate;

  /// Duration of the session in minutes
  @HiveField(7)
  final int sessionDurationMinutes;

  /// When the progress entry was created
  @HiveField(8)
  final DateTime createdAt;

  /// Additional metadata as key-value pairs
  @HiveField(9)
  final Map<String, dynamic> metadata;

  UserProgress({
    required this.id,
    required this.userDeviceId,
    required this.chapterId,
    this.verseId,
    required this.progressType,
    this.progressValue,
    required this.sessionDate,
    this.sessionDurationMinutes = 0,
    required this.createdAt,
    this.metadata = const {},
  });

  /// Creates a UserProgress from Supabase JSON response
  factory UserProgress.fromJson(Map<String, dynamic> json) {
    return UserProgress(
      id: json['id'] as String,
      userDeviceId: json['user_device_id'] as String,
      chapterId: json['chapter_id'] as int,
      verseId: json['verse_id'] as int?,
      progressType: ProgressType.fromString(json['progress_type'] as String),
      progressValue: (json['progress_value'] as num?)?.toDouble(),
      sessionDate: DateTime.parse(json['session_date'] as String),
      sessionDurationMinutes: json['session_duration_minutes'] as int? ?? 0,
      createdAt: DateTime.parse(json['created_at'] as String),
      metadata: (json['metadata'] as Map<String, dynamic>?) ?? {},
    );
  }

  /// Converts progress to JSON for Supabase storage
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'user_device_id': userDeviceId,
      'chapter_id': chapterId,
      'verse_id': verseId,
      'progress_type': progressType.value,
      'progress_value': progressValue,
      'session_date': sessionDate.toIso8601String().split('T')[0], // Date only
      'session_duration_minutes': sessionDurationMinutes,
      'created_at': createdAt.toIso8601String(),
      'metadata': metadata,
    };
  }

  /// Creates a new progress entry with current timestamp
  factory UserProgress.create({
    required String userDeviceId,
    required int chapterId,
    int? verseId,
    required ProgressType progressType,
    double? progressValue,
    DateTime? sessionDate,
    int sessionDurationMinutes = 0,
    Map<String, dynamic> metadata = const {},
  }) {
    final now = DateTime.now();
    const uuid = Uuid();
    return UserProgress(
      id: uuid.v4(), // Generate proper UUID instead of timestamp
      userDeviceId: userDeviceId,
      chapterId: chapterId,
      verseId: verseId,
      progressType: progressType,
      progressValue: progressValue,
      sessionDate: sessionDate ?? DateTime(now.year, now.month, now.day),
      sessionDurationMinutes: sessionDurationMinutes,
      createdAt: now,
      metadata: metadata,
    );
  }

  /// Creates a copy with updated fields
  UserProgress copyWith({
    String? id,
    String? userDeviceId,
    int? chapterId,
    int? verseId,
    ProgressType? progressType,
    double? progressValue,
    DateTime? sessionDate,
    int? sessionDurationMinutes,
    DateTime? createdAt,
    Map<String, dynamic>? metadata,
  }) {
    return UserProgress(
      id: id ?? this.id,
      userDeviceId: userDeviceId ?? this.userDeviceId,
      chapterId: chapterId ?? this.chapterId,
      verseId: verseId ?? this.verseId,
      progressType: progressType ?? this.progressType,
      progressValue: progressValue ?? this.progressValue,
      sessionDate: sessionDate ?? this.sessionDate,
      sessionDurationMinutes: sessionDurationMinutes ?? this.sessionDurationMinutes,
      createdAt: createdAt ?? this.createdAt,
      metadata: metadata ?? this.metadata,
    );
  }

  /// Returns true if this is a completion-type progress
  bool get isCompletion => 
      progressType == ProgressType.chapterCompleted || 
      progressType == ProgressType.dailyGoalMet;

  /// Returns true if this progress entry is valid
  bool get isValid => 
      id.isNotEmpty && 
      userDeviceId.isNotEmpty && 
      chapterId > 0;

  /// Returns progress reference string
  String get reference {
    if (verseId != null) {
      return 'progress:$chapterId.$verseId:${progressType.value}';
    }
    return 'progress:$chapterId:${progressType.value}';
  }

  /// Returns formatted progress value based on type
  String get formattedProgressValue {
    if (progressValue == null) return '-';
    
    switch (progressType) {
      case ProgressType.sessionTime:
        return '${progressValue!.toInt()} min';
      case ProgressType.chapterStarted:
      case ProgressType.chapterCompleted:
        return '${(progressValue! * 100).toInt()}%';
      case ProgressType.streakMilestone:
        return '${progressValue!.toInt()} days';
      case ProgressType.verseRead:
      case ProgressType.dailyGoalMet:
        return progressValue!.toInt().toString();
    }
  }

  /// Returns today's date as DateTime
  static DateTime get today {
    final now = DateTime.now();
    return DateTime(now.year, now.month, now.day);
  }

  /// Returns true if this progress was made today
  bool get isToday => 
      sessionDate.year == today.year &&
      sessionDate.month == today.month &&
      sessionDate.day == today.day;

  @override
  String toString() {
    return 'UserProgress(id: $id, type: ${progressType.value}, chapter: $chapterId, value: $progressValue)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is UserProgress &&
        other.id == id &&
        other.userDeviceId == userDeviceId &&
        other.chapterId == chapterId &&
        other.progressType == progressType;
  }

  @override
  int get hashCode {
    return Object.hash(id, userDeviceId, chapterId, progressType);
  }
}