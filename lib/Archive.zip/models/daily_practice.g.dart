// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'daily_practice.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class DailyChallengeAdapter extends TypeAdapter<DailyChallenge> {
  @override
  final int typeId = 20;

  @override
  DailyChallenge read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return DailyChallenge(
      id: fields[0] as String,
      title: fields[1] as String,
      description: fields[2] as String,
      practiceTypeString: fields[3] as String,
      targetValue: fields[4] as int,
      targetUnit: fields[5] as String,
      currentProgress: fields[6] as int,
      isCompleted: fields[7] as bool,
      createdAt: fields[8] as DateTime,
      completedAt: fields[9] as DateTime?,
      rewardPoints: fields[10] as int,
      verseReference: fields[11] as String?,
      iconName: fields[12] as String?,
    );
  }

  @override
  void write(BinaryWriter writer, DailyChallenge obj) {
    writer
      ..writeByte(13)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.title)
      ..writeByte(2)
      ..write(obj.description)
      ..writeByte(3)
      ..write(obj.practiceTypeString)
      ..writeByte(4)
      ..write(obj.targetValue)
      ..writeByte(5)
      ..write(obj.targetUnit)
      ..writeByte(6)
      ..write(obj.currentProgress)
      ..writeByte(7)
      ..write(obj.isCompleted)
      ..writeByte(8)
      ..write(obj.createdAt)
      ..writeByte(9)
      ..write(obj.completedAt)
      ..writeByte(10)
      ..write(obj.rewardPoints)
      ..writeByte(11)
      ..write(obj.verseReference)
      ..writeByte(12)
      ..write(obj.iconName);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is DailyChallengeAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class MeditationSessionAdapter extends TypeAdapter<MeditationSession> {
  @override
  final int typeId = 21;

  @override
  MeditationSession read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return MeditationSession(
      id: fields[0] as String,
      title: fields[1] as String,
      description: fields[2] as String,
      durationMinutes: fields[3] as int,
      themeName: fields[4] as String,
      guidanceSteps: (fields[5] as List).cast<String>(),
      backgroundMusic: fields[6] as String?,
      focusVerse: fields[7] as String?,
      startedAt: fields[8] as DateTime,
      completedAt: fields[9] as DateTime?,
      actualDurationSeconds: fields[10] as int,
      userRating: fields[11] as double?,
      reflection: fields[12] as String?,
    );
  }

  @override
  void write(BinaryWriter writer, MeditationSession obj) {
    writer
      ..writeByte(13)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.title)
      ..writeByte(2)
      ..write(obj.description)
      ..writeByte(3)
      ..write(obj.durationMinutes)
      ..writeByte(4)
      ..write(obj.themeName)
      ..writeByte(5)
      ..write(obj.guidanceSteps)
      ..writeByte(6)
      ..write(obj.backgroundMusic)
      ..writeByte(7)
      ..write(obj.focusVerse)
      ..writeByte(8)
      ..write(obj.startedAt)
      ..writeByte(9)
      ..write(obj.completedAt)
      ..writeByte(10)
      ..write(obj.actualDurationSeconds)
      ..writeByte(11)
      ..write(obj.userRating)
      ..writeByte(12)
      ..write(obj.reflection);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is MeditationSessionAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class PracticeStreakAdapter extends TypeAdapter<PracticeStreak> {
  @override
  final int typeId = 22;

  @override
  PracticeStreak read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return PracticeStreak(
      practiceTypeString: fields[0] as String,
      currentStreak: fields[1] as int,
      bestStreak: fields[2] as int,
      lastPracticeDate: fields[3] as DateTime?,
      totalSessions: fields[4] as int,
      totalMinutes: fields[5] as int,
      practiceDates: (fields[6] as List?)?.cast<DateTime>(),
    );
  }

  @override
  void write(BinaryWriter writer, PracticeStreak obj) {
    writer
      ..writeByte(7)
      ..writeByte(0)
      ..write(obj.practiceTypeString)
      ..writeByte(1)
      ..write(obj.currentStreak)
      ..writeByte(2)
      ..write(obj.bestStreak)
      ..writeByte(3)
      ..write(obj.lastPracticeDate)
      ..writeByte(4)
      ..write(obj.totalSessions)
      ..writeByte(5)
      ..write(obj.totalMinutes)
      ..writeByte(6)
      ..write(obj.practiceDates);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is PracticeStreakAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class DailyRoutineAdapter extends TypeAdapter<DailyRoutine> {
  @override
  final int typeId = 23;

  @override
  DailyRoutine read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return DailyRoutine(
      id: fields[0] as String,
      name: fields[1] as String,
      timeOfDay: fields[2] as String,
      steps: (fields[3] as List).cast<RoutineStep>(),
      totalDurationMinutes: fields[4] as int,
      isActive: fields[5] as bool,
      reminderTimes: (fields[6] as List?)?.cast<String>(),
      createdAt: fields[7] as DateTime,
      lastCompletedAt: fields[8] as DateTime?,
      completionCount: fields[9] as int,
    );
  }

  @override
  void write(BinaryWriter writer, DailyRoutine obj) {
    writer
      ..writeByte(10)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.name)
      ..writeByte(2)
      ..write(obj.timeOfDay)
      ..writeByte(3)
      ..write(obj.steps)
      ..writeByte(4)
      ..write(obj.totalDurationMinutes)
      ..writeByte(5)
      ..write(obj.isActive)
      ..writeByte(6)
      ..write(obj.reminderTimes)
      ..writeByte(7)
      ..write(obj.createdAt)
      ..writeByte(8)
      ..write(obj.lastCompletedAt)
      ..writeByte(9)
      ..write(obj.completionCount);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is DailyRoutineAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class RoutineStepAdapter extends TypeAdapter<RoutineStep> {
  @override
  final int typeId = 24;

  @override
  RoutineStep read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return RoutineStep(
      title: fields[0] as String,
      description: fields[1] as String,
      practiceTypeString: fields[2] as String,
      durationMinutes: fields[3] as int,
      resourceId: fields[4] as String?,
      isCompleted: fields[5] as bool,
    );
  }

  @override
  void write(BinaryWriter writer, RoutineStep obj) {
    writer
      ..writeByte(6)
      ..writeByte(0)
      ..write(obj.title)
      ..writeByte(1)
      ..write(obj.description)
      ..writeByte(2)
      ..write(obj.practiceTypeString)
      ..writeByte(3)
      ..write(obj.durationMinutes)
      ..writeByte(4)
      ..write(obj.resourceId)
      ..writeByte(5)
      ..write(obj.isCompleted);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is RoutineStepAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
