// lib/widgets/streak_indicator.dart

import 'package:flutter/material.dart';
import 'dart:math' as math;

class StreakIndicator extends StatelessWidget {
  final int currentStreak;
  final int longestStreak;
  final bool isActive;

  const StreakIndicator({
    super.key,
    required this.currentStreak,
    required this.longestStreak,
    required this.isActive,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: isActive
              ? [
                  Colors.orange.shade100,
                  Colors.red.shade100,
                  Colors.pink.shade50,
                ]
              : [
                  theme.colorScheme.surfaceVariant.withOpacity(0.3),
                  theme.colorScheme.surface,
                ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isActive ? Colors.orange.withOpacity(0.3) : theme.colorScheme.outline.withOpacity(0.2),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildFlameIcon(),
              const SizedBox(width: 8),
              Text(
                'Reading Streak',
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: isActive ? Colors.orange.shade800 : theme.colorScheme.onSurface,
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 16),
          
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildStreakStat(
                'Current',
                currentStreak.toString(),
                'days',
                Colors.orange,
                theme,
                isActive,
              ),
              Container(
                width: 1,
                height: 40,
                color: theme.colorScheme.outline.withOpacity(0.3),
              ),
              _buildStreakStat(
                'Best',
                longestStreak.toString(),
                'days',
                Colors.blue,
                theme,
                false,
              ),
            ],
          ),
          
          const SizedBox(height: 16),
          
          _buildStreakProgress(theme),
        ],
      ),
    );
  }

  Widget _buildFlameIcon() {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: isActive ? Colors.orange.withOpacity(0.2) : Colors.grey.withOpacity(0.2),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Icon(
        isActive ? Icons.local_fire_department : Icons.local_fire_department_outlined,
        color: isActive ? Colors.orange.shade700 : Colors.grey.shade600,
        size: 24,
      ),
    );
  }

  Widget _buildStreakStat(
    String label,
    String value,
    String unit,
    Color color,
    ThemeData theme,
    bool highlight,
  ) {
    return Column(
      children: [
        Text(
          label,
          style: theme.textTheme.labelMedium?.copyWith(
            color: theme.colorScheme.onSurface.withOpacity(0.7),
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 4),
        Row(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              value,
              style: theme.textTheme.headlineLarge?.copyWith(
                fontWeight: FontWeight.bold,
                color: highlight ? color : theme.colorScheme.onSurface,
                fontSize: 28,
              ),
            ),
            const SizedBox(width: 2),
            Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Text(
                unit,
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onSurface.withOpacity(0.6),
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildStreakProgress(ThemeData theme) {
    final nextMilestone = _getNextMilestone(currentStreak);
    final progress = currentStreak / nextMilestone;
    
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Next milestone',
              style: theme.textTheme.labelSmall?.copyWith(
                color: theme.colorScheme.onSurface.withOpacity(0.6),
              ),
            ),
            Text(
              '$nextMilestone days',
              style: theme.textTheme.labelSmall?.copyWith(
                color: theme.colorScheme.onSurface.withOpacity(0.6),
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        LinearProgressIndicator(
          value: progress.clamp(0.0, 1.0),
          backgroundColor: theme.colorScheme.surfaceVariant.withOpacity(0.5),
          valueColor: AlwaysStoppedAnimation<Color>(
            isActive ? Colors.orange.shade500 : Colors.grey.shade400,
          ),
          minHeight: 6,
        ),
        const SizedBox(height: 4),
        Text(
          '${currentStreak} / $nextMilestone days',
          style: theme.textTheme.labelSmall?.copyWith(
            color: theme.colorScheme.onSurface.withOpacity(0.5),
          ),
        ),
      ],
    );
  }

  int _getNextMilestone(int streak) {
    const milestones = [7, 14, 30, 60, 90, 180, 365];
    
    for (final milestone in milestones) {
      if (streak < milestone) {
        return milestone;
      }
    }
    
    // Beyond all predefined milestones, use yearly increments
    return ((streak / 365).ceil() + 1) * 365;
  }
}