// lib/widgets/audio_control_widget.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/enhanced_audio_service.dart';
import '../models/verse.dart';
import '../models/scenario.dart';

/// Reusable audio control widget for verses and scenarios
/// Provides play/pause, speed control, and narration functionality
class AudioControlWidget extends StatefulWidget {
  final Verse? verse;
  final Scenario? scenario;
  final bool compact;
  final Color? iconColor;
  final double iconSize;

  const AudioControlWidget({
    Key? key,
    this.verse,
    this.scenario,
    this.compact = false,
    this.iconColor,
    this.iconSize = 24.0,
  }) : assert(verse != null || scenario != null, 'Either verse or scenario must be provided'),
        super(key: key);

  @override
  State<AudioControlWidget> createState() => _AudioControlWidgetState();
}

class _AudioControlWidgetState extends State<AudioControlWidget> {
  bool _isPlaying = false;
  bool _isLoading = false;

  @override
  Widget build(BuildContext context) {
    return Consumer<EnhancedAudioService>(
      builder: (context, audioService, child) {
        if (!audioService.isInitialized) {
          return const SizedBox.shrink();
        }

        // Check if this item is currently playing
        final isCurrentlyPlaying = _isCurrentlyPlaying(audioService);
        _isPlaying = isCurrentlyPlaying && audioService.narration.isPlaying;

        if (widget.compact) {
          return _buildCompactControls(audioService);
        } else {
          return _buildFullControls(audioService);
        }
      },
    );
  }

  /// Build compact audio controls (just play button)
  Widget _buildCompactControls(EnhancedAudioService audioService) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: _isLoading ? null : () => _togglePlayback(audioService),
        child: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.5),
            borderRadius: BorderRadius.circular(20),
          ),
          child: _isLoading
              ? SizedBox(
                  width: widget.iconSize,
                  height: widget.iconSize,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: widget.iconColor ?? Theme.of(context).colorScheme.primary,
                  ),
                )
              : Icon(
                  _isPlaying ? Icons.pause : Icons.play_arrow,
                  size: widget.iconSize,
                  color: widget.iconColor ?? Theme.of(context).colorScheme.primary,
                ),
        ),
      ),
    );
  }

  /// Build full audio controls with speed control
  Widget _buildFullControls(EnhancedAudioService audioService) {
    final theme = Theme.of(context);
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceVariant.withOpacity(0.3),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: theme.colorScheme.outline.withOpacity(0.2),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Main controls row
          Row(
            children: [
              // Play/Pause button
              Material(
                color: Colors.transparent,
                child: InkWell(
                  borderRadius: BorderRadius.circular(24),
                  onTap: _isLoading ? null : () => _togglePlayback(audioService),
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: theme.colorScheme.primary,
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: _isLoading
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                        : Icon(
                            _isPlaying ? Icons.pause : Icons.play_arrow,
                            color: theme.colorScheme.onPrimary,
                            size: 20,
                          ),
                  ),
                ),
              ),
              const SizedBox(width: 12),

              // Content info
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _getTitle(),
                      style: theme.textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Tap to hear narration',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurface.withOpacity(0.6),
                      ),
                    ),
                  ],
                ),
              ),

              // Speed control
              _buildSpeedControl(audioService),
            ],
          ),
        ],
      ),
    );
  }

  /// Build speed control dropdown
  Widget _buildSpeedControl(EnhancedAudioService audioService) {
    final currentSpeed = audioService.narration.speechRate;
    
    return PopupMenuButton<double>(
      icon: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            '${currentSpeed.toStringAsFixed(1)}x',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
              fontWeight: FontWeight.w500,
            ),
          ),
          const Icon(Icons.keyboard_arrow_down, size: 16),
        ],
      ),
      onSelected: (speed) async {
        await audioService.setNarrationSpeed(speed);
      },
      itemBuilder: (context) => [
        const PopupMenuItem(value: 0.5, child: Text('0.5x - Slow')),
        const PopupMenuItem(value: 0.75, child: Text('0.75x')),
        const PopupMenuItem(value: 1.0, child: Text('1.0x - Normal')),
        const PopupMenuItem(value: 1.25, child: Text('1.25x')),
        const PopupMenuItem(value: 1.5, child: Text('1.5x - Fast')),
        const PopupMenuItem(value: 2.0, child: Text('2.0x - Very Fast')),
      ],
    );
  }

  /// Toggle playback for current item
  Future<void> _togglePlayback(EnhancedAudioService audioService) async {
    setState(() {
      _isLoading = true;
    });

    try {
      if (_isPlaying) {
        // Stop current narration
        await audioService.narration.stop();
      } else {
        // Start narration for this item
        if (widget.verse != null) {
          await audioService.playVerseNarration(widget.verse!);
        } else if (widget.scenario != null) {
          await audioService.playScenarioNarration(widget.scenario!);
        }
      }
    } catch (e) {
      debugPrint('❌ Audio control error: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Audio playback failed. Please try again.'),
          duration: Duration(seconds: 2),
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  /// Check if current item is playing
  bool _isCurrentlyPlaying(EnhancedAudioService audioService) {
    final currentId = audioService.narration.currentId;
    if (currentId == null) return false;

    if (widget.verse != null) {
      return currentId == '${widget.verse!.chapterId}.${widget.verse!.verseId}';
    } else if (widget.scenario != null) {
      return currentId == widget.scenario!.title;
    }
    
    return false;
  }

  /// Get display title for the audio control
  String _getTitle() {
    if (widget.verse != null) {
      return 'Verse ${widget.verse!.chapterId}.${widget.verse!.verseId}';
    } else if (widget.scenario != null) {
      return widget.scenario!.title;
    }
    return 'Audio';
  }
}