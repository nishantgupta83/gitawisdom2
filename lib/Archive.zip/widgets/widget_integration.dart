// lib/widgets/widget_integration.dart

import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:provider/provider.dart';
import '../services/widget_service.dart';
import '../services/bookmark_service.dart';
import '../services/progress_service.dart';
import '../services/daily_verse_service.dart';

/// Widget to handle automatic widget data updates
/// Place this widget high in the widget tree to ensure data sync
class WidgetIntegration extends StatefulWidget {
  final Widget child;
  
  const WidgetIntegration({
    Key? key,
    required this.child,
  }) : super(key: key);
  
  @override
  State<WidgetIntegration> createState() => _WidgetIntegrationState();
}

class _WidgetIntegrationState extends State<WidgetIntegration> 
    with WidgetsBindingObserver {
  
  WidgetService? _widgetService;
  BookmarkService? _bookmarkService;
  ProgressService? _progressService;
  DailyVerseService? _dailyVerseService;
  
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    
    // Initialize widget service
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _initializeServices();
    });
  }
  
  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }
  
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    
    // Update widgets when app goes to background
    if (state == AppLifecycleState.paused || 
        state == AppLifecycleState.inactive) {
      _updateAllWidgetData();
    }
  }
  
  void _initializeServices() {
    _widgetService = Provider.of<WidgetService>(context, listen: false);
    _bookmarkService = Provider.of<BookmarkService>(context, listen: false);
    _progressService = Provider.of<ProgressService>(context, listen: false);
    _dailyVerseService = Provider.of<DailyVerseService>(context, listen: false);
    
    // Set up listeners for automatic widget updates
    _setupListeners();
    
    // Initial widget data update
    _updateAllWidgetData();
  }
  
  void _setupListeners() {
    // Listen to bookmark changes
    _bookmarkService?.addListener(_onBookmarksChanged);
    
    // Listen to progress changes  
    _progressService?.addListener(_onProgressChanged);
    
    // Note: DailyVerseService doesn't extend ChangeNotifier
    // Will update manually when needed
  }
  
  void _onBookmarksChanged() {
    if (_bookmarkService?.bookmarks != null) {
      _widgetService?.updateRecentBookmarks(_bookmarkService!.bookmarks);
    }
  }
  
  void _onProgressChanged() {
    // Placeholder progress data until we integrate with actual service
    _widgetService?.updateReadingProgress(
      readingStreak: 7,
      chaptersCompleted: 3,
      totalReadingTime: 120,
      todayProgress: true,
      completedChapterIds: [1, 2, 3],
      achievements: ['week_streak', 'consistent_reader'],
    );
  }
  
  void _onDailyVerseChanged() {
    // Will be implemented when DailyVerseService integration is ready
    // For now, widget service handles daily verse updates internally
  }
  
  void _updateAllWidgetData() {
    final widgetService = _widgetService;
    final bookmarkService = _bookmarkService;
    
    if (widgetService == null) return;
    
    // Update bookmarks
    final bookmarks = bookmarkService?.bookmarks;
    if (bookmarks != null) {
      widgetService.updateRecentBookmarks(bookmarks);
    }
    
    // Update progress with placeholder data until service integration
    widgetService.updateReadingProgress(
      readingStreak: 7,
      chaptersCompleted: 3,
      totalReadingTime: 120,
      todayProgress: true,
      completedChapterIds: [1, 2, 3],
      achievements: ['week_streak', 'consistent_reader'],
    );
  }
  
  @override
  Widget build(BuildContext context) {
    return widget.child;
  }
}

/// Floating Action Button for widget testing (debug mode only)
class WidgetTestingFAB extends StatelessWidget {
  const WidgetTestingFAB({Key? key}) : super(key: key);
  
  @override
  Widget build(BuildContext context) {
    // Only show in debug mode
    if (!kDebugMode) return const SizedBox.shrink();
    
    return FloatingActionButton.extended(
      onPressed: () => _showWidgetTestDialog(context),
      backgroundColor: Colors.blue,
      icon: const Icon(Icons.widgets),
      label: const Text('Test Widgets'),
    );
  }
  
  void _showWidgetTestDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => const WidgetTestDialog(),
    );
  }
}

/// Dialog for testing widget functionality
class WidgetTestDialog extends StatefulWidget {
  const WidgetTestDialog({Key? key}) : super(key: key);
  
  @override
  State<WidgetTestDialog> createState() => _WidgetTestDialogState();
}

class _WidgetTestDialogState extends State<WidgetTestDialog> {
  bool _isLoading = false;
  String _status = '';
  
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Widget Testing'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(_status),
          if (_isLoading) 
            const Padding(
              padding: EdgeInsets.all(16.0),
              child: CircularProgressIndicator(),
            ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: _isLoading ? null : () => _testWidgetData(context),
          child: const Text('Update Widget Data'),
        ),
        TextButton(
          onPressed: _isLoading ? null : () => _showWidgetDebugInfo(context),
          child: const Text('Debug Info'),
        ),
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Close'),
        ),
      ],
    );
  }
  
  Future<void> _testWidgetData(BuildContext context) async {
    setState(() {
      _isLoading = true;
      _status = 'Updating widget data...';
    });
    
    try {
      final widgetService = Provider.of<WidgetService>(context, listen: false);
      
      // Force update all widget data with current app state
      final bookmarkService = Provider.of<BookmarkService>(context, listen: false);
      final progressService = Provider.of<ProgressService>(context, listen: false);
      final dailyVerseService = Provider.of<DailyVerseService>(context, listen: false);
      
      // Use placeholder data for now until service interfaces are clarified
      await widgetService.forceUpdateAllWidgetData(
        dailyVerse: null, // dailyVerseService interface TBD
        bookmarks: bookmarkService.bookmarks,
        readingStreak: 7,  // progressService interface TBD
        chaptersCompleted: 3,
        totalReadingTime: 120,
        todayProgress: true,
      );
      
      setState(() {
        _status = 'Widget data updated successfully!';
      });
      
    } catch (e) {
      setState(() {
        _status = 'Error updating widget data: $e';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }
  
  Future<void> _showWidgetDebugInfo(BuildContext context) async {
    setState(() {
      _isLoading = true;
      _status = 'Loading debug info...';
    });
    
    try {
      final widgetService = Provider.of<WidgetService>(context, listen: false);
      final debugInfo = await widgetService.getWidgetDebugInfo();
      
      setState(() {
        _status = 'Debug info loaded. Check console for details.';
      });
      
      // Print debug info to console
      print('=== WIDGET DEBUG INFO ===');
      debugInfo.forEach((key, value) {
        print('$key: $value');
      });
      print('========================');
      
    } catch (e) {
      setState(() {
        _status = 'Error loading debug info: $e';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }
}

/// Extension methods for easier widget service access
extension WidgetServiceHelper on BuildContext {
  WidgetService? get widgetService {
    try {
      return Provider.of<WidgetService>(this, listen: false);
    } catch (e) {
      return null;
    }
  }
  
  /// Quick method to update widget achievement
  Future<void> notifyWidgetAchievement({
    required String achievementId,
    required String title,
    required String description,
  }) async {
    final service = widgetService;
    if (service != null) {
      await service.updateAchievement(
        achievementId: achievementId,
        title: title,
        description: description,
        unlockedAt: DateTime.now(),
      );
    }
  }
}