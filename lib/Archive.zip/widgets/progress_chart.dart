// lib/widgets/progress_chart.dart

import 'package:flutter/material.dart';
import 'dart:math' as math;
import '../models/user_progress.dart';

class ProgressChart extends StatelessWidget {
  final Map<DateTime, List<UserProgress>> progressData;
  final int period;
  final String title;

  const ProgressChart({
    super.key,
    required this.progressData,
    required this.period,
    required this.title,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                title,
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.blue.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  '${period}d',
                  style: theme.textTheme.labelSmall?.copyWith(
                    color: Colors.blue.shade600,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 20),
          
          if (progressData.isEmpty)
            _buildEmptyChart(theme)
          else
            _buildChart(theme),
            
          const SizedBox(height: 16),
          _buildLegend(theme),
        ],
      ),
    );
  }

  Widget _buildEmptyChart(ThemeData theme) {
    return Container(
      height: 200,
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.bar_chart,
              size: 48,
              color: theme.colorScheme.onSurface.withOpacity(0.3),
            ),
            const SizedBox(height: 12),
            Text(
              'No data for this period',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: theme.colorScheme.onSurface.withOpacity(0.6),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildChart(ThemeData theme) {
    final maxValue = _getMaxValue();
    final chartData = _prepareChartData();
    
    return Container(
      height: 200,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: chartData.map((data) => _buildBar(data, maxValue, theme)).toList(),
      ),
    );
  }

  Widget _buildBar(ChartData data, double maxValue, ThemeData theme) {
    final height = maxValue > 0 ? (data.minutes / maxValue) * 160 : 0.0;
    
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 1),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            // Reading minutes bar
            Container(
              height: height,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.blue.shade400,
                    Colors.blue.shade600,
                  ],
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                ),
                borderRadius: const BorderRadius.vertical(top: Radius.circular(2)),
              ),
            ),
            
            const SizedBox(height: 8),
            
            // Date label
            Text(
              _formatDateLabel(data.date),
              style: theme.textTheme.labelSmall?.copyWith(
                color: theme.colorScheme.onSurface.withOpacity(0.6),
                fontSize: 10,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLegend(ThemeData theme) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        _buildLegendItem('Reading Time', Colors.blue, theme),
        _buildLegendItem('Peak: ${_getMaxValue().toInt()}m', Colors.green, theme),
        _buildLegendItem('Avg: ${_getAverageValue().toInt()}m', Colors.orange, theme),
      ],
    );
  }

  Widget _buildLegendItem(String label, Color color, ThemeData theme) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 12,
          height: 12,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 6),
        Text(
          label,
          style: theme.textTheme.labelSmall?.copyWith(
            color: theme.colorScheme.onSurface.withOpacity(0.7),
          ),
        ),
      ],
    );
  }

  List<ChartData> _prepareChartData() {
    final now = DateTime.now();
    final startDate = now.subtract(Duration(days: period - 1));
    final chartData = <ChartData>[];
    
    for (int i = 0; i < period; i++) {
      final date = startDate.add(Duration(days: i));
      final dayData = progressData[DateTime(date.year, date.month, date.day)] ?? [];
      
      final totalMinutes = dayData.fold<double>(
        0.0, 
        (sum, progress) => sum + progress.sessionDurationMinutes.toDouble(),
      );
      
      final versesRead = dayData.where((p) => p.progressType == ProgressType.verseRead).length;
      
      chartData.add(ChartData(
        date: date,
        minutes: totalMinutes,
        verses: versesRead,
      ));
    }
    
    return chartData;
  }

  double _getMaxValue() {
    if (progressData.isEmpty) return 60.0; // Default max
    
    double max = 0;
    for (final dayProgress in progressData.values) {
      final dayTotal = dayProgress.fold<double>(
        0.0,
        (sum, progress) => sum + progress.sessionDurationMinutes.toDouble(),
      );
      max = math.max(max, dayTotal);
    }
    
    return math.max(max, 10.0); // Minimum 10 minutes for scale
  }

  double _getAverageValue() {
    if (progressData.isEmpty) return 0.0;
    
    double total = 0;
    int days = 0;
    
    for (final dayProgress in progressData.values) {
      final dayTotal = dayProgress.fold<double>(
        0.0,
        (sum, progress) => sum + progress.sessionDurationMinutes.toDouble(),
      );
      if (dayTotal > 0) {
        total += dayTotal;
        days++;
      }
    }
    
    return days > 0 ? total / days : 0.0;
  }

  String _formatDateLabel(DateTime date) {
    switch (period) {
      case 7:
        // Show day abbreviations for week view
        const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        return days[date.weekday % 7];
      case 30:
        // Show day numbers for month view
        return '${date.day}';
      case 90:
        // Show month/day for quarter view
        return '${date.month}/${date.day}';
      default:
        return '${date.day}';
    }
  }
}

class ChartData {
  final DateTime date;
  final double minutes;
  final int verses;

  ChartData({
    required this.date,
    required this.minutes,
    required this.verses,
  });
}