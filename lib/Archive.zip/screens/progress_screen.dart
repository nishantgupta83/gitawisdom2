// lib/screens/progress_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/progress_service.dart';
import '../widgets/progress_chart.dart';
import '../widgets/achievement_card.dart';
import '../widgets/stats_card.dart';
import '../widgets/streak_indicator.dart';

class ProgressScreen extends StatefulWidget {
  const ProgressScreen({super.key});

  @override
  State<ProgressScreen> createState() => _ProgressScreenState();
}

class _ProgressScreenState extends State<ProgressScreen>
    with TickerProviderStateMixin {
  late TabController _tabController;
  int _selectedPeriod = 30; // Days

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      appBar: _buildAppBar(theme),
      body: Consumer<ProgressService>(
        builder: (context, progressService, child) {
          if (progressService.isLoading && progressService.userSettings == null) {
            return _buildLoadingState(theme);
          }

          return RefreshIndicator(
            onRefresh: () => progressService.forceSync(),
            child: SingleChildScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              child: Column(
                children: [
                  _buildQuickStats(progressService, theme),
                  const SizedBox(height: 16),
                  _buildPeriodSelector(theme),
                  const SizedBox(height: 16),
                  _buildTabView(progressService, theme),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(ThemeData theme) {
    return AppBar(
      backgroundColor: theme.colorScheme.surface,
      elevation: 0,
      title: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.green.shade400,
                  Colors.teal.shade500,
                ],
              ),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(
              Icons.trending_up,
              color: Colors.white,
              size: 24,
            ),
          ),
          const SizedBox(width: 12),
          Text(
            'My Progress',
            style: theme.textTheme.headlineMedium?.copyWith(
              fontWeight: FontWeight.bold,
              color: theme.colorScheme.onSurface,
            ),
          ),
        ],
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.settings),
          onPressed: _showGoalSettings,
          tooltip: 'Reading Goals',
        ),
      ],
    );
  }

  Widget _buildQuickStats(ProgressService progressService, ThemeData theme) {
    final stats = progressService.getReadingStats();
    
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Colors.blue.shade50,
            Colors.indigo.shade50,
            Colors.purple.shade50,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.blue.withOpacity(0.1),
            blurRadius: 15,
            spreadRadius: 2,
            offset: const Offset(0, 5),
          ),
        ],
        border: Border.all(
          color: Colors.blue.withOpacity(0.2),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          // Streak Indicator
          StreakIndicator(
            currentStreak: stats['readingStreak'] ?? 0,
            longestStreak: stats['longestStreak'] ?? 0,
            isActive: stats['dailyGoalMet'] ?? false,
          ),
          
          const SizedBox(height: 20),
          
          // Quick Stats Grid
          Row(
            children: [
              Expanded(
                child: StatsCard(
                  title: 'Chapters',
                  value: '${stats['chaptersCompleted']}/${stats['totalChapters']}',
                  subtitle: '${stats['completionPercentage']}% Complete',
                  icon: Icons.menu_book,
                  color: Colors.blue,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: StatsCard(
                  title: 'Reading Time',
                  value: '${stats['totalReadingHours']}h',
                  subtitle: 'Total Hours',
                  icon: Icons.schedule,
                  color: Colors.green,
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 12),
          
          Row(
            children: [
              Expanded(
                child: StatsCard(
                  title: 'Today',
                  value: '${stats['todayMinutes']}m',
                  subtitle: 'Goal: ${stats['dailyGoalMinutes']}m',
                  icon: Icons.today,
                  color: stats['dailyGoalMet'] == true ? Colors.green : Colors.orange,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: StatsCard(
                  title: 'Achievements',
                  value: '${stats['achievementsCount']}',
                  subtitle: 'Unlocked',
                  icon: Icons.emoji_events,
                  color: Colors.purple,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildPeriodSelector(ThemeData theme) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          Text(
            'Period: ',
            style: theme.textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(width: 8),
          ...[ 7, 30, 90].map((days) => Padding(
            padding: const EdgeInsets.only(right: 8),
            child: FilterChip(
              label: Text(days == 7 ? 'Week' : days == 30 ? 'Month' : 'Quarter'),
              selected: _selectedPeriod == days,
              onSelected: (selected) {
                if (selected) {
                  setState(() => _selectedPeriod = days);
                }
              },
              backgroundColor: theme.colorScheme.surfaceVariant.withOpacity(0.3),
              selectedColor: theme.colorScheme.primaryContainer,
              showCheckmark: false,
            ),
          )),
        ],
      ),
    );
  }

  Widget _buildTabView(ProgressService progressService, ThemeData theme) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      height: 600,
      child: Column(
        children: [
          TabBar(
            controller: _tabController,
            labelColor: theme.colorScheme.primary,
            unselectedLabelColor: theme.colorScheme.onSurface.withOpacity(0.6),
            indicatorColor: theme.colorScheme.primary,
            tabs: const [
              Tab(text: 'Charts', icon: Icon(Icons.bar_chart)),
              Tab(text: 'Achievements', icon: Icon(Icons.emoji_events)),
              Tab(text: 'Activity', icon: Icon(Icons.history)),
            ],
          ),
          
          const SizedBox(height: 16),
          
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildChartsTab(progressService, theme),
                _buildAchievementsTab(progressService, theme),
                _buildActivityTab(progressService, theme),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChartsTab(ProgressService progressService, ThemeData theme) {
    return SingleChildScrollView(
      child: Column(
        children: [
          // Reading Progress Chart
          ProgressChart(
            progressData: progressService.getProgressByDate(_selectedPeriod),
            period: _selectedPeriod,
            title: 'Reading Activity',
          ),
          
          const SizedBox(height: 20),
          
          // Chapter Completion Chart
          _buildChapterCompletionChart(progressService, theme),
        ],
      ),
    );
  }

  Widget _buildAchievementsTab(ProgressService progressService, ThemeData theme) {
    final settings = progressService.userSettings;
    if (settings == null) return const SizedBox.shrink();
    
    final achievements = _getAchievementsList(settings, progressService.getReadingStats());
    
    return ListView.builder(
      padding: const EdgeInsets.only(bottom: 20),
      itemCount: achievements.length,
      itemBuilder: (context, index) {
        final achievement = achievements[index];
        return AchievementCard(
          achievement: achievement,
          isUnlocked: settings.achievementsUnlocked.contains(achievement['id']),
        );
      },
    );
  }

  Widget _buildActivityTab(ProgressService progressService, ThemeData theme) {
    final recentActivity = progressService.getRecentActivity(_selectedPeriod);
    
    if (recentActivity.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.history,
              size: 64,
              color: theme.colorScheme.onSurface.withOpacity(0.3),
            ),
            const SizedBox(height: 16),
            Text(
              'No Recent Activity',
              style: theme.textTheme.titleLarge?.copyWith(
                color: theme.colorScheme.onSurface.withOpacity(0.6),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Start reading to see your activity here',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: theme.colorScheme.onSurface.withOpacity(0.4),
              ),
            ),
          ],
        ),
      );
    }
    
    return ListView.builder(
      padding: const EdgeInsets.only(bottom: 20),
      itemCount: recentActivity.length,
      itemBuilder: (context, index) {
        final activity = recentActivity[index];
        return _buildActivityItem(activity, theme);
      },
    );
  }

  Widget _buildChapterCompletionChart(ProgressService progressService, ThemeData theme) {
    final settings = progressService.userSettings;
    if (settings == null) return const SizedBox.shrink();
    
    final completedChapters = settings.chaptersCompleted.length;
    final totalChapters = 18;
    final percentage = completedChapters / totalChapters;
    
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Gita Completion',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          
          // Progress Bar
          LinearProgressIndicator(
            value: percentage,
            backgroundColor: theme.colorScheme.surfaceVariant,
            valueColor: AlwaysStoppedAnimation<Color>(Colors.green.shade500),
            minHeight: 8,
          ),
          
          const SizedBox(height: 12),
          
          Text(
            '$completedChapters of $totalChapters chapters (${(percentage * 100).toInt()}%)',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurface.withOpacity(0.7),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActivityItem(dynamic activity, ThemeData theme) {
    IconData icon;
    Color color;
    String title;
    String subtitle;

    switch (activity.progressType) {
      case ProgressType.verseRead:
        icon = Icons.format_quote;
        color = Colors.blue;
        title = 'Read Verse ${activity.verseId}';
        subtitle = 'Chapter ${activity.chapterId}';
        break;
      case ProgressType.chapterStarted:
        icon = Icons.play_circle_outline;
        color = Colors.orange;
        title = 'Started Chapter ${activity.chapterId}';
        subtitle = 'Reading session began';
        break;
      case ProgressType.chapterCompleted:
        icon = Icons.check_circle;
        color = Colors.green;
        title = 'Completed Chapter ${activity.chapterId}';
        subtitle = '${(activity.progressValue! * 100).toInt()}% completion';
        break;
      case ProgressType.sessionTime:
        icon = Icons.schedule;
        color = Colors.purple;
        title = 'Reading Session';
        subtitle = '${activity.sessionDurationMinutes} minutes';
        break;
      case ProgressType.streakMilestone:
        icon = Icons.local_fire_department;
        color = Colors.red;
        title = 'Streak Milestone!';
        subtitle = '${activity.progressValue!.toInt()} days';
        break;
      default:
        icon = Icons.circle;
        color = Colors.grey;
        title = 'Activity';
        subtitle = 'Progress tracked';
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: theme.colorScheme.outline.withOpacity(0.2),
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text(
                  subtitle,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurface.withOpacity(0.6),
                  ),
                ),
              ],
            ),
          ),
          Text(
            _formatDate(activity.createdAt),
            style: theme.textTheme.labelSmall?.copyWith(
              color: theme.colorScheme.onSurface.withOpacity(0.5),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingState(ThemeData theme) {
    return const Center(
      child: CircularProgressIndicator(),
    );
  }

  // Helper methods

  List<Map<String, dynamic>> _getAchievementsList(settings, stats) {
    return [
      {
        'id': 'first_chapter',
        'title': 'First Chapter',
        'description': 'Complete your first chapter',
        'icon': Icons.star,
        'color': Colors.yellow,
      },
      {
        'id': 'half_gita',
        'title': 'Halfway There',
        'description': 'Complete 9 chapters of the Gita',
        'icon': Icons.trending_up,
        'color': Colors.orange,
      },
      {
        'id': 'full_gita',
        'title': 'Gita Master',
        'description': 'Complete all 18 chapters',
        'icon': Icons.emoji_events,
        'color': Colors.gold,
      },
      {
        'id': 'week_streak',
        'title': 'Week Warrior',
        'description': 'Read for 7 consecutive days',
        'icon': Icons.local_fire_department,
        'color': Colors.red,
      },
      {
        'id': 'month_streak',
        'title': 'Monthly Master',
        'description': 'Read for 30 consecutive days',
        'icon': Icons.whatshot,
        'color': Colors.deepOrange,
      },
      {
        'id': 'ten_hours',
        'title': 'Dedicated Reader',
        'description': 'Read for 10+ hours total',
        'icon': Icons.schedule,
        'color': Colors.blue,
      },
    ];
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);
    
    if (difference.inDays == 0) {
      return 'Today';
    } else if (difference.inDays == 1) {
      return 'Yesterday';
    } else if (difference.inDays < 7) {
      return '${difference.inDays}d ago';
    } else {
      return '${date.day}/${date.month}';
    }
  }

  void _showGoalSettings() {
    // TODO: Implement reading goal settings dialog
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Reading Goals'),
        content: const Text('Goal settings coming soon!'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }
}