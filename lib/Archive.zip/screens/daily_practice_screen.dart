// lib/screens/daily_practice_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/daily_practice.dart';
import '../services/practice_service.dart';
import '../services/meditation_service.dart';
import 'meditation_screen.dart';

class DailyPracticeScreen extends StatefulWidget {
  const DailyPracticeScreen({Key? key}) : super(key: key);

  @override
  State<DailyPracticeScreen> createState() => _DailyPracticeScreenState();
}

class _DailyPracticeScreenState extends State<DailyPracticeScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _initializeServices();
  }
  
  Future<void> _initializeServices() async {
    final practiceService = PracticeService.instance;
    if (!practiceService.isInitialized) {
      await practiceService.initialize();
      if (mounted) setState(() {});
    }
  }
  
  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Daily Practice'),
        elevation: 0,
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: Theme.of(context).primaryColor,
          tabs: const [
            Tab(text: 'Challenges', icon: Icon(Icons.task_alt, size: 20)),
            Tab(text: 'Meditation', icon: Icon(Icons.self_improvement, size: 20)),
            Tab(text: 'Progress', icon: Icon(Icons.trending_up, size: 20)),
          ],
        ),
      ),
      body: ChangeNotifierProvider.value(
        value: PracticeService.instance,
        child: TabBarView(
          controller: _tabController,
          children: [
            _buildChallengesTab(),
            _buildMeditationTab(),
            _buildProgressTab(),
          ],
        ),
      ),
    );
  }
  
  Widget _buildChallengesTab() {
    return Consumer<PracticeService>(
      builder: (context, practiceService, child) {
        if (!practiceService.isInitialized) {
          return const Center(child: CircularProgressIndicator());
        }
        
        final challenges = practiceService.todaysChallenges;
        final completedCount = challenges.where((c) => c.isCompleted).length;
        
        return Column(
          children: [
            _buildDailyHeader(completedCount, challenges.length),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: challenges.length,
                itemBuilder: (context, index) {
                  return _buildChallengeCard(challenges[index]);
                },
              ),
            ),
          ],
        );
      },
    );
  }
  
  Widget _buildDailyHeader(int completed, int total) {
    final progress = total > 0 ? completed / total : 0.0;
    
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Colors.deepOrange.shade600,
            Colors.orange.shade400,
            Colors.amber.shade300,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          stops: const [0.0, 0.6, 1.0],
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.orange.withOpacity(0.3),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Today\'s Practice Journey',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.5,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.25),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      '$completed of $total completed',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
              Stack(
                alignment: Alignment.center,
                children: [
                  SizedBox(
                    width: 70,
                    height: 70,
                    child: CircularProgressIndicator(
                      value: progress,
                      backgroundColor: Colors.white.withOpacity(0.2),
                      valueColor: const AlwaysStoppedAnimation<Color>(Colors.white),
                      strokeWidth: 8,
                      strokeCap: StrokeCap.round,
                    ),
                  ),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        '${(progress * 100).round()}%',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const Text(
                        'complete',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),
          _buildStreakIndicators(),
        ],
      ),
    );
  }
  
  Widget _buildStreakIndicators() {
    return Consumer<PracticeService>(
      builder: (context, practiceService, child) {
        final overallStreak = practiceService.currentOverallStreak;
        final points = practiceService.totalPracticePoints;
        
        return Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildStreakBadge(
              icon: Icons.local_fire_department,
              label: 'Streak',
              value: '$overallStreak days',
            ),
            _buildStreakBadge(
              icon: Icons.stars,
              label: 'Points',
              value: points.toString(),
            ),
          ],
        );
      },
    );
  }
  
  Widget _buildStreakBadge({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.2),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: [
          Icon(icon, color: Colors.white, size: 20),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.9),
                  fontSize: 12,
                ),
              ),
              Text(
                value,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
  
  Widget _buildChallengeCard(DailyChallenge challenge) {
    final iconMap = {
      'book': Icons.book,
      'self_improvement': Icons.self_improvement,
      'edit_note': Icons.edit_note,
      'favorite': Icons.favorite,
      'volunteer_activism': Icons.volunteer_activism,
    };
    
    final icon = iconMap[challenge.iconName] ?? Icons.task_alt;
    final practiceTypeColors = {
      PracticeType.reading: Colors.blue,
      PracticeType.meditation: Colors.purple,
      PracticeType.reflection: Colors.orange,
      PracticeType.gratitude: Colors.pink,
      PracticeType.service: Colors.green,
      PracticeType.chanting: Colors.indigo,
      PracticeType.mindfulness: Colors.teal,
    };
    
    final color = practiceTypeColors[challenge.practiceType] ?? Theme.of(context).primaryColor;
    
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: challenge.isCompleted ? 0 : 2,
      child: InkWell(
        onTap: challenge.isCompleted ? null : () => _showChallengeDialog(challenge),
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            color: challenge.isCompleted 
                ? color.withOpacity(0.1)
                : null,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(icon, color: color, size: 24),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          challenge.title,
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            decoration: challenge.isCompleted 
                                ? TextDecoration.lineThrough 
                                : null,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          challenge.description,
                          style: TextStyle(
                            fontSize: 14,
                            color: Theme.of(context).textTheme.bodySmall?.color,
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (challenge.isCompleted)
                    Icon(Icons.check_circle, color: color, size: 28)
                  else
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                      decoration: BoxDecoration(
                        color: color.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        '+${challenge.rewardPoints} pts',
                        style: TextStyle(
                          color: color,
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                        ),
                      ),
                    ),
                ],
              ),
              if (!challenge.isCompleted) ...[
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: LinearProgressIndicator(
                        value: challenge.progressPercentage,
                        backgroundColor: color.withOpacity(0.2),
                        valueColor: AlwaysStoppedAnimation<Color>(color),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      '${challenge.currentProgress}/${challenge.targetValue} ${challenge.targetUnit}',
                      style: TextStyle(
                        fontSize: 12,
                        color: color,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
  
  Widget _buildMeditationTab() {
    final templates = MeditationService.instance.meditationTemplates;
    final recommended = MeditationService.instance.getRecommendedMeditation();
    
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildMeditationStats(),
        const SizedBox(height: 20),
        Text(
          'Recommended for You',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        _buildMeditationCard(recommended, isRecommended: true),
        const SizedBox(height: 20),
        Text(
          'All Meditations',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        ...templates.map((template) => _buildMeditationCard(template)),
      ],
    );
  }
  
  Widget _buildMeditationStats() {
    return Consumer<MeditationService>(
      builder: (context, meditationService, child) {
        return Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Colors.purple.shade400,
                Colors.purple.shade600,
              ],
            ),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildStatColumn(
                label: 'Total Minutes',
                value: meditationService.totalMeditationMinutes.toString(),
                icon: Icons.timer,
              ),
              _buildStatColumn(
                label: 'Sessions',
                value: meditationService.totalSessions.toString(),
                icon: Icons.self_improvement,
              ),
              _buildStatColumn(
                label: 'Avg Rating',
                value: meditationService.averageRating.toStringAsFixed(1),
                icon: Icons.star,
              ),
            ],
          ),
        );
      },
    );
  }
  
  Widget _buildStatColumn({
    required String label,
    required String value,
    required IconData icon,
  }) {
    return Column(
      children: [
        Icon(icon, color: Colors.white, size: 24),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            color: Colors.white.withOpacity(0.9),
            fontSize: 12,
          ),
        ),
      ],
    );
  }
  
  Widget _buildMeditationCard(MeditationTemplate template, {bool isRecommended = false}) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: isRecommended ? 4 : 2,
      child: InkWell(
        onTap: () => _startMeditation(template),
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: isRecommended ? Border.all(
              color: Colors.purple.shade300,
              width: 2,
            ) : null,
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.purple.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(
                  Icons.self_improvement,
                  color: Colors.purple,
                  size: 28,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            template.title,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        if (isRecommended)
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: Colors.purple.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: const Text(
                              'RECOMMENDED',
                              style: TextStyle(
                                color: Colors.purple,
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      template.description,
                      style: TextStyle(
                        fontSize: 14,
                        color: Theme.of(context).textTheme.bodySmall?.color,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Icon(
                          Icons.timer,
                          size: 16,
                          color: Theme.of(context).textTheme.bodySmall?.color,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          '${template.durationMinutes} minutes',
                          style: TextStyle(
                            fontSize: 12,
                            color: Theme.of(context).textTheme.bodySmall?.color,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Icon(
                          Icons.music_note,
                          size: 16,
                          color: Theme.of(context).textTheme.bodySmall?.color,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          template.musicTheme.toString().split('.').last,
                          style: TextStyle(
                            fontSize: 12,
                            color: Theme.of(context).textTheme.bodySmall?.color,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Icon(
                Icons.arrow_forward_ios,
                color: Theme.of(context).textTheme.bodySmall?.color,
                size: 16,
              ),
            ],
          ),
        ),
      ),
    );
  }
  
  Widget _buildProgressTab() {
    return Consumer<PracticeService>(
      builder: (context, practiceService, child) {
        final streaks = practiceService.streaks;
        
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _buildOverallProgress(practiceService),
            const SizedBox(height: 20),
            Text(
              'Practice Streaks',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            ...PracticeType.values.map((type) {
              final streak = streaks[type];
              return _buildStreakCard(type, streak);
            }),
            const SizedBox(height: 20),
            _buildSuggestedPractices(practiceService),
          ],
        );
      },
    );
  }
  
  Widget _buildOverallProgress(PracticeService practiceService) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Colors.indigo.shade600,
            Colors.purple.shade500,
            Colors.deepPurple.shade400,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          stops: const [0.0, 0.5, 1.0],
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.purple.withOpacity(0.3),
            blurRadius: 15,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        children: [
          const Text(
            'Your Spiritual Journey',
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildProgressStat(
                icon: Icons.local_fire_department,
                value: practiceService.currentOverallStreak.toString(),
                label: 'Day Streak',
              ),
              _buildProgressStat(
                icon: Icons.stars,
                value: practiceService.totalPracticePoints.toString(),
                label: 'Total Points',
              ),
              _buildProgressStat(
                icon: Icons.emoji_events,
                value: _getLevel(practiceService.totalPracticePoints),
                label: 'Level',
              ),
            ],
          ),
        ],
      ),
    );
  }
  
  Widget _buildProgressStat({
    required IconData icon,
    required String value,
    required String label,
  }) {
    return Column(
      children: [
        Icon(icon, color: Colors.white, size: 32),
        const SizedBox(height: 8),
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            color: Colors.white.withOpacity(0.9),
            fontSize: 12,
          ),
        ),
      ],
    );
  }
  
  Widget _buildStreakCard(PracticeType type, PracticeStreak? streak) {
    final typeNames = {
      PracticeType.reading: 'Reading',
      PracticeType.meditation: 'Meditation',
      PracticeType.reflection: 'Reflection',
      PracticeType.gratitude: 'Gratitude',
      PracticeType.service: 'Service',
      PracticeType.chanting: 'Chanting',
      PracticeType.mindfulness: 'Mindfulness',
    };
    
    final typeIcons = {
      PracticeType.reading: Icons.book,
      PracticeType.meditation: Icons.self_improvement,
      PracticeType.reflection: Icons.edit_note,
      PracticeType.gratitude: Icons.favorite,
      PracticeType.service: Icons.volunteer_activism,
      PracticeType.chanting: Icons.music_note,
      PracticeType.mindfulness: Icons.spa,
    };
    
    final currentStreak = streak?.currentStreak ?? 0;
    final bestStreak = streak?.bestStreak ?? 0;
    final isActiveToday = streak?.isActiveToday ?? false;
    
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: isActiveToday 
                ? Colors.green.withOpacity(0.2)
                : Colors.grey.withOpacity(0.2),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(
            typeIcons[type],
            color: isActiveToday ? Colors.green : Colors.grey,
          ),
        ),
        title: Text(typeNames[type] ?? ''),
        subtitle: Text('Best streak: $bestStreak days'),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (currentStreak > 0) ...[
              Icon(
                Icons.local_fire_department,
                color: Colors.orange,
                size: 20,
              ),
              const SizedBox(width: 4),
              Text(
                '$currentStreak',
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ] else
              Text(
                'Start today',
                style: TextStyle(
                  color: Theme.of(context).textTheme.bodySmall?.color,
                  fontSize: 12,
                ),
              ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildSuggestedPractices(PracticeService practiceService) {
    final suggestions = practiceService.getSuggestedPractices();
    
    if (suggestions.isEmpty) return const SizedBox.shrink();
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Suggested Practices',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        ...suggestions.map((suggestion) => Card(
          child: ListTile(
            leading: const Icon(Icons.lightbulb_outline, color: Colors.amber),
            title: Text(suggestion),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
          ),
        )),
      ],
    );
  }
  
  void _showChallengeDialog(DailyChallenge challenge) {
    showDialog(
      context: context,
      builder: (context) => _ChallengeProgressDialog(challenge: challenge),
    );
  }
  
  void _startMeditation(MeditationTemplate template) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => MeditationScreen(template: template),
      ),
    );
  }
  
  String _getLevel(int points) {
    if (points < 100) return 'Seeker';
    if (points < 500) return 'Student';
    if (points < 1000) return 'Practitioner';
    if (points < 2500) return 'Devotee';
    if (points < 5000) return 'Master';
    return 'Sage';
  }
}

class _ChallengeProgressDialog extends StatefulWidget {
  final DailyChallenge challenge;
  
  const _ChallengeProgressDialog({required this.challenge});
  
  @override
  State<_ChallengeProgressDialog> createState() => _ChallengeProgressDialogState();
}

class _ChallengeProgressDialogState extends State<_ChallengeProgressDialog> {
  late int _progress;
  
  @override
  void initState() {
    super.initState();
    _progress = widget.challenge.currentProgress;
  }
  
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.challenge.title),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(widget.challenge.description),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(
                onPressed: _progress > 0 ? () => setState(() => _progress--) : null,
                icon: const Icon(Icons.remove_circle_outline),
              ),
              Column(
                children: [
                  Text(
                    '$_progress / ${widget.challenge.targetValue}',
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    widget.challenge.targetUnit,
                    style: TextStyle(
                      color: Theme.of(context).textTheme.bodySmall?.color,
                    ),
                  ),
                ],
              ),
              IconButton(
                onPressed: _progress < widget.challenge.targetValue 
                    ? () => setState(() => _progress++) 
                    : null,
                icon: const Icon(Icons.add_circle_outline),
              ),
            ],
          ),
          const SizedBox(height: 16),
          LinearProgressIndicator(
            value: widget.challenge.targetValue > 0 
                ? _progress / widget.challenge.targetValue 
                : 0,
            minHeight: 8,
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: () async {
            await PracticeService.instance.updateChallengeProgress(
              widget.challenge.id,
              _progress,
            );
            if (context.mounted) {
              Navigator.pop(context);
              if (_progress >= widget.challenge.targetValue) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('🎉 Challenge completed! +${widget.challenge.rewardPoints} points'),
                    backgroundColor: Colors.green,
                  ),
                );
              }
            }
          },
          child: const Text('Update Progress'),
        ),
      ],
    );
  }
}