// lib/screens/root_scaffold.dart

import 'package:flutter/material.dart';
import '../core/app_config.dart';
import '../core/navigation/navigation_service.dart';
import '../l10n/app_localizations.dart';
import '../widgets/custom_nav_bar.dart';
import 'home_screen.dart';
import 'chapters_screen.dart';
import 'scenarios_screen.dart';
import 'daily_practice_screen.dart';
import 'more_screen.dart';

/// Root scaffold with bottom navigation
/// Moved from main.dart and cleaned up with proper service integration
class RootScaffold extends StatefulWidget {
  const RootScaffold({Key? key}) : super(key: key);
  
  @override
  State<RootScaffold> createState() => _RootScaffoldState();
}

class _RootScaffoldState extends State<RootScaffold> with WidgetsBindingObserver {
  int _currentIndex = 0;
  int? _pendingChapterFilter;
  late List<Widget> _pages;

  @override
  void initState() {
    super.initState();
    _initializePages();
    _initializeNavigationService();
    WidgetsBinding.instance.addObserver(this);
  }

  /// Initialize navigation service with callbacks
  void _initializeNavigationService() {
    NavigationService.instance.initialize(
      onTabChanged: _selectTab,
      onGoToScenariosWithChapter: _goToScenariosWithChapter,
    );
  }

  /// Initialize pages for bottom navigation
  void _initializePages() {
    _pages = [
      HomeScreen(onTabChange: _selectTab),
      ChapterScreen(),
      ScenariosScreen(
        key: ValueKey('chapter_filter_${_pendingChapterFilter ?? 'all'}'),
        filterChapter: _pendingChapterFilter,
      ),
      const DailyPracticeScreen(),
      MoreScreen(),
    ];
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    
    // Reset to home screen when app resumes for better UX
    if (state == AppLifecycleState.resumed && _currentIndex != 0) {
      debugPrint('🏠 App resumed - resetting to home screen');
      _selectTab(0);
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    NavigationService.instance.dispose();
    super.dispose();
  }

  /// Select a tab by index
  void _selectTab(int index) {
    if (index >= 0 && index < _pages.length) {
      setState(() {
        _currentIndex = index;
      });
    }
  }

  /// Navigate to scenarios with chapter filter
  void _goToScenariosWithChapter(int chapterId) {
    debugPrint('🔧 Navigating to scenarios with chapter filter: $chapterId');
    
    _pendingChapterFilter = chapterId;
    
    // Update scenarios screen with new filter (force rebuild with unique key)
    setState(() {
      _pages[2] = ScenariosScreen(
        key: ValueKey('chapter_filter_$_pendingChapterFilter'),
        filterChapter: _pendingChapterFilter,
      );
      _currentIndex = 2; // Switch to scenarios tab
    });
    
    debugPrint('🔧 Switched to scenarios tab with filter: $chapterId');
  }

  /// Handle back button behavior
  Future<bool> _onWillPop() async {
    // Go to home tab if not already there
    if (_currentIndex != 0) {
      _selectTab(0);
      return false; // Don't exit app
    }
    return true; // Exit app
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        body: Stack(
          children: [
            // Background image for main scaffold
            Positioned.fill(
              child: Image.asset(
                AppConfig.appBackgroundImage,
                fit: BoxFit.cover,
                color: isDark 
                    ? Color.fromARGB((0.32 * 255).toInt(), 0, 0, 0) 
                    : null,
                colorBlendMode: isDark ? BlendMode.darken : null,
                errorBuilder: (context, error, stackTrace) {
                  debugPrint('❌ Root background image failed to load: $error');
                  return Container(color: theme.scaffoldBackgroundColor);
                },
              ),
            ),
            
            // Tab content using IndexedStack for better performance
            IndexedStack(
              index: _currentIndex,
              children: _pages,
            ),
          ],
        ),
        
        // Custom bottom navigation bar
        bottomNavigationBar: CustomNavBar(
          currentIndex: _currentIndex,
          onTap: _selectTab,
          items: [
            NavBarItem(
              icon: Icons.home, 
              label: AppLocalizations.of(context)!.homeTab,
            ),
            NavBarItem(
              icon: Icons.menu_book, 
              label: AppLocalizations.of(context)!.chaptersTab,
            ),
            NavBarItem(
              icon: Icons.list, 
              label: AppLocalizations.of(context)!.scenariosTab,
            ),
            NavBarItem(
              icon: Icons.self_improvement, 
              label: 'Practice',
            ),
            NavBarItem(
              icon: Icons.more_horiz, 
              label: AppLocalizations.of(context)!.moreTab,
            ),
          ],
        ),
      ),
    );
  }
}