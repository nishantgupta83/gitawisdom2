// lib/services/enhanced_audio_service.dart

import 'package:flutter/foundation.dart';
import 'package:hive/hive.dart';
import 'narration_service.dart';
import 'background_music_service.dart' show BackgroundMusicService, MusicTheme;
import 'settings_service.dart';
import '../models/verse.dart';
import '../models/scenario.dart';

/// Enhanced audio service that coordinates narration and background music
/// Handles smart audio ducking and unified audio controls
class EnhancedAudioService extends ChangeNotifier {
  static final EnhancedAudioService _instance = EnhancedAudioService._internal();
  factory EnhancedAudioService() => _instance;
  EnhancedAudioService._internal();

  static EnhancedAudioService get instance => _instance;

  // Service instances
  late final NarrationService _narrationService;
  late final BackgroundMusicService _backgroundMusicService;

  bool _isInitialized = false;
  bool _narrationEnabled = true;
  bool _backgroundMusicEnabled = true;

  // Getters for service access
  NarrationService get narration => _narrationService;
  BackgroundMusicService get backgroundMusic => _backgroundMusicService;
  
  bool get isInitialized => _isInitialized;
  bool get narrationEnabled => _narrationEnabled;
  bool get backgroundMusicEnabled => _backgroundMusicEnabled;

  /// Initialize the enhanced audio service (lazy loading)
  Future<void> initialize() async {
    if (_isInitialized) return;

    try {
      // Initialize individual services lazily - don't auto-start
      _narrationService = NarrationService.instance;
      _backgroundMusicService = BackgroundMusicService.instance;

      // Load saved settings first (no audio initialization yet)
      await _loadSettings();

      // Set up narration listeners for smart ducking
      _narrationService.addListener(_onNarrationStateChanged);

      _isInitialized = true;
      debugPrint('✅ EnhancedAudioService initialized (lazy mode)');
      notifyListeners();
    } catch (e) {
      debugPrint('❌ Failed to initialize EnhancedAudioService: $e');
    }
  }

  /// Initialize audio systems only when first needed
  Future<void> _ensureAudioInitialized() async {
    if (_narrationService.isInitialized && _backgroundMusicService.isInitialized) {
      return;
    }

    try {
      if (!_narrationService.isInitialized) {
        await _narrationService.initialize();
      }
      if (!_backgroundMusicService.isInitialized) {
        await _backgroundMusicService.initialize();
      }
      debugPrint('✅ Audio systems initialized on-demand');
    } catch (e) {
      debugPrint('❌ Failed to initialize audio systems: $e');
    }
  }

  /// Load audio settings from storage
  Future<void> _loadSettings() async {
    try {
      final box = Hive.box(SettingsService.boxName);
      _narrationEnabled = box.get('narration_enabled', defaultValue: true) as bool;
      _backgroundMusicEnabled = box.get('background_music_enabled', defaultValue: true) as bool;

      // Apply loaded settings
      await _backgroundMusicService.setEnabled(_backgroundMusicEnabled);
      
      debugPrint('📚 Audio settings loaded - Narration: $_narrationEnabled, Music: $_backgroundMusicEnabled');
    } catch (e) {
      debugPrint('⚠️ Failed to load audio settings: $e');
    }
  }

  /// Save audio settings to storage
  Future<void> _saveSettings() async {
    try {
      final box = Hive.box(SettingsService.boxName);
      await box.put('narration_enabled', _narrationEnabled);
      await box.put('background_music_enabled', _backgroundMusicEnabled);
    } catch (e) {
      debugPrint('⚠️ Failed to save audio settings: $e');
    }
  }

  /// Handle narration state changes for smart ducking
  void _onNarrationStateChanged() {
    if (_narrationService.isPlaying) {
      // Duck background music when narration starts
      _backgroundMusicService.duck();
    } else if (!_narrationService.isPlaying && !_narrationService.isPaused) {
      // Unduck when narration stops (not just paused)
      _backgroundMusicService.unduck();
    }
  }

  /// Play narration for a verse with smart audio management
  Future<bool> playVerseNarration(Verse verse) async {
    if (!_narrationEnabled) {
      debugPrint('🎤 Narration disabled - skipping verse playback');
      return false;
    }

    if (!_isInitialized) {
      await initialize();
    }

    // Initialize audio systems only when needed
    await _ensureAudioInitialized();

    try {
      final result = await _narrationService.playVerse(verse);
      if (result) {
        debugPrint('🎤 Playing verse narration: ${verse.chapterId}.${verse.verseId}');
      }
      return result;
    } catch (e) {
      debugPrint('❌ Failed to play verse narration: $e');
      return false;
    }
  }

  /// Play narration for a scenario with smart audio management
  Future<bool> playScenarioNarration(Scenario scenario) async {
    if (!_narrationEnabled) {
      debugPrint('🎤 Narration disabled - skipping scenario playbook');
      return false;
    }

    if (!_isInitialized) {
      await initialize();
    }

    // Initialize audio systems only when needed
    await _ensureAudioInitialized();

    try {
      final result = await _narrationService.playScenario(scenario);
      if (result) {
        debugPrint('🎤 Playing scenario narration: ${scenario.title}');
      }
      return result;
    } catch (e) {
      debugPrint('❌ Failed to play scenario narration: $e');
      return false;
    }
  }

  /// Start background music for reading/meditation
  Future<void> startBackgroundMusic() async {
    if (!_backgroundMusicEnabled) {
      debugPrint('🎵 Background music disabled - skipping start');
      return;
    }

    if (!_isInitialized) {
      await initialize();
    }

    // Initialize audio systems only when needed
    await _ensureAudioInitialized();
    await _backgroundMusicService.startMusic();
    debugPrint('🎵 Background music started');
  }

  /// Stop background music
  Future<void> stopBackgroundMusic() async {
    await _backgroundMusicService.stopMusic();
    debugPrint('🎵 Background music stopped');
  }

  /// Enable/disable narration
  Future<void> setNarrationEnabled(bool enabled) async {
    _narrationEnabled = enabled;
    
    if (!enabled && _narrationService.isPlaying) {
      await _narrationService.stop();
    }
    
    await _saveSettings();
    notifyListeners();
    debugPrint('🎤 Narration enabled: $enabled');
  }

  /// Enable/disable background music
  Future<void> setBackgroundMusicEnabled(bool enabled) async {
    _backgroundMusicEnabled = enabled;
    await _backgroundMusicService.setEnabled(enabled);
    await _saveSettings();
    notifyListeners();
    debugPrint('🎵 Background music enabled: $enabled');
  }

  /// Set background music theme
  Future<void> setMusicTheme(MusicTheme theme) async {
    await _backgroundMusicService.setTheme(theme);
    debugPrint('🎵 Music theme changed: $theme');
  }

  /// Set narration speech rate
  Future<void> setNarrationSpeed(double rate) async {
    await _narrationService.setSpeechRate(rate);
    debugPrint('🎤 Narration speed: $rate');
  }

  /// Set narration volume
  Future<void> setNarrationVolume(double volume) async {
    await _narrationService.setVolume(volume);
    debugPrint('🎤 Narration volume: $volume');
  }

  /// Set background music volume
  Future<void> setBackgroundMusicVolume(double volume) async {
    await _backgroundMusicService.setVolume(volume);
    debugPrint('🎵 Background music volume: $volume');
  }

  /// Stop all audio (narration + background music)
  Future<void> stopAll() async {
    await _narrationService.stop();
    await _backgroundMusicService.stopMusic();
    debugPrint('🔇 All audio stopped');
  }

  /// Pause all audio
  Future<void> pauseAll() async {
    await _narrationService.pause();
    await _backgroundMusicService.pauseMusic();
    debugPrint('⏸️ All audio paused');
  }

  /// Resume all audio
  Future<void> resumeAll() async {
    await _narrationService.resume();
    if (_backgroundMusicEnabled) {
      await _backgroundMusicService.resumeMusic();
    }
    debugPrint('▶️ All audio resumed');
  }

  /// Get current playback status
  Map<String, dynamic> getStatus() {
    return {
      'initialized': _isInitialized,
      'narrationEnabled': _narrationEnabled,
      'backgroundMusicEnabled': _backgroundMusicEnabled,
      'narrationPlaying': _narrationService.isPlaying,
      'backgroundMusicPlaying': _backgroundMusicService.isPlaying,
      'currentNarration': _narrationService.currentId,
      'musicTheme': _backgroundMusicService.currentTheme,
      'isDucking': _backgroundMusicService.isDucking,
    };
  }

  /// Dispose of resources
  @override
  void dispose() {
    _narrationService.removeListener(_onNarrationStateChanged);
    _narrationService.dispose();
    _backgroundMusicService.dispose();
    _isInitialized = false;
    debugPrint('🔇 EnhancedAudioService disposed');
    super.dispose();
  }
}