// lib/services/progress_service.dart

import 'package:flutter/foundation.dart';
import 'package:hive/hive.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/user_progress.dart';
import '../models/user_settings.dart';

/// Service for tracking user reading progress, achievements, and analytics
class ProgressService extends ChangeNotifier {
  static const String _boxName = 'user_progress';
  static const String _tableProgress = 'user_progress';
  static const String _tableSettings = 'user_settings';
  
  Box<UserProgress>? _progressBox;
  final SupabaseClient _supabase = Supabase.instance.client;
  
  List<UserProgress> _progressEntries = [];
  UserSettings? _userSettings;
  bool _isLoading = false;
  String? _error;
  String _userDeviceId = 'default_device';

  // Getters
  List<UserProgress> get progressEntries => List.unmodifiable(_progressEntries);
  UserSettings? get userSettings => _userSettings;
  bool get isLoading => _isLoading;
  String? get error => _error;
  
  /// Initialize the progress service
  Future<void> initialize(String deviceId) async {
    try {
      _userDeviceId = deviceId;
      _progressBox = await Hive.openBox<UserProgress>(_boxName);
      await _loadProgressFromLocal();
      await _loadOrCreateUserSettings();
      await _syncWithCloud();
    } catch (e) {
      _error = 'Failed to initialize progress tracking: $e';
      if (kDebugMode) print('ProgressService initialization error: $e');
      notifyListeners();
    }
  }

  /// Load progress entries from local storage
  Future<void> _loadProgressFromLocal() async {
    if (_progressBox == null) return;
    
    _progressEntries = _progressBox!.values.toList();
    _progressEntries.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    notifyListeners();
  }

  /// Load or create user settings
  Future<void> _loadOrCreateUserSettings() async {
    try {
      // Try to load from cloud first
      final response = await _supabase
          .from(_tableSettings)
          .select()
          .eq('user_device_id', _userDeviceId)
          .maybeSingle();
      
      if (response != null) {
        _userSettings = UserSettings.fromJson(response);
      } else {
        // Create default settings
        _userSettings = UserSettings.createDefault(userDeviceId: _userDeviceId);
        await _saveUserSettings();
      }
    } catch (e) {
      // Fallback to default settings
      _userSettings = UserSettings.createDefault(userDeviceId: _userDeviceId);
      if (kDebugMode) print('Failed to load user settings: $e');
    }
    notifyListeners();
  }

  /// Save user settings to cloud
  Future<void> _saveUserSettings() async {
    if (_userSettings == null) return;
    
    try {
      // Use upsert with onConflict to handle duplicates properly
      await _supabase.from(_tableSettings).upsert(
        _userSettings!.toJson(),
        onConflict: 'user_device_id', // Specify conflict resolution column
      );
    } catch (e) {
      if (kDebugMode) print('Failed to save user settings: $e');
      // Try update if upsert fails
      try {
        await _supabase
            .from(_tableSettings)
            .update(_userSettings!.toJson())
            .eq('user_device_id', _userSettings!.userDeviceId);
      } catch (updateError) {
        if (kDebugMode) print('Failed to update user settings: $updateError');
      }
    }
  }

  /// Sync progress with cloud
  Future<void> _syncWithCloud() async {
    try {
      await _uploadPendingProgress();
      await _downloadCloudProgress();
      _error = null;
    } catch (e) {
      _error = 'Sync failed: $e';
      if (kDebugMode) print('Progress sync error: $e');
    }
    notifyListeners();
  }

  /// Upload pending progress entries
  Future<void> _uploadPendingProgress() async {
    for (final progress in _progressEntries) {
      try {
        await _supabase.from(_tableProgress).upsert(progress.toJson());
      } catch (e) {
        if (kDebugMode) print('Failed to upload progress ${progress.id}: $e');
      }
    }
  }

  /// Download progress from cloud
  Future<void> _downloadCloudProgress() async {
    try {
      final response = await _supabase
          .from(_tableProgress)
          .select()
          .eq('user_device_id', _userDeviceId)
          .order('created_at', ascending: false);
      
      final cloudEntries = response.map((json) => UserProgress.fromJson(json)).toList();
      
      // Merge with local entries (avoid duplicates)
      for (final cloudEntry in cloudEntries) {
        if (!_progressEntries.any((local) => local.id == cloudEntry.id)) {
          await _progressBox?.put(cloudEntry.id, cloudEntry);
        }
      }
      
      await _loadProgressFromLocal();
    } catch (e) {
      if (kDebugMode) print('Failed to download cloud progress: $e');
    }
  }

  /// Track verse reading
  Future<bool> trackVerseRead({
    required int chapterId,
    required int verseId,
    int sessionDurationMinutes = 1,
  }) async {
    return await _addProgress(
      chapterId: chapterId,
      verseId: verseId,
      progressType: ProgressType.verseRead,
      progressValue: 1.0,
      sessionDurationMinutes: sessionDurationMinutes,
    );
  }

  /// Track chapter started
  Future<bool> trackChapterStarted({
    required int chapterId,
    int sessionDurationMinutes = 0,
  }) async {
    return await _addProgress(
      chapterId: chapterId,
      progressType: ProgressType.chapterStarted,
      progressValue: 0.0,
      sessionDurationMinutes: sessionDurationMinutes,
    );
  }

  /// Track chapter completed
  Future<bool> trackChapterCompleted({
    required int chapterId,
    required double completionPercentage,
    int sessionDurationMinutes = 0,
  }) async {
    final success = await _addProgress(
      chapterId: chapterId,
      progressType: ProgressType.chapterCompleted,
      progressValue: completionPercentage,
      sessionDurationMinutes: sessionDurationMinutes,
    );

    if (success && _userSettings != null) {
      // Update user settings
      final updatedChapters = List<int>.from(_userSettings!.chaptersCompleted);
      if (!updatedChapters.contains(chapterId)) {
        updatedChapters.add(chapterId);
        _userSettings = _userSettings!.copyWith(chaptersCompleted: updatedChapters);
        await _saveUserSettings();
        await _checkAchievements();
      }
    }

    return success;
  }

  /// Track session time
  Future<bool> trackSessionTime({
    required int chapterId,
    required int sessionDurationMinutes,
    int? verseId,
  }) async {
    final success = await _addProgress(
      chapterId: chapterId,
      verseId: verseId,
      progressType: ProgressType.sessionTime,
      progressValue: sessionDurationMinutes.toDouble(),
      sessionDurationMinutes: sessionDurationMinutes,
    );

    if (success && _userSettings != null) {
      // Update total reading time
      _userSettings = _userSettings!.copyWith(
        totalReadingTimeMinutes: _userSettings!.totalReadingTimeMinutes + sessionDurationMinutes,
        lastReadDate: DateTime.now(),
      );
      await _saveUserSettings();
      await _updateReadingStreak();
    }

    return success;
  }

  /// Add progress entry
  Future<bool> _addProgress({
    required int chapterId,
    int? verseId,
    required ProgressType progressType,
    double? progressValue,
    int sessionDurationMinutes = 0,
    Map<String, dynamic>? metadata,
  }) async {
    try {
      _setLoading(true);

      final progress = UserProgress.create(
        userDeviceId: _userDeviceId,
        chapterId: chapterId,
        verseId: verseId,
        progressType: progressType,
        progressValue: progressValue,
        sessionDurationMinutes: sessionDurationMinutes,
        metadata: metadata ?? {},
      );

      // Save locally
      await _progressBox?.put(progress.id, progress);
      _progressEntries.add(progress);
      _progressEntries.sort((a, b) => b.createdAt.compareTo(a.createdAt));

      // Background sync
      _syncWithCloud();

      _error = null;
      _setLoading(false);
      return true;
    } catch (e) {
      _error = 'Failed to track progress: $e';
      _setLoading(false);
      return false;
    }
  }

  /// Update reading streak
  Future<void> _updateReadingStreak() async {
    if (_userSettings == null) return;

    final today = DateTime.now();
    final lastRead = _userSettings!.lastReadDate;

    if (lastRead == null) {
      // First day reading
      _userSettings = _userSettings!.copyWith(
        readingStreak: 1,
        longestStreak: 1,
      );
    } else {
      final daysSinceLastRead = today.difference(lastRead).inDays;
      
      if (daysSinceLastRead == 0) {
        // Same day - no change to streak
        return;
      } else if (daysSinceLastRead == 1) {
        // Consecutive day - increment streak
        final newStreak = _userSettings!.readingStreak + 1;
        _userSettings = _userSettings!.copyWith(
          readingStreak: newStreak,
          longestStreak: newStreak > _userSettings!.longestStreak 
              ? newStreak 
              : _userSettings!.longestStreak,
        );
        
        // Track streak milestone
        if (newStreak % 7 == 0) { // Weekly milestone
          await _addProgress(
            chapterId: 0, // Generic
            progressType: ProgressType.streakMilestone,
            progressValue: newStreak.toDouble(),
            metadata: {'milestone_type': 'weekly', 'days': newStreak},
          );
        }
      } else {
        // Streak broken
        _userSettings = _userSettings!.copyWith(readingStreak: 1);
      }
    }

    await _saveUserSettings();
    notifyListeners();
  }

  /// Check for achievements
  Future<void> _checkAchievements() async {
    if (_userSettings == null) return;

    final achievements = <String>[];
    
    // Chapter completion achievements
    final chaptersCompleted = _userSettings!.chaptersCompleted.length;
    if (chaptersCompleted == 1 && !_userSettings!.achievementsUnlocked.contains('first_chapter')) {
      achievements.add('first_chapter');
    }
    if (chaptersCompleted == 9 && !_userSettings!.achievementsUnlocked.contains('half_gita')) {
      achievements.add('half_gita');
    }
    if (chaptersCompleted == 18 && !_userSettings!.achievementsUnlocked.contains('full_gita')) {
      achievements.add('full_gita');
    }

    // Reading streak achievements
    final streak = _userSettings!.readingStreak;
    if (streak >= 7 && !_userSettings!.achievementsUnlocked.contains('week_streak')) {
      achievements.add('week_streak');
    }
    if (streak >= 30 && !_userSettings!.achievementsUnlocked.contains('month_streak')) {
      achievements.add('month_streak');
    }

    // Time-based achievements
    final totalHours = _userSettings!.totalReadingTimeMinutes / 60;
    if (totalHours >= 10 && !_userSettings!.achievementsUnlocked.contains('ten_hours')) {
      achievements.add('ten_hours');
    }

    if (achievements.isNotEmpty) {
      final updatedAchievements = List<String>.from(_userSettings!.achievementsUnlocked);
      updatedAchievements.addAll(achievements);
      
      _userSettings = _userSettings!.copyWith(achievementsUnlocked: updatedAchievements);
      await _saveUserSettings();
      notifyListeners();
    }
  }

  /// Get reading statistics
  Map<String, dynamic> getReadingStats() {
    if (_userSettings == null) return {};
    
    final today = DateTime.now();
    final todayProgress = _progressEntries.where((p) => p.isToday).toList();
    
    return {
      'totalChapters': 18,
      'chaptersCompleted': _userSettings!.chaptersCompleted.length,
      'completionPercentage': (_userSettings!.chaptersCompleted.length / 18 * 100).round(),
      'readingStreak': _userSettings!.readingStreak,
      'longestStreak': _userSettings!.longestStreak,
      'totalReadingHours': (_userSettings!.totalReadingTimeMinutes / 60).round(),
      'totalBookmarks': _userSettings!.totalBookmarks,
      'achievementsCount': _userSettings!.achievementsUnlocked.length,
      'todayMinutes': todayProgress.fold<int>(0, (sum, p) => sum + p.sessionDurationMinutes),
      'todayVerses': todayProgress.where((p) => p.progressType == ProgressType.verseRead).length,
      'dailyGoalMinutes': _userSettings!.readingGoalMinutes,
      'dailyGoalMet': todayProgress.fold<int>(0, (sum, p) => sum + p.sessionDurationMinutes) >= _userSettings!.readingGoalMinutes,
    };
  }

  /// Get progress for a specific chapter
  List<UserProgress> getChapterProgress(int chapterId) {
    return _progressEntries.where((p) => p.chapterId == chapterId).toList();
  }

  /// Get recent activity (last 30 days)
  List<UserProgress> getRecentActivity([int days = 30]) {
    final cutoff = DateTime.now().subtract(Duration(days: days));
    return _progressEntries.where((p) => p.createdAt.isAfter(cutoff)).toList();
  }

  /// Get progress by date for charts
  Map<DateTime, List<UserProgress>> getProgressByDate([int days = 30]) {
    final recent = getRecentActivity(days);
    final grouped = <DateTime, List<UserProgress>>{};
    
    for (final progress in recent) {
      final date = DateTime(
        progress.sessionDate.year,
        progress.sessionDate.month,
        progress.sessionDate.day,
      );
      grouped.putIfAbsent(date, () => []).add(progress);
    }
    
    return grouped;
  }

  /// Update reading goal
  Future<bool> updateReadingGoal(int goalMinutes) async {
    if (_userSettings == null) return false;
    
    _userSettings = _userSettings!.copyWith(readingGoalMinutes: goalMinutes);
    await _saveUserSettings();
    notifyListeners();
    return true;
  }

  /// Force sync with cloud
  Future<void> forceSync() async {
    _setLoading(true);
    await _syncWithCloud();
    _setLoading(false);
  }

  // Private helper methods
  void _setLoading(bool loading) {
    if (_isLoading != loading) {
      _isLoading = loading;
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _progressBox?.close();
    super.dispose();
  }
}