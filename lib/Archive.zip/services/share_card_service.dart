// lib/services/share_card_service.dart

import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:gal/gal.dart';
import '../models/verse.dart';
import '../models/scenario.dart';
import '../core/app_config.dart';

/// Card design themes
enum ShareCardTheme {
  minimalist,
  ornate, 
  modern,
  spiritual,
  nature
}

/// Service for creating and sharing beautiful verse cards
/// Generates custom-designed quote images for social sharing
class ShareCardService {
  static final ShareCardService _instance = ShareCardService._internal();
  factory ShareCardService() => _instance;
  ShareCardService._internal();

  static ShareCardService get instance => _instance;

  /// Generate a verse card without sharing (for preview)
  Future<Uint8List> generateVerseCard(Verse verse, ShareCardTheme theme) async {
    return _generateVerseCard(verse, theme);
  }

  /// Generate a scenario card without sharing (for preview)
  Future<Uint8List> generateScenarioCard(Scenario scenario, ShareCardTheme theme) async {
    return _generateScenarioCard(scenario, theme);
  }

  /// Generate and share a verse card
  Future<bool> shareVerseCard({
    required Verse verse,
    ShareCardTheme theme = ShareCardTheme.minimalist,
    bool saveToGallery = false,
  }) async {
    try {
      final cardImage = await _generateVerseCard(verse, theme);
      final imagePath = await _saveCardToTemp(cardImage, 'verse_card');
      
      if (saveToGallery) {
        await _saveToGallery(cardImage, 'GitaWisdom_Verse_${verse.verseId}');
      }
      
      await Share.shareXFiles(
        [XFile(imagePath)],
        text: 'Bhagavad Gita Chapter ${verse.chapterId}, Verse ${verse.verseId}\n\n${verse.description}\n\n🌿 Shared from GitaWisdom App',
        subject: 'Wisdom from Bhagavad Gita',
        sharePositionOrigin: const Rect.fromLTWH(0, 0, 200, 200), // Fix for iPad
      );
      
      return true;
    } catch (e) {
      debugPrint('❌ Error sharing verse card: $e');
      return false;
    }
  }

  /// Generate and share a scenario wisdom card  
  Future<bool> shareScenarioCard({
    required Scenario scenario,
    ShareCardTheme theme = ShareCardTheme.modern,
    bool saveToGallery = false,
  }) async {
    try {
      final cardImage = await _generateScenarioCard(scenario, theme);
      final imagePath = await _saveCardToTemp(cardImage, 'scenario_card');
      
      if (saveToGallery) {
        await _saveToGallery(cardImage, 'GitaWisdom_Scenario_${scenario.title.replaceAll(' ', '_')}');
      }
      
      await Share.shareXFiles(
        [XFile(imagePath)],
        text: '${scenario.title}\n\n${scenario.description}\n\n🌿 Wisdom for modern life from GitaWisdom',
        subject: 'Gita Wisdom for Daily Life',
        sharePositionOrigin: const Rect.fromLTWH(0, 0, 200, 200), // Fix for iPad
      );
      
      return true;
    } catch (e) {
      debugPrint('❌ Error sharing scenario card: $e');
      return false;
    }
  }

  /// Generate verse card image
  Future<Uint8List> _generateVerseCard(Verse verse, ShareCardTheme theme) async {
    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder);
    final size = const Size(1080, 1920); // Instagram story size
    
    // Draw background
    await _drawCardBackground(canvas, size, theme);
    
    // Draw verse content
    _drawVerseContent(canvas, size, verse, theme);
    
    // Draw branding
    _drawBranding(canvas, size);
    
    final picture = recorder.endRecording();
    final image = await picture.toImage(size.width.toInt(), size.height.toInt());
    final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
    
    return byteData!.buffer.asUint8List();
  }

  /// Generate scenario card image
  Future<Uint8List> _generateScenarioCard(Scenario scenario, ShareCardTheme theme) async {
    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder);
    final size = const Size(1080, 1080); // Instagram post size
    
    // Draw background
    await _drawCardBackground(canvas, size, theme);
    
    // Draw scenario content
    _drawScenarioContent(canvas, size, scenario, theme);
    
    // Draw branding
    _drawBranding(canvas, size);
    
    final picture = recorder.endRecording();
    final image = await picture.toImage(size.width.toInt(), size.height.toInt());
    final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
    
    return byteData!.buffer.asUint8List();
  }

  /// Draw themed background
  Future<void> _drawCardBackground(Canvas canvas, Size size, ShareCardTheme theme) async {
    final paint = Paint();
    
    switch (theme) {
      case ShareCardTheme.minimalist:
        paint.shader = ui.Gradient.linear(
          Offset.zero,
          Offset(size.width, size.height),
          [
            const Color(0xFFFAFAFA),
            const Color(0xFFF5F5F5),
          ],
        );
        break;
        
      case ShareCardTheme.spiritual:
        paint.shader = ui.Gradient.radial(
          Offset(size.width / 2, size.height / 3),
          size.width * 0.8,
          [
            const Color(0xFFFFE0B2), // Warm saffron
            const Color(0xFFFF8A65), // Deep orange
            const Color(0xFFBF360C), // Dark orange
          ],
        );
        break;
        
      case ShareCardTheme.nature:
        paint.shader = ui.Gradient.linear(
          const Offset(0, 0),
          Offset(size.width, size.height),
          [
            const Color(0xFF66BB6A), // Light green
            const Color(0xFF4CAF50), // Green
            const Color(0xFF2E7D32), // Dark green
          ],
        );
        break;
        
      case ShareCardTheme.ornate:
        paint.shader = ui.Gradient.linear(
          const Offset(0, 0),
          Offset(size.width, size.height),
          [
            const Color(0xFF9C27B0), // Purple
            const Color(0xFF673AB7), // Deep purple
            const Color(0xFF3F51B5), // Indigo
          ],
        );
        break;
        
      case ShareCardTheme.modern:
      default:
        paint.shader = ui.Gradient.linear(
          const Offset(0, 0),
          Offset(size.width, size.height),
          [
            const Color(0xFF37474F), // Blue grey
            const Color(0xFF263238), // Dark blue grey
          ],
        );
        break;
    }
    
    canvas.drawRect(Offset.zero & size, paint);
  }

  /// Draw verse content on card
  void _drawVerseContent(Canvas canvas, Size size, Verse verse, ShareCardTheme theme) {
    final textColor = _getTextColor(theme);
    final accentColor = _getAccentColor(theme);
    
    // Draw chapter and verse reference
    final referencePainter = TextPainter(
      text: TextSpan(
        text: 'Bhagavad Gita ${verse.chapterId}.${verse.verseId}',
        style: TextStyle(
          fontSize: 24,
          fontWeight: FontWeight.w300,
          color: accentColor,
          letterSpacing: 2.0,
        ),
      ),
      textDirection: TextDirection.ltr,
    );
    referencePainter.layout(maxWidth: size.width - 120);
    referencePainter.paint(canvas, Offset(60, size.height * 0.15));
    
    // Draw verse text
    final versePainter = TextPainter(
      text: TextSpan(
        text: verse.description,
        style: TextStyle(
          fontSize: 32,
          fontWeight: FontWeight.w400,
          color: textColor,
          height: 1.4,
        ),
      ),
      textDirection: TextDirection.ltr,
      textAlign: TextAlign.center,
    );
    versePainter.layout(maxWidth: size.width - 120);
    
    final verseY = (size.height - versePainter.height) / 2;
    versePainter.paint(canvas, Offset(60, verseY));
    
    // Draw decorative spa symbol
    final spaPainter = TextPainter(
      text: const TextSpan(
        text: '🌿',
        style: TextStyle(
          fontSize: 60,
        ),
      ),
      textDirection: TextDirection.ltr,
    );
    spaPainter.layout();
    spaPainter.paint(
      canvas, 
      Offset(
        (size.width - spaPainter.width) / 2,
        size.height * 0.85,
      ),
    );
  }

  /// Draw scenario content on card
  void _drawScenarioContent(Canvas canvas, Size size, Scenario scenario, ShareCardTheme theme) {
    final textColor = _getTextColor(theme);
    final accentColor = _getAccentColor(theme);
    
    // Draw title
    final titlePainter = TextPainter(
      text: TextSpan(
        text: scenario.title,
        style: TextStyle(
          fontSize: 36,
          fontWeight: FontWeight.bold,
          color: textColor,
          height: 1.2,
        ),
      ),
      textDirection: TextDirection.ltr,
      textAlign: TextAlign.center,
    );
    titlePainter.layout(maxWidth: size.width - 120);
    titlePainter.paint(canvas, Offset(60, size.height * 0.2));
    
    // Draw description
    final descPainter = TextPainter(
      text: TextSpan(
        text: scenario.description,
        style: TextStyle(
          fontSize: 28,
          fontWeight: FontWeight.w400,
          color: textColor,
          height: 1.4,
        ),
      ),
      textDirection: TextDirection.ltr,
      textAlign: TextAlign.center,
    );
    descPainter.layout(maxWidth: size.width - 120);
    
    final descY = titlePainter.height + size.height * 0.25;
    descPainter.paint(canvas, Offset(60, descY));
    
    // Draw category badge
    final categoryPainter = TextPainter(
      text: TextSpan(
        text: '🧭 DAILY WISDOM',
        style: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.w600,
          color: accentColor,
          letterSpacing: 1.5,
        ),
      ),
      textDirection: TextDirection.ltr,
    );
    categoryPainter.layout();
    categoryPainter.paint(
      canvas,
      Offset(
        (size.width - categoryPainter.width) / 2,
        size.height * 0.85,
      ),
    );
  }

  /// Draw app branding
  void _drawBranding(Canvas canvas, Size size) {
    final brandPainter = TextPainter(
      text: const TextSpan(
        text: 'GitaWisdom',
        style: TextStyle(
          fontSize: 24,
          fontWeight: FontWeight.w600,
          color: Colors.white70,
          letterSpacing: 1.0,
        ),
      ),
      textDirection: TextDirection.ltr,
    );
    brandPainter.layout();
    brandPainter.paint(
      canvas,
      Offset(
        size.width - brandPainter.width - 40,
        size.height - brandPainter.height - 40,
      ),
    );
  }

  /// Get text color for theme
  Color _getTextColor(ShareCardTheme theme) {
    switch (theme) {
      case ShareCardTheme.minimalist:
        return const Color(0xFF263238);
      case ShareCardTheme.nature:
      case ShareCardTheme.spiritual:
      case ShareCardTheme.ornate:
      case ShareCardTheme.modern:
      default:
        return Colors.white;
    }
  }

  /// Get accent color for theme
  Color _getAccentColor(ShareCardTheme theme) {
    switch (theme) {
      case ShareCardTheme.minimalist:
        return const Color(0xFFFF8A65);
      case ShareCardTheme.spiritual:
        return const Color(0xFFFFE0B2);
      case ShareCardTheme.nature:
        return const Color(0xFF81C784);
      case ShareCardTheme.ornate:
        return const Color(0xFFBA68C8);
      case ShareCardTheme.modern:
      default:
        return const Color(0xFF64B5F6);
    }
  }

  /// Save card to temporary directory
  Future<String> _saveCardToTemp(Uint8List imageBytes, String prefix) async {
    final directory = await getTemporaryDirectory();
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final filePath = '${directory.path}/${prefix}_$timestamp.png';
    
    final file = File(filePath);
    await file.writeAsBytes(imageBytes);
    
    return filePath;
  }

  /// Save image to gallery
  Future<void> _saveToGallery(Uint8List imageBytes, String name) async {
    try {
      // Save to temp file first
      final directory = await getTemporaryDirectory();
      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final filePath = '${directory.path}/gallery_$name$timestamp.png';
      
      final file = File(filePath);
      await file.writeAsBytes(imageBytes);
      
      // Save to gallery using gal package
      await Gal.putImage(filePath, album: 'GitaWisdom');
      
      debugPrint('✅ Image saved to gallery: $name');
    } catch (e) {
      debugPrint('❌ Failed to save to gallery: $e');
    }
  }

  /// Get available themes
  static List<ShareCardTheme> get availableThemes => ShareCardTheme.values;
}