// lib/services/practice_notification_service.dart

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import '../services/notification_service.dart';
import '../services/practice_service.dart';
import '../models/daily_practice.dart';

/// Service for managing practice-related notifications and reminders
class PracticeNotificationService extends ChangeNotifier {
  static final PracticeNotificationService _instance = PracticeNotificationService._internal();
  static PracticeNotificationService get instance => _instance;
  
  PracticeNotificationService._internal();
  
  Box? _settingsBox;
  Timer? _dailyCheckTimer;
  bool _isInitialized = false;
  
  // Notification settings
  bool _dailyRemindersEnabled = true;
  bool _streakRemindersEnabled = true;
  bool _challengeRemindersEnabled = true;
  List<String> _reminderTimes = ['09:00', '20:00']; // Morning and evening
  
  // Getters
  bool get isInitialized => _isInitialized;
  bool get dailyRemindersEnabled => _dailyRemindersEnabled;
  bool get streakRemindersEnabled => _streakRemindersEnabled;
  bool get challengeRemindersEnabled => _challengeRemindersEnabled;
  List<String> get reminderTimes => List.from(_reminderTimes);
  
  /// Initialize the notification service
  Future<void> initialize() async {
    if (_isInitialized) return;
    
    try {
      _settingsBox = await Hive.openBox('practice_notifications');
      await _loadSettings();
      await _scheduleDailyCheck();
      
      _isInitialized = true;
      debugPrint('✅ PracticeNotificationService initialized');
    } catch (e) {
      debugPrint('❌ PracticeNotificationService initialization failed: $e');
    }
  }
  
  /// Load notification settings
  Future<void> _loadSettings() async {
    if (_settingsBox == null) return;
    
    _dailyRemindersEnabled = _settingsBox!.get('daily_reminders', defaultValue: true);
    _streakRemindersEnabled = _settingsBox!.get('streak_reminders', defaultValue: true);
    _challengeRemindersEnabled = _settingsBox!.get('challenge_reminders', defaultValue: true);
    _reminderTimes = List<String>.from(_settingsBox!.get('reminder_times', defaultValue: ['09:00', '20:00']));
  }
  
  /// Schedule daily check for practice reminders
  Future<void> _scheduleDailyCheck() async {
    _dailyCheckTimer?.cancel();
    
    // Check every hour for pending notifications
    _dailyCheckTimer = Timer.periodic(const Duration(hours: 1), (timer) async {
      if (_dailyRemindersEnabled) {
        await _checkDailyPracticeReminders();
      }
      if (_streakRemindersEnabled) {
        await _checkStreakReminders();
      }
      if (_challengeRemindersEnabled) {
        await _checkChallengeReminders();
      }
    });
    
    // Also check immediately
    await Future.delayed(const Duration(minutes: 1)); // Small delay for initialization
    if (_dailyRemindersEnabled) await _checkDailyPracticeReminders();
    if (_streakRemindersEnabled) await _checkStreakReminders();
    if (_challengeRemindersEnabled) await _checkChallengeReminders();
  }
  
  /// Check if it's time for daily practice reminders
  Future<void> _checkDailyPracticeReminders() async {
    final now = DateTime.now();
    final currentTime = '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';
    
    for (final reminderTime in _reminderTimes) {
      if (_isTimeMatch(currentTime, reminderTime)) {
        await _sendDailyPracticeReminder();
        break;
      }
    }
  }
  
  /// Check for streak-related reminders
  Future<void> _checkStreakReminders() async {
    if (!PracticeService.instance.isInitialized) return;
    
    final streaks = PracticeService.instance.streaks;
    final now = DateTime.now();
    
    // Check for broken streaks that need attention
    for (final streak in streaks.values) {
      if (streak.lastPracticeDate != null) {
        final daysSince = now.difference(streak.lastPracticeDate!).inDays;
        
        // Remind if streak will break (last practice was yesterday)
        if (daysSince == 1 && streak.currentStreak > 2) {
          await _sendStreakReminder(streak);
        }
        
        // Celebrate milestone streaks
        if (streak.currentStreak > 0 && _isStreakMilestone(streak.currentStreak)) {
          await _sendStreakCelebration(streak);
        }
      }
    }
  }
  
  /// Check for challenge completion reminders
  Future<void> _checkChallengeReminders() async {
    if (!PracticeService.instance.isInitialized) return;
    
    final challenges = PracticeService.instance.todaysChallenges;
    final incompleteCount = challenges.where((c) => !c.isCompleted).length;
    
    // Evening reminder for incomplete challenges
    final now = DateTime.now();
    if (now.hour >= 19 && incompleteCount > 0) {
      await _sendChallengeReminder(incompleteCount);
    }
  }
  
  /// Send daily practice reminder notification
  Future<void> _sendDailyPracticeReminder() async {
    final now = DateTime.now();
    final hour = now.hour;
    
    String title;
    String message;
    
    if (hour < 12) {
      title = '🌅 Start Your Spiritual Day';
      message = 'Begin with meditation, reading, or reflection to set a peaceful tone.';
    } else {
      title = '🌙 Evening Practice Time';
      message = 'End your day with gratitude, reflection, or calming meditation.';
    }
    
    await NotificationService().showAchievementNotification(
      title: title,
      description: message,
      payload: 'practice_screen',
    );
    
    debugPrint('📱 Sent daily practice reminder: $title');
  }
  
  /// Send streak reminder notification
  Future<void> _sendStreakReminder(PracticeStreak streak) async {
    final practiceTypeName = _getPracticeTypeName(streak.practiceType);
    
    await NotificationService().showAchievementNotification(
      title: '🔥 Don\'t Break Your Streak!',
      description: 'Your ${streak.currentStreak}-day $practiceTypeName streak needs attention today.',
      payload: 'practice_screen',
    );
    
    debugPrint('📱 Sent streak reminder for ${streak.practiceTypeString}');
  }
  
  /// Send streak celebration notification
  Future<void> _sendStreakCelebration(PracticeStreak streak) async {
    final practiceTypeName = _getPracticeTypeName(streak.practiceType);
    final milestone = streak.currentStreak;
    
    String title;
    String message;
    
    if (milestone == 7) {
      title = '🎉 One Week Streak!';
      message = 'Amazing! You\'ve practiced $practiceTypeName for 7 days straight.';
    } else if (milestone == 30) {
      title = '🏆 One Month Achievement!';
      message = 'Incredible dedication! 30 days of $practiceTypeName practice.';
    } else if (milestone == 100) {
      title = '💎 Master Level Achieved!';
      message = '100 days of $practiceTypeName practice! You\'re truly dedicated.';
    } else if (milestone % 10 == 0) {
      title = '⭐ $milestone Day Milestone!';
      message = 'Congratulations on $milestone consecutive days of $practiceTypeName.';
    } else {
      return; // Only celebrate specific milestones
    }
    
    await NotificationService().showAchievementNotification(
      title: title,
      description: message,
      payload: 'practice_screen',
    );
    
    debugPrint('📱 Sent streak celebration for ${streak.practiceTypeString}: $milestone days');
  }
  
  /// Send challenge reminder notification
  Future<void> _sendChallengeReminder(int incompleteCount) async {
    await NotificationService().showAchievementNotification(
      title: '⏰ Challenges Waiting',
      description: 'You have $incompleteCount spiritual challenges left to complete today.',
      payload: 'practice_screen',
    );
    
    debugPrint('📱 Sent challenge reminder: $incompleteCount incomplete');
  }
  
  /// Check if current time matches reminder time (within 1 minute)
  bool _isTimeMatch(String currentTime, String targetTime) {
    final currentParts = currentTime.split(':');
    final targetParts = targetTime.split(':');
    
    if (currentParts.length != 2 || targetParts.length != 2) return false;
    
    final currentHour = int.tryParse(currentParts[0]) ?? -1;
    final currentMinute = int.tryParse(currentParts[1]) ?? -1;
    final targetHour = int.tryParse(targetParts[0]) ?? -1;
    final targetMinute = int.tryParse(targetParts[1]) ?? -1;
    
    return currentHour == targetHour && (currentMinute - targetMinute).abs() <= 1;
  }
  
  /// Check if streak count is a milestone worth celebrating
  bool _isStreakMilestone(int streak) {
    return streak == 7 || streak == 30 || streak == 100 || (streak % 10 == 0 && streak > 0);
  }
  
  /// Get human-readable practice type name
  String _getPracticeTypeName(PracticeType type) {
    switch (type) {
      case PracticeType.reading:
        return 'reading';
      case PracticeType.meditation:
        return 'meditation';
      case PracticeType.reflection:
        return 'reflection';
      case PracticeType.gratitude:
        return 'gratitude';
      case PracticeType.service:
        return 'service';
      case PracticeType.chanting:
        return 'chanting';
      case PracticeType.mindfulness:
        return 'mindfulness';
    }
  }
  
  /// Update notification settings
  Future<void> updateSettings({
    bool? dailyReminders,
    bool? streakReminders,
    bool? challengeReminders,
    List<String>? reminderTimes,
  }) async {
    if (_settingsBox == null) return;
    
    if (dailyReminders != null) {
      _dailyRemindersEnabled = dailyReminders;
      await _settingsBox!.put('daily_reminders', dailyReminders);
    }
    
    if (streakReminders != null) {
      _streakRemindersEnabled = streakReminders;
      await _settingsBox!.put('streak_reminders', streakReminders);
    }
    
    if (challengeReminders != null) {
      _challengeRemindersEnabled = challengeReminders;
      await _settingsBox!.put('challenge_reminders', challengeReminders);
    }
    
    if (reminderTimes != null) {
      _reminderTimes = List.from(reminderTimes);
      await _settingsBox!.put('reminder_times', reminderTimes);
    }
    
    notifyListeners();
    debugPrint('💾 Updated practice notification settings');
  }
  
  /// Manually trigger a practice reminder for testing
  Future<void> sendTestReminder() async {
    await NotificationService().showAchievementNotification(
      title: '🧘‍♀️ Practice Reminder Test',
      description: 'This is a test notification for your spiritual practice.',
      payload: 'practice_screen',
    );
  }
  
  /// Cancel all practice-related notifications
  Future<void> cancelAllNotifications() async {
    await NotificationService().cancelAllNotifications();
    debugPrint('🗑️ Cancelled all practice notifications');
  }
  
  @override
  void dispose() {
    _dailyCheckTimer?.cancel();
    _settingsBox?.close();
    super.dispose();
  }
}