// lib/services/auth_service.dart

import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:crypto/crypto.dart';
import 'package:uuid/uuid.dart';
import 'dart:convert';
import 'dart:io';

/// Authentication service supporting both anonymous and authenticated users
class AuthService extends ChangeNotifier {
  final SupabaseClient _supabase = Supabase.instance.client;
  
  User? _currentUser;
  String? _deviceId;
  bool _isLoading = false;
  String? _error;
  bool _isAnonymous = true;

  // Getters
  User? get currentUser => _currentUser;
  String? get deviceId => _deviceId;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isAuthenticated => _currentUser != null;
  bool get isAnonymous => _isAnonymous;
  String get userId => _currentUser?.id ?? _deviceId ?? 'anonymous';

  /// Initialize authentication service
  Future<void> initialize() async {
    try {
      _setLoading(true);
      
      // Generate device ID for anonymous users
      await _generateDeviceId();
      
      // Check if user is already signed in
      _currentUser = _supabase.auth.currentUser;
      _isAnonymous = _currentUser == null;
      
      // Listen to auth state changes
      _supabase.auth.onAuthStateChange.listen((data) {
        final AuthChangeEvent event = data.event;
        final Session? session = data.session;
        
        _currentUser = session?.user;
        _isAnonymous = _currentUser == null;
        
        if (kDebugMode) {
          print('Auth state changed: $event, User: ${_currentUser?.email}');
        }
        
        notifyListeners();
      });
      
      _error = null;
      _setLoading(false);
    } catch (e) {
      _error = 'Failed to initialize authentication: $e';
      _setLoading(false);
      if (kDebugMode) print('Auth initialization error: $e');
    }
  }

  /// Generate unique device ID for anonymous users
  Future<void> _generateDeviceId() async {
    try {
      final deviceInfo = DeviceInfoPlugin();
      String identifier = '';
      
      if (Platform.isAndroid) {
        final androidInfo = await deviceInfo.androidInfo;
        identifier = '${androidInfo.brand}_${androidInfo.model}_${androidInfo.id}';
      } else if (Platform.isIOS) {
        final iosInfo = await deviceInfo.iosInfo;
        identifier = '${iosInfo.name}_${iosInfo.model}_${iosInfo.identifierForVendor}';
      }
      
      // Create a hash of the device identifier for privacy
      final bytes = utf8.encode(identifier);
      final digest = sha256.convert(bytes);
      _deviceId = 'device_${digest.toString().substring(0, 16)}';
      
    } catch (e) {
      // Fallback device ID using proper UUID
      const uuid = Uuid();
      _deviceId = 'device_${uuid.v4().substring(0, 16)}';
      if (kDebugMode) print('Device ID generation error: $e');
    }
  }

  /// Sign in with email and password
  Future<bool> signInWithEmail(String email, String password) async {
    try {
      _setLoading(true);
      _error = null;
      
      final response = await _supabase.auth.signInWithPassword(
        email: email,
        password: password,
      );
      
      _currentUser = response.user;
      _isAnonymous = false;
      _setLoading(false);
      
      if (_currentUser != null) {
        // Migrate anonymous data if needed
        await _migrateAnonymousData();
        return true;
      }
      
      return false;
    } catch (e) {
      _error = _getAuthErrorMessage(e);
      _setLoading(false);
      if (kDebugMode) print('Sign in error: $e');
      return false;
    }
  }

  /// Sign up with email and password
  Future<bool> signUpWithEmail(String email, String password, {String? fullName}) async {
    try {
      _setLoading(true);
      _error = null;
      
      final response = await _supabase.auth.signUp(
        email: email,
        password: password,
        data: fullName != null ? {'full_name': fullName} : null,
      );
      
      _currentUser = response.user;
      _isAnonymous = false;
      _setLoading(false);
      
      if (_currentUser != null) {
        // Migrate anonymous data
        await _migrateAnonymousData();
        return true;
      }
      
      return false;
    } catch (e) {
      _error = _getAuthErrorMessage(e);
      _setLoading(false);
      if (kDebugMode) print('Sign up error: $e');
      return false;
    }
  }

  /// Sign in with Google (for future implementation)
  Future<bool> signInWithGoogle() async {
    // TODO: Implement Google Sign In
    _error = 'Google Sign In coming soon';
    return false;
  }

  /// Sign in with Apple (for iOS)
  Future<bool> signInWithApple() async {
    // TODO: Implement Apple Sign In
    _error = 'Apple Sign In coming soon';
    return false;
  }

  /// Continue as anonymous user
  Future<bool> continueAsAnonymous() async {
    try {
      _isAnonymous = true;
      _currentUser = null;
      notifyListeners();
      return true;
    } catch (e) {
      _error = 'Failed to continue as anonymous: $e';
      return false;
    }
  }

  /// Send password reset email
  Future<bool> resetPassword(String email) async {
    try {
      _setLoading(true);
      _error = null;
      
      await _supabase.auth.resetPasswordForEmail(email);
      _setLoading(false);
      return true;
    } catch (e) {
      _error = _getAuthErrorMessage(e);
      _setLoading(false);
      if (kDebugMode) print('Password reset error: $e');
      return false;
    }
  }

  /// Sign out user
  Future<void> signOut() async {
    try {
      await _supabase.auth.signOut();
      _currentUser = null;
      _isAnonymous = true;
      _error = null;
      notifyListeners();
    } catch (e) {
      _error = 'Failed to sign out: $e';
      if (kDebugMode) print('Sign out error: $e');
    }
  }

  /// Update user profile
  Future<bool> updateProfile({String? fullName, String? email}) async {
    try {
      _setLoading(true);
      _error = null;
      
      final updates = <String, dynamic>{};
      if (fullName != null) updates['full_name'] = fullName;
      if (email != null) updates['email'] = email;
      
      final response = await _supabase.auth.updateUser(
        UserAttributes(
          email: email,
          data: fullName != null ? {'full_name': fullName} : null,
        ),
      );
      
      _currentUser = response.user;
      _setLoading(false);
      return true;
    } catch (e) {
      _error = _getAuthErrorMessage(e);
      _setLoading(false);
      if (kDebugMode) print('Profile update error: $e');
      return false;
    }
  }

  /// Get user's display name
  String get displayName {
    if (_currentUser != null) {
      return _currentUser!.userMetadata?['full_name'] as String? ?? 
             _currentUser!.email?.split('@').first ?? 
             'User';
    }
    return 'Anonymous User';
  }

  /// Get user's email
  String? get userEmail => _currentUser?.email;

  /// Migrate anonymous data to authenticated user
  Future<void> _migrateAnonymousData() async {
    if (_currentUser == null || _deviceId == null) return;
    
    try {
      // Update all user data from device_id to user_id
      final tables = ['user_bookmarks', 'user_progress', 'user_settings'];
      
      for (final table in tables) {
        await _supabase.from(table)
            .update({'user_device_id': _currentUser!.id})
            .eq('user_device_id', _deviceId!);
      }
      
      if (kDebugMode) {
        print('Successfully migrated anonymous data for device: $_deviceId to user: ${_currentUser!.id}');
      }
    } catch (e) {
      if (kDebugMode) print('Data migration error: $e');
    }
  }

  /// Convert auth errors to user-friendly messages
  String _getAuthErrorMessage(dynamic error) {
    final errorMessage = error.toString().toLowerCase();
    
    if (errorMessage.contains('invalid_credentials')) {
      return 'Invalid email or password';
    } else if (errorMessage.contains('user_not_found')) {
      return 'No account found with this email';
    } else if (errorMessage.contains('weak_password')) {
      return 'Password should be at least 6 characters';
    } else if (errorMessage.contains('email_already_in_use')) {
      return 'An account with this email already exists';
    } else if (errorMessage.contains('invalid_email')) {
      return 'Please enter a valid email address';
    } else if (errorMessage.contains('network')) {
      return 'Network error. Please check your connection';
    } else {
      return 'An error occurred. Please try again';
    }
  }

  /// Clear error message
  void clearError() {
    _error = null;
    notifyListeners();
  }

  // Private helper methods
  void _setLoading(bool loading) {
    if (_isLoading != loading) {
      _isLoading = loading;
      notifyListeners();
    }
  }
}