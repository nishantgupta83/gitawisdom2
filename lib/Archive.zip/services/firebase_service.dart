// lib/services/firebase_service.dart
import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/chapter.dart';
import '../models/scenario.dart';
import '../models/verse.dart';
import '../models/journal_entry.dart';
import '../models/daily_practice.dart';

class FirebaseService {
  static final FirebaseFirestore _db = FirebaseFirestore.instance;
  static final FirebaseAuth _auth = FirebaseAuth.instance;
  
  // ==========================================
  // CHAPTERS
  // ==========================================
  
  static Future<List<Chapter>> getChapters() async {
    try {
      final snapshot = await _db.collection('chapters')
          .orderBy('ch_chapter_id')
          .get();
      
      return snapshot.docs
          .map((doc) => Chapter.fromFirestore(doc.data(), doc.id))
          .toList();
    } catch (e) {
      throw Exception('Failed to fetch chapters: $e');
    }
  }
  
  static Future<Chapter?> getChapter(int chapterId) async {
    try {
      final snapshot = await _db.collection('chapters')
          .where('ch_chapter_id', isEqualTo: chapterId)
          .limit(1)
          .get();
      
      if (snapshot.docs.isEmpty) return null;
      
      final doc = snapshot.docs.first;
      return Chapter.fromFirestore(doc.data(), doc.id);
    } catch (e) {
      throw Exception('Failed to fetch chapter $chapterId: $e');
    }
  }
  
  // ==========================================
  // SCENARIOS
  // ==========================================
  
  static Future<List<Scenario>> getAllScenarios({int? limit}) async {
    try {
      Query query = _db.collection('scenarios')
          .orderBy('created_at', descending: true);
      
      if (limit != null) {
        query = query.limit(limit);
      }
      
      final snapshot = await query.get();
      
      return snapshot.docs
          .map((doc) => Scenario.fromFirestore(doc.data() as Map<String, dynamic>, doc.id))
          .toList();
    } catch (e) {
      throw Exception('Failed to fetch scenarios: $e');
    }
  }
  
  static Future<List<Scenario>> getScenariosByChapter(int chapter, {int? limit}) async {
    try {
      Query query = _db.collection('scenarios')
          .where('sc_chapter', isEqualTo: chapter)
          .orderBy('created_at', descending: true);
      
      if (limit != null) {
        query = query.limit(limit);
      }
      
      final snapshot = await query.get();
      
      return snapshot.docs
          .map((doc) => Scenario.fromFirestore(doc.data() as Map<String, dynamic>, doc.id))
          .toList();
    } catch (e) {
      throw Exception('Failed to fetch scenarios for chapter $chapter: $e');
    }
  }
  
  static Future<List<Scenario>> getScenariosByCategory(String category, {int? limit}) async {
    try {
      Query query = _db.collection('scenarios')
          .where('sc_category', isEqualTo: category)
          .orderBy('quality_score', descending: true);
      
      if (limit != null) {
        query = query.limit(limit);
      }
      
      final snapshot = await query.get();
      
      return snapshot.docs
          .map((doc) => Scenario.fromFirestore(doc.data() as Map<String, dynamic>, doc.id))
          .toList();
    } catch (e) {
      throw Exception('Failed to fetch scenarios for category $category: $e');
    }
  }
  
  static Future<Scenario?> getScenario(String scenarioId) async {
    try {
      final doc = await _db.collection('scenarios').doc(scenarioId).get();
      
      if (!doc.exists) return null;
      
      return Scenario.fromFirestore(doc.data()!, doc.id);
    } catch (e) {
      throw Exception('Failed to fetch scenario $scenarioId: $e');
    }
  }
  
  static Future<List<Scenario>> searchScenarios(String searchQuery, {int? limit}) async {
    try {
      // Simple text search - can be enhanced with Algolia or similar
      final snapshot = await _db.collection('scenarios')
          .where('sc_title', isGreaterThanOrEqualTo: searchQuery.toLowerCase())
          .where('sc_title', isLessThan: searchQuery.toLowerCase() + 'z')
          .limit(limit ?? 20)
          .get();
      
      return snapshot.docs
          .map((doc) => Scenario.fromFirestore(doc.data(), doc.id))
          .toList();
    } catch (e) {
      // Fallback: get scenarios and filter in memory (less efficient but works)
      final allScenarios = await getAllScenarios(limit: limit ?? 100);
      return allScenarios.where((scenario) =>
          scenario.scTitle.toLowerCase().contains(searchQuery.toLowerCase()) ||
          scenario.scDescription.toLowerCase().contains(searchQuery.toLowerCase())
      ).take(limit ?? 20).toList();
    }
  }
  
  // ==========================================
  // VERSES
  // ==========================================
  
  static Future<List<Verse>> getVersesByChapter(int chapterId) async {
    try {
      final snapshot = await _db.collection('gita_verses')
          .where('gv_chapter_id', isEqualTo: chapterId)
          .orderBy('gv_verse_number')
          .get();
      
      return snapshot.docs
          .map((doc) => Verse.fromFirestore(doc.data(), doc.id))
          .toList();
    } catch (e) {
      throw Exception('Failed to fetch verses for chapter $chapterId: $e');
    }
  }
  
  static Future<List<Verse>> getRandomVerses({int count = 3}) async {
    try {
      // Get a sample of verses for daily verses
      final snapshot = await _db.collection('gita_verses')
          .limit(count * 10) // Get more than needed to randomize
          .get();
      
      if (snapshot.docs.isEmpty) return [];
      
      final verses = snapshot.docs
          .map((doc) => Verse.fromFirestore(doc.data(), doc.id))
          .toList();
      
      // Shuffle and return requested count
      verses.shuffle(Random());
      return verses.take(count).toList();
    } catch (e) {
      throw Exception('Failed to fetch random verses: $e');
    }
  }
  
  static Future<Verse?> getVerse(String verseId) async {
    try {
      final doc = await _db.collection('gita_verses').doc(verseId).get();
      
      if (!doc.exists) return null;
      
      return Verse.fromFirestore(doc.data()!, doc.id);
    } catch (e) {
      throw Exception('Failed to fetch verse $verseId: $e');
    }
  }
  
  // ==========================================
  // DAILY QUOTES
  // ==========================================
  
  static Future<String?> getTodaysQuote() async {
    try {
      final today = DateTime.now();
      final dateString = '${today.year}-${today.month.toString().padLeft(2, '0')}-${today.day.toString().padLeft(2, '0')}';
      
      // Try to get today's specific quote
      final snapshot = await _db.collection('daily_quotes')
          .where('date', isEqualTo: dateString)
          .limit(1)
          .get();
      
      if (snapshot.docs.isNotEmpty) {
        return snapshot.docs.first.data()['quote'] as String?;
      }
      
      // Fallback: get a random quote
      final randomSnapshot = await _db.collection('daily_quotes')
          .limit(50)
          .get();
      
      if (randomSnapshot.docs.isNotEmpty) {
        final randomIndex = Random().nextInt(randomSnapshot.docs.length);
        return randomSnapshot.docs[randomIndex].data()['quote'] as String?;
      }
      
      return null;
    } catch (e) {
      throw Exception('Failed to fetch daily quote: $e');
    }
  }
  
  // ==========================================
  // USER AUTHENTICATION
  // ==========================================
  
  static User? get currentUser => _auth.currentUser;
  
  static Future<void> signInAnonymously() async {
    try {
      await _auth.signInAnonymously();
    } catch (e) {
      throw Exception('Failed to sign in: $e');
    }
  }
  
  static Future<void> signOut() async {
    try {
      await _auth.signOut();
    } catch (e) {
      throw Exception('Failed to sign out: $e');
    }
  }
  
  // ==========================================
  // JOURNAL ENTRIES
  // ==========================================
  
  static Future<void> addJournalEntry(JournalEntry entry) async {
    final user = _auth.currentUser;
    if (user == null) {
      // Sign in anonymously if not authenticated
      await signInAnonymously();
      final newUser = _auth.currentUser;
      if (newUser == null) throw Exception('Failed to authenticate user');
    }
    
    try {
      await _db.collection('users')
          .doc(_auth.currentUser!.uid)
          .collection('journal_entries')
          .doc(entry.id)
          .set(entry.toFirestore());
    } catch (e) {
      throw Exception('Failed to add journal entry: $e');
    }
  }
  
  static Future<List<JournalEntry>> getUserJournalEntries() async {
    final user = _auth.currentUser;
    if (user == null) return []; // Return empty list if not authenticated
    
    try {
      final snapshot = await _db.collection('users')
          .doc(user.uid)
          .collection('journal_entries')
          .orderBy('created_at', descending: true)
          .get();
      
      return snapshot.docs
          .map((doc) => JournalEntry.fromFirestore(doc.data(), doc.id))
          .toList();
    } catch (e) {
      throw Exception('Failed to fetch journal entries: $e');
    }
  }
  
  static Future<void> updateJournalEntry(JournalEntry entry) async {
    final user = _auth.currentUser;
    if (user == null) throw Exception('User not authenticated');
    
    try {
      await _db.collection('users')
          .doc(user.uid)
          .collection('journal_entries')
          .doc(entry.id)
          .update(entry.toFirestore());
    } catch (e) {
      throw Exception('Failed to update journal entry: $e');
    }
  }
  
  static Future<void> deleteJournalEntry(String entryId) async {
    final user = _auth.currentUser;
    if (user == null) throw Exception('User not authenticated');
    
    try {
      await _db.collection('users')
          .doc(user.uid)
          .collection('journal_entries')
          .doc(entryId)
          .delete();
    } catch (e) {
      throw Exception('Failed to delete journal entry: $e');
    }
  }
  
  // ==========================================
  // USER FAVORITES
  // ==========================================
  
  static Future<void> addFavorite(String itemId, String itemType) async {
    final user = _auth.currentUser;
    if (user == null) {
      await signInAnonymously();
    }
    
    try {
      await _db.collection('users')
          .doc(_auth.currentUser!.uid)
          .collection('favorites')
          .doc('${itemType}_$itemId')
          .set({
            'item_id': itemId,
            'item_type': itemType, // 'scenario', 'verse', 'chapter'
            'added_at': FieldValue.serverTimestamp(),
          });
    } catch (e) {
      throw Exception('Failed to add favorite: $e');
    }
  }
  
  static Future<void> removeFavorite(String itemId, String itemType) async {
    final user = _auth.currentUser;
    if (user == null) return;
    
    try {
      await _db.collection('users')
          .doc(user.uid)
          .collection('favorites')
          .doc('${itemType}_$itemId')
          .delete();
    } catch (e) {
      throw Exception('Failed to remove favorite: $e');
    }
  }
  
  static Future<List<String>> getUserFavorites(String itemType) async {
    final user = _auth.currentUser;
    if (user == null) return [];
    
    try {
      final snapshot = await _db.collection('users')
          .doc(user.uid)
          .collection('favorites')
          .where('item_type', isEqualTo: itemType)
          .get();
      
      return snapshot.docs
          .map((doc) => doc.data()['item_id'] as String)
          .toList();
    } catch (e) {
      throw Exception('Failed to fetch favorites: $e');
    }
  }
  
  // ==========================================
  // DAILY PRACTICE
  // ==========================================
  
  static Future<void> saveDailyPractice(DailyChallenge challenge) async {
    final user = _auth.currentUser;
    if (user == null) {
      await signInAnonymously();
    }
    
    try {
      await _db.collection('users')
          .doc(_auth.currentUser!.uid)
          .collection('daily_practices')
          .doc(challenge.id)
          .set(challenge.toFirestore());
    } catch (e) {
      throw Exception('Failed to save daily practice: $e');
    }
  }
  
  static Future<void> saveMeditationSession(MeditationSession session) async {
    final user = _auth.currentUser;
    if (user == null) {
      await signInAnonymously();
    }
    
    try {
      await _db.collection('users')
          .doc(_auth.currentUser!.uid)
          .collection('meditation_sessions')
          .doc(session.id)
          .set(session.toFirestore());
    } catch (e) {
      throw Exception('Failed to save meditation session: $e');
    }
  }
  
  static Future<List<DailyChallenge>> getUserDailyPractices() async {
    final user = _auth.currentUser;
    if (user == null) return [];
    
    try {
      final snapshot = await _db.collection('users')
          .doc(user.uid)
          .collection('daily_practices')
          .orderBy('date', descending: true)
          .limit(30) // Last 30 days
          .get();
      
      return snapshot.docs
          .map((doc) => DailyChallenge.fromFirestore(doc.data(), doc.id))
          .toList();
    } catch (e) {
      throw Exception('Failed to fetch daily practices: $e');
    }
  }
  
  static Future<List<MeditationSession>> getUserMeditationSessions() async {
    final user = _auth.currentUser;
    if (user == null) return [];
    
    try {
      final snapshot = await _db.collection('users')
          .doc(user.uid)
          .collection('meditation_sessions')
          .orderBy('started_at', descending: true)
          .limit(50) // Last 50 sessions
          .get();
      
      return snapshot.docs
          .map((doc) => MeditationSession.fromFirestore(doc.data(), doc.id))
          .toList();
    } catch (e) {
      throw Exception('Failed to fetch meditation sessions: $e');
    }
  }
  
  // ==========================================
  // TRANSLATIONS
  // ==========================================
  
  static Future<Map<String, dynamic>?> getScenarioTranslation(String scenarioId, String langCode) async {
    try {
      final snapshot = await _db.collection('scenarios')
          .doc(scenarioId)
          .collection('translations')
          .doc(langCode)
          .get();
      
      return snapshot.exists ? snapshot.data() : null;
    } catch (e) {
      throw Exception('Failed to fetch scenario translation: $e');
    }
  }
  
  static Future<Map<String, dynamic>?> getVerseTranslation(String verseId, String langCode) async {
    try {
      final snapshot = await _db.collection('gita_verses')
          .doc(verseId)
          .collection('translations')
          .doc(langCode)
          .get();
      
      return snapshot.exists ? snapshot.data() : null;
    } catch (e) {
      throw Exception('Failed to fetch verse translation: $e');
    }
  }
  
  // ==========================================
  // PERFORMANCE METRICS
  // ==========================================
  
  static Future<void> logPerformanceMetric(String operation, int durationMs) async {
    try {
      await _db.collection('performance_metrics').add({
        'operation': operation,
        'duration_ms': durationMs,
        'backend': 'firebase',
        'user_id': _auth.currentUser?.uid,
        'timestamp': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      // Don't throw on performance logging failures
      print('Failed to log performance metric: $e');
    }
  }
  
  // ==========================================
  // HEALTH CHECK
  // ==========================================
  
  static Future<bool> testConnection() async {
    try {
      // Simple test to verify Firebase connection
      await _db.collection('health_check').limit(1).get();
      return true;
    } catch (e) {
      print('Firebase connection test failed: $e');
      return false;
    }
  }
}

// ==========================================
// FIRESTORE EXTENSIONS
// ==========================================

extension ChapterFirestore on Chapter {
  static Chapter fromFirestore(Map<String, dynamic> data, String id) {
    return Chapter(
      id: id,
      chChapterId: data['ch_chapter_id'] ?? 0,
      chTitle: data['ch_title'] ?? '',
      chSummary: data['ch_summary'] ?? '',
      chVerseCount: data['ch_verse_count'] ?? 0,
    );
  }
  
  Map<String, dynamic> toFirestore() {
    return {
      'ch_chapter_id': chChapterId,
      'ch_title': chTitle,
      'ch_summary': chSummary,
      'ch_verse_count': chVerseCount,
      'created_at': FieldValue.serverTimestamp(),
      'updated_at': FieldValue.serverTimestamp(),
    };
  }
}

extension ScenarioFirestore on Scenario {
  static Scenario fromFirestore(Map<String, dynamic> data, String id) {
    return Scenario(
      id: id,
      scTitle: data['sc_title'] ?? '',
      scDescription: data['sc_description'] ?? '',
      scHeartResponse: data['sc_heart_response'] ?? '',
      scDutyResponse: data['sc_duty_response'] ?? '',
      scGitaWisdom: data['sc_gita_wisdom'] ?? '',
      scVerse: data['sc_verse'] ?? '',
      scChapter: data['sc_chapter'] ?? 1,
      scCategory: data['sc_category'] ?? '',
      scTags: List<String>.from(data['sc_tags'] ?? []),
      scActionSteps: List<String>.from(data['sc_action_steps'] ?? []),
    );
  }
  
  Map<String, dynamic> toFirestore() {
    return {
      'sc_title': scTitle,
      'sc_description': scDescription,
      'sc_heart_response': scHeartResponse,
      'sc_duty_response': scDutyResponse,
      'sc_gita_wisdom': scGitaWisdom,
      'sc_verse': scVerse,
      'sc_chapter': scChapter,
      'sc_category': scCategory,
      'sc_tags': scTags,
      'sc_action_steps': scActionSteps,
      'created_at': FieldValue.serverTimestamp(),
      'updated_at': FieldValue.serverTimestamp(),
    };
  }
}

extension VerseFirestore on Verse {
  static Verse fromFirestore(Map<String, dynamic> data, String id) {
    return Verse(
      id: id,
      gvChapterId: data['gv_chapter_id'] ?? 0,
      gvVerseNumber: data['gv_verse_number'] ?? 0,
      gvVerseText: data['gv_verse_text'] ?? '',
      gvMeaning: data['gv_meaning'] ?? '',
      gvCommentary: data['gv_commentary'] ?? '',
    );
  }
  
  Map<String, dynamic> toFirestore() {
    return {
      'gv_chapter_id': gvChapterId,
      'gv_verse_number': gvVerseNumber,
      'gv_verse_text': gvVerseText,
      'gv_meaning': gvMeaning,
      'gv_commentary': gvCommentary,
      'created_at': FieldValue.serverTimestamp(),
      'updated_at': FieldValue.serverTimestamp(),
    };
  }
}

extension JournalEntryFirestore on JournalEntry {
  static JournalEntry fromFirestore(Map<String, dynamic> data, String id) {
    final timestamp = data['created_at'] as Timestamp?;
    final updatedTimestamp = data['updated_at'] as Timestamp?;
    
    return JournalEntry(
      id: id,
      title: data['title'] ?? '',
      content: data['content'] ?? '',
      rating: data['rating'] ?? 0,
      tags: List<String>.from(data['tags'] ?? []),
      scenarioId: data['scenario_id'],
      verseId: data['verse_id'],
      createdAt: timestamp?.toDate() ?? DateTime.now(),
      updatedAt: updatedTimestamp?.toDate() ?? DateTime.now(),
    );
  }
  
  Map<String, dynamic> toFirestore() {
    return {
      'title': title,
      'content': content,
      'rating': rating,
      'tags': tags,
      'scenario_id': scenarioId,
      'verse_id': verseId,
      'created_at': Timestamp.fromDate(createdAt),
      'updated_at': Timestamp.fromDate(updatedAt),
    };
  }
}

extension DailyChallengeFirestore on DailyChallenge {
  static DailyChallenge fromFirestore(Map<String, dynamic> data, String id) {
    final dateTimestamp = data['date'] as Timestamp?;
    final completedTimestamp = data['completed_at'] as Timestamp?;
    
    return DailyChallenge(
      id: id,
      title: data['title'] ?? '',
      description: data['description'] ?? '',
      type: data['type'] ?? 'reflection',
      chapter: data['chapter'] ?? 1,
      verseId: data['verse_id'],
      points: data['points'] ?? 0,
      date: dateTimestamp?.toDate() ?? DateTime.now(),
      isCompleted: data['is_completed'] ?? false,
      completedAt: completedTimestamp?.toDate(),
    );
  }
  
  Map<String, dynamic> toFirestore() {
    return {
      'title': title,
      'description': description,
      'type': type,
      'chapter': chapter,
      'verse_id': verseId,
      'points': points,
      'date': Timestamp.fromDate(date),
      'is_completed': isCompleted,
      'completed_at': completedAt != null ? Timestamp.fromDate(completedAt!) : null,
    };
  }
}

extension MeditationSessionFirestore on MeditationSession {
  static MeditationSession fromFirestore(Map<String, dynamic> data, String id) {
    final startedTimestamp = data['started_at'] as Timestamp?;
    final completedTimestamp = data['completed_at'] as Timestamp?;
    
    return MeditationSession(
      id: id,
      templateId: data['template_id'] ?? '',
      templateName: data['template_name'] ?? '',
      durationMinutes: data['duration_minutes'] ?? 5,
      focusVerseId: data['focus_verse_id'],
      startedAt: startedTimestamp?.toDate() ?? DateTime.now(),
      completedAt: completedTimestamp?.toDate(),
      isCompleted: data['is_completed'] ?? false,
      notes: data['notes'],
    );
  }
  
  Map<String, dynamic> toFirestore() {
    return {
      'template_id': templateId,
      'template_name': templateName,
      'duration_minutes': durationMinutes,
      'focus_verse_id': focusVerseId,
      'started_at': Timestamp.fromDate(startedAt),
      'completed_at': completedAt != null ? Timestamp.fromDate(completedAt!) : null,
      'is_completed': isCompleted,
      'notes': notes,
    };
  }
}