// lib/services/widget_service.dart

import 'dart:convert';
import 'dart:io';
import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/bookmark.dart';
import '../models/verse.dart';

/// Service to manage iOS/Android widget data sharing
/// Shares app data with native widgets through shared preferences
class WidgetService extends ChangeNotifier {
  
  SharedPreferences? _prefs;
  bool _isInitialized = false;
  
  // Debouncing timers to prevent excessive updates
  Timer? _bookmarkUpdateTimer;
  Timer? _progressUpdateTimer;
  static const Duration _debounceDuration = Duration(milliseconds: 500);
  
  // Skip updates during theme transitions to prevent UI hangs
  bool _isThemeTransitioning = false;
  Timer? _themeTransitionTimer;
  
  bool get isInitialized => _isInitialized;
  
  @override
  void dispose() {
    _bookmarkUpdateTimer?.cancel();
    _progressUpdateTimer?.cancel();
    _themeTransitionTimer?.cancel();
    super.dispose();
  }
  
  /// Initialize widget service
  Future<void> initialize() async {
    try {
      _prefs = await SharedPreferences.getInstance();
      _isInitialized = true;
      
      if (kDebugMode) print('✅ WidgetService initialized');
    } catch (e) {
      if (kDebugMode) print('❌ WidgetService initialization failed: $e');
    }
  }
  
  /// Update daily verse for widget display
  Future<void> updateDailyVerse(Verse verse) async {
    if (!_isInitialized || _prefs == null) return;
    
    try {
      final dateKey = _getTodayDateKey();
      final verseData = {
        'chapterNumber': verse.chapterId ?? 1,
        'verseNumber': verse.verseId,
        'sanskrit': '', // Sanskrit not available in our model
        'translation': verse.description,
        'commentary': '', // Commentary not available in our model
        'updatedAt': DateTime.now().toIso8601String(),
      };
      
      await _prefs!.setString('daily_verse_$dateKey', jsonEncode(verseData));
      
      // Also set a general daily verse key
      await _prefs!.setString('daily_verse_current', jsonEncode(verseData));
      
      if (kDebugMode) print('📱 Daily verse updated for widgets: ${verse.reference}');
      
      // Trigger widget refresh on iOS
      if (Platform.isIOS) {
        await _refreshiOSWidgets();
      }
      
    } catch (e) {
      if (kDebugMode) print('❌ Failed to update daily verse for widgets: $e');
    }
  }
  
  /// Notify about theme transition to prevent conflicts
  void setThemeTransitioning(bool transitioning) {
    _isThemeTransitioning = transitioning;
    if (transitioning) {
      // Clear timer when transition starts
      _themeTransitionTimer?.cancel();
      _themeTransitionTimer = Timer(const Duration(milliseconds: 300), () {
        _isThemeTransitioning = false;
      });
    }
  }

  /// Update recent bookmarks for widget display (with debouncing)
  void updateRecentBookmarks(List<Bookmark> bookmarks) {
    if (!_isInitialized || _prefs == null || _isThemeTransitioning) return;
    
    // Cancel previous timer and start a new one
    _bookmarkUpdateTimer?.cancel();
    _bookmarkUpdateTimer = Timer(_debounceDuration, () {
      _performBookmarkUpdate(bookmarks);
    });
  }
  
  /// Perform the actual bookmark update
  Future<void> _performBookmarkUpdate(List<Bookmark> bookmarks) async {
    try {
      final recentBookmarks = bookmarks
          .take(5) // Top 5 recent bookmarks
          .map((bookmark) => {
                'id': bookmark.id,
                'type': bookmark.bookmarkType.toString().split('.').last,
                'title': bookmark.title,
                'preview': bookmark.contentPreview ?? '',
                'chapterNumber': bookmark.chapterId,
                'createdAt': bookmark.createdAt.toIso8601String(),
              })
          .toList();
      
      await _prefs!.setString('recent_bookmarks', jsonEncode(recentBookmarks));
      await _prefs!.setInt('total_bookmarks_count', bookmarks.length);
      
      if (kDebugMode) print('📚 Recent bookmarks updated for widgets: ${recentBookmarks.length} items');
      
      if (Platform.isIOS) {
        await _refreshiOSWidgets();
      }
      
    } catch (e) {
      if (kDebugMode) print('❌ Failed to update bookmarks for widgets: $e');
    }
  }
  
  /// Update reading progress for widget display (with debouncing)
  void updateReadingProgress({
    required int readingStreak,
    required int chaptersCompleted,
    required int totalReadingTime,
    required bool todayProgress,
    List<int>? completedChapterIds,
    List<String>? achievements,
  }) {
    if (!_isInitialized || _prefs == null || _isThemeTransitioning) return;
    
    // Cancel previous timer and start a new one
    _progressUpdateTimer?.cancel();
    _progressUpdateTimer = Timer(_debounceDuration, () {
      _performProgressUpdate(
        readingStreak: readingStreak,
        chaptersCompleted: chaptersCompleted,
        totalReadingTime: totalReadingTime,
        todayProgress: todayProgress,
        completedChapterIds: completedChapterIds,
        achievements: achievements,
      );
    });
  }
  
  /// Perform the actual progress update
  Future<void> _performProgressUpdate({
    required int readingStreak,
    required int chaptersCompleted,
    required int totalReadingTime,
    required bool todayProgress,
    List<int>? completedChapterIds,
    List<String>? achievements,
  }) async {
    try {
      // Individual progress values
      await _prefs!.setInt('reading_streak', readingStreak);
      await _prefs!.setInt('chapters_completed', chaptersCompleted);
      await _prefs!.setInt('total_reading_time', totalReadingTime);
      await _prefs!.setBool('today_progress_${_getTodayDateKey()}', todayProgress);
      
      // Detailed progress data
      final progressData = {
        'readingStreak': readingStreak,
        'chaptersCompleted': chaptersCompleted,
        'totalReadingTime': totalReadingTime,
        'todayProgress': todayProgress,
        'completedChapters': completedChapterIds ?? [],
        'achievements': achievements ?? [],
        'lastUpdated': DateTime.now().toIso8601String(),
        'progressPercentage': ((chaptersCompleted / 18.0) * 100).round(),
      };
      
      await _prefs!.setString('reading_progress_data', jsonEncode(progressData));
      
      if (kDebugMode) {
        print('📈 Reading progress updated for widgets:');
        print('   Streak: $readingStreak days');
        print('   Chapters: $chaptersCompleted/18');
        print('   Time: ${totalReadingTime}m');
        print('   Today: $todayProgress');
      }
      
      if (Platform.isIOS) {
        await _refreshiOSWidgets();
      }
      
    } catch (e) {
      if (kDebugMode) print('❌ Failed to update progress for widgets: $e');
    }
  }
  
  /// Update user achievement for widgets
  Future<void> updateAchievement({
    required String achievementId,
    required String title,
    required String description,
    required DateTime unlockedAt,
  }) async {
    if (!_isInitialized || _prefs == null) return;
    
    try {
      // Get existing achievements
      final existingData = _prefs!.getString('recent_achievements') ?? '[]';
      final List<dynamic> achievements = jsonDecode(existingData);
      
      // Add new achievement
      final newAchievement = {
        'id': achievementId,
        'title': title,
        'description': description,
        'unlockedAt': unlockedAt.toIso8601String(),
      };
      
      achievements.insert(0, newAchievement); // Add to beginning
      
      // Keep only last 5 achievements
      if (achievements.length > 5) {
        achievements.removeRange(5, achievements.length);
      }
      
      await _prefs!.setString('recent_achievements', jsonEncode(achievements));
      
      if (kDebugMode) print('🏆 Achievement updated for widgets: $title');
      
      if (Platform.isIOS) {
        await _refreshiOSWidgets();
      }
      
    } catch (e) {
      if (kDebugMode) print('❌ Failed to update achievement for widgets: $e');
    }
  }
  
  /// Update app usage statistics
  Future<void> updateAppStats({
    required int totalSessions,
    required int totalTimeSpent,
    required DateTime lastOpenedAt,
  }) async {
    if (!_isInitialized || _prefs == null) return;
    
    try {
      final statsData = {
        'totalSessions': totalSessions,
        'totalTimeSpent': totalTimeSpent,
        'lastOpenedAt': lastOpenedAt.toIso8601String(),
        'updatedAt': DateTime.now().toIso8601String(),
      };
      
      await _prefs!.setString('app_statistics', jsonEncode(statsData));
      
      if (kDebugMode) print('📊 App statistics updated for widgets');
      
    } catch (e) {
      if (kDebugMode) print('❌ Failed to update app stats for widgets: $e');
    }
  }
  
  /// Clear all widget data (for logout or app reset)
  Future<void> clearWidgetData() async {
    if (!_isInitialized || _prefs == null) return;
    
    try {
      final keysToRemove = [
        'daily_verse_current',
        'recent_bookmarks',
        'reading_progress_data',
        'recent_achievements',
        'app_statistics',
        'total_bookmarks_count',
        'reading_streak',
        'chapters_completed',
        'total_reading_time',
      ];
      
      for (final key in keysToRemove) {
        await _prefs!.remove(key);
      }
      
      // Remove today's progress key
      await _prefs!.remove('today_progress_${_getTodayDateKey()}');
      
      if (kDebugMode) print('🧹 Widget data cleared');
      
      if (Platform.isIOS) {
        await _refreshiOSWidgets();
      }
      
    } catch (e) {
      if (kDebugMode) print('❌ Failed to clear widget data: $e');
    }
  }
  
  /// Refresh iOS widgets (requires native implementation)
  Future<void> _refreshiOSWidgets() async {
    try {
      // This would typically use a method channel to call native iOS code
      // For now, we just mark that a refresh is needed
      await _prefs!.setInt('widget_refresh_timestamp', DateTime.now().millisecondsSinceEpoch);
      
      if (kDebugMode) print('🔄 iOS widgets refresh requested');
    } catch (e) {
      if (kDebugMode) print('❌ Failed to refresh iOS widgets: $e');
    }
  }
  
  /// Get today's date key for data organization
  String _getTodayDateKey() {
    final now = DateTime.now();
    return '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
  }
  
  /// Get current widget data (for debugging)
  Future<Map<String, dynamic>> getWidgetDebugInfo() async {
    if (!_isInitialized || _prefs == null) return {};
    
    try {
      return {
        'dailyVerse': _prefs!.getString('daily_verse_current'),
        'recentBookmarks': _prefs!.getString('recent_bookmarks'),
        'progressData': _prefs!.getString('reading_progress_data'),
        'readingStreak': _prefs!.getInt('reading_streak'),
        'chaptersCompleted': _prefs!.getInt('chapters_completed'),
        'totalReadingTime': _prefs!.getInt('total_reading_time'),
        'todayProgress': _prefs!.getBool('today_progress_${_getTodayDateKey()}'),
        'lastRefresh': _prefs!.getInt('widget_refresh_timestamp'),
      };
    } catch (e) {
      if (kDebugMode) print('❌ Failed to get widget debug info: $e');
      return {};
    }
  }
  
  /// Force update all widget data (useful for testing)
  Future<void> forceUpdateAllWidgetData({
    Verse? dailyVerse,
    List<Bookmark>? bookmarks,
    required int readingStreak,
    required int chaptersCompleted,
    required int totalReadingTime,
    required bool todayProgress,
  }) async {
    try {
      if (dailyVerse != null) {
        await updateDailyVerse(dailyVerse);
      }
      
      if (bookmarks != null) {
        updateRecentBookmarks(bookmarks);
      }
      
      updateReadingProgress(
        readingStreak: readingStreak,
        chaptersCompleted: chaptersCompleted,
        totalReadingTime: totalReadingTime,
        todayProgress: todayProgress,
      );
      
      if (kDebugMode) print('🔄 Force updated all widget data');
      
    } catch (e) {
      if (kDebugMode) print('❌ Failed to force update widget data: $e');
    }
  }
}