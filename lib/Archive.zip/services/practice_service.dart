// lib/services/practice_service.dart

import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import '../models/daily_practice.dart';
import '../models/verse.dart';
import 'daily_verse_service.dart';

/// Service for managing daily spiritual practices and challenges
class PracticeService extends ChangeNotifier {
  static const String challengesBoxName = 'daily_challenges';
  static const String streaksBoxName = 'practice_streaks';
  static const String routinesBoxName = 'daily_routines';
  
  static final PracticeService _instance = PracticeService._internal();
  static PracticeService get instance => _instance;
  
  PracticeService._internal();
  
  Box<DailyChallenge>? _challengesBox;
  Box<PracticeStreak>? _streaksBox;
  Box<DailyRoutine>? _routinesBox;
  
  bool _isInitialized = false;
  bool get isInitialized => _isInitialized;
  
  // Current active challenges
  List<DailyChallenge> _todaysChallenges = [];
  List<DailyChallenge> get todaysChallenges => _todaysChallenges;
  
  // Practice streaks by type
  Map<PracticeType, PracticeStreak> _streaks = {};
  Map<PracticeType, PracticeStreak> get streaks => _streaks;
  
  // Active routines
  List<DailyRoutine> _activeRoutines = [];
  List<DailyRoutine> get activeRoutines => _activeRoutines;
  
  // Practice statistics
  int get totalPracticePoints => _calculateTotalPoints();
  int get currentOverallStreak => _calculateOverallStreak();
  
  /// Initialize the practice service
  Future<void> initialize() async {
    if (_isInitialized) return;
    
    try {
      // Open Hive boxes
      _challengesBox = await Hive.openBox<DailyChallenge>(challengesBoxName);
      _streaksBox = await Hive.openBox<PracticeStreak>(streaksBoxName);
      _routinesBox = await Hive.openBox<DailyRoutine>(routinesBoxName);
      
      // Load existing data
      await _loadTodaysChallenges();
      await _loadStreaks();
      await _loadRoutines();
      
      // Generate today's challenges if needed
      await _ensureDailyChallengesExist();
      
      // Setup default routines if first time
      if (_routinesBox!.isEmpty) {
        await _createDefaultRoutines();
      }
      
      _isInitialized = true;
      notifyListeners();
      
      debugPrint('✅ PracticeService initialized');
    } catch (e) {
      debugPrint('❌ PracticeService initialization failed: $e');
    }
  }
  
  /// Load today's challenges from storage
  Future<void> _loadTodaysChallenges() async {
    final now = DateTime.now();
    final todayKey = '${now.year}-${now.month}-${now.day}';
    
    _todaysChallenges = _challengesBox!.values
        .where((challenge) {
          final challengeKey = '${challenge.createdAt.year}-${challenge.createdAt.month}-${challenge.createdAt.day}';
          return challengeKey == todayKey;
        })
        .toList();
  }
  
  /// Load practice streaks
  Future<void> _loadStreaks() async {
    _streaks.clear();
    for (final streak in _streaksBox!.values) {
      _streaks[streak.practiceType] = streak;
    }
  }
  
  /// Load active routines
  Future<void> _loadRoutines() async {
    _activeRoutines = _routinesBox!.values
        .where((routine) => routine.isActive)
        .toList();
  }
  
  /// Ensure daily challenges exist for today
  Future<void> _ensureDailyChallengesExist() async {
    if (_todaysChallenges.isEmpty) {
      await _generateDailyChallenges();
    }
  }
  
  /// Generate new daily challenges
  Future<void> _generateDailyChallenges() async {
    final now = DateTime.now();
    final random = Random(now.millisecondsSinceEpoch);
    
    // Get a daily verse for reference
    final dailyVerses = await DailyVerseService.instance.getTodaysVerses();
    final dailyVerse = dailyVerses.isNotEmpty ? dailyVerses.first : null;
    
    final challenges = <DailyChallenge>[];
    
    // Reading challenge
    challenges.add(DailyChallenge(
      id: 'read_${now.millisecondsSinceEpoch}',
      title: 'Morning Scripture Study',
      description: 'Read and reflect on ${2 + random.nextInt(3)} verses from the Bhagavad Gita',
      practiceTypeString: PracticeType.reading.toString().split('.').last,
      targetValue: 2 + random.nextInt(3),
      targetUnit: 'verses',
      createdAt: now,
      rewardPoints: 15,
      verseReference: dailyVerse?.reference,
      iconName: 'book',
    ));
    
    // Meditation challenge
    final meditationMinutes = 5 + (random.nextInt(4) * 5); // 5, 10, 15, or 20 minutes
    challenges.add(DailyChallenge(
      id: 'meditate_${now.millisecondsSinceEpoch}',
      title: 'Mindful Meditation',
      description: 'Practice meditation for $meditationMinutes minutes focusing on inner peace',
      practiceTypeString: PracticeType.meditation.toString().split('.').last,
      targetValue: meditationMinutes,
      targetUnit: 'minutes',
      createdAt: now,
      rewardPoints: 20,
      iconName: 'self_improvement',
    ));
    
    // Reflection challenge
    challenges.add(DailyChallenge(
      id: 'reflect_${now.millisecondsSinceEpoch}',
      title: 'Daily Reflection',
      description: 'Journal about how today\'s verse applies to your life',
      practiceTypeString: PracticeType.reflection.toString().split('.').last,
      targetValue: 1,
      targetUnit: 'entry',
      createdAt: now,
      rewardPoints: 10,
      verseReference: dailyVerse?.reference,
      iconName: 'edit_note',
    ));
    
    // Gratitude challenge
    challenges.add(DailyChallenge(
      id: 'gratitude_${now.millisecondsSinceEpoch}',
      title: 'Gratitude Practice',
      description: 'List 5 things you are grateful for today',
      practiceTypeString: PracticeType.gratitude.toString().split('.').last,
      targetValue: 5,
      targetUnit: 'items',
      createdAt: now,
      rewardPoints: 10,
      iconName: 'favorite',
    ));
    
    // Service challenge (random)
    if (random.nextBool()) {
      challenges.add(DailyChallenge(
        id: 'service_${now.millisecondsSinceEpoch}',
        title: 'Act of Service',
        description: 'Perform one selfless act of kindness today',
        practiceTypeString: PracticeType.service.toString().split('.').last,
        targetValue: 1,
        targetUnit: 'act',
        createdAt: now,
        rewardPoints: 25,
        iconName: 'volunteer_activism',
      ));
    }
    
    // Save challenges
    for (final challenge in challenges) {
      await _challengesBox!.put(challenge.id, challenge);
    }
    
    _todaysChallenges = challenges;
    notifyListeners();
  }
  
  /// Update challenge progress
  Future<void> updateChallengeProgress(String challengeId, int progress) async {
    final index = _todaysChallenges.indexWhere((c) => c.id == challengeId);
    if (index == -1) return;
    
    final challenge = _todaysChallenges[index];
    final updatedChallenge = challenge.copyWith(
      currentProgress: progress,
      isCompleted: progress >= challenge.targetValue,
      completedAt: progress >= challenge.targetValue ? DateTime.now() : null,
    );
    
    await _challengesBox!.put(challengeId, updatedChallenge);
    _todaysChallenges[index] = updatedChallenge;
    
    // Update streak if completed
    if (updatedChallenge.isCompleted && !challenge.isCompleted) {
      await _updateStreak(challenge.practiceType);
    }
    
    notifyListeners();
  }
  
  /// Complete a challenge
  Future<void> completeChallenge(String challengeId) async {
    final challenge = _todaysChallenges.firstWhere(
      (c) => c.id == challengeId,
      orElse: () => throw Exception('Challenge not found'),
    );
    
    await updateChallengeProgress(challengeId, challenge.targetValue);
  }
  
  /// Update practice streak
  Future<void> _updateStreak(PracticeType practiceType) async {
    final existingStreak = _streaks[practiceType];
    final updatedStreak = existingStreak?.updateStreak(
      practiceDate: DateTime.now(),
    ) ?? PracticeStreak(
      practiceTypeString: practiceType.toString().split('.').last,
      currentStreak: 1,
      bestStreak: 1,
      lastPracticeDate: DateTime.now(),
      totalSessions: 1,
    );
    
    await _streaksBox!.put(practiceType.toString(), updatedStreak);
    _streaks[practiceType] = updatedStreak;
    notifyListeners();
  }
  
  /// Create default daily routines
  Future<void> _createDefaultRoutines() async {
    final now = DateTime.now();
    
    // Morning routine
    final morningRoutine = DailyRoutine(
      id: 'morning_routine',
      name: 'Morning Spiritual Practice',
      timeOfDay: 'morning',
      steps: [
        RoutineStep(
          title: 'Gratitude Meditation',
          description: 'Start your day with 5 minutes of gratitude',
          practiceTypeString: PracticeType.gratitude.toString().split('.').last,
          durationMinutes: 5,
        ),
        RoutineStep(
          title: 'Scripture Reading',
          description: 'Read the daily verse and reflect',
          practiceTypeString: PracticeType.reading.toString().split('.').last,
          durationMinutes: 10,
        ),
        RoutineStep(
          title: 'Morning Meditation',
          description: 'Center yourself with peaceful meditation',
          practiceTypeString: PracticeType.meditation.toString().split('.').last,
          durationMinutes: 10,
        ),
      ],
      totalDurationMinutes: 25,
      reminderTimes: ['07:00'],
      createdAt: now,
    );
    
    // Evening routine
    final eveningRoutine = DailyRoutine(
      id: 'evening_routine',
      name: 'Evening Reflection',
      timeOfDay: 'evening',
      steps: [
        RoutineStep(
          title: 'Daily Review',
          description: 'Reflect on your day and lessons learned',
          practiceTypeString: PracticeType.reflection.toString().split('.').last,
          durationMinutes: 10,
        ),
        RoutineStep(
          title: 'Gratitude Journal',
          description: 'Write down 3 things you\'re grateful for',
          practiceTypeString: PracticeType.gratitude.toString().split('.').last,
          durationMinutes: 5,
        ),
        RoutineStep(
          title: 'Peaceful Meditation',
          description: 'End your day with calming meditation',
          practiceTypeString: PracticeType.meditation.toString().split('.').last,
          durationMinutes: 10,
        ),
      ],
      totalDurationMinutes: 25,
      reminderTimes: ['20:00'],
      createdAt: now,
    );
    
    await _routinesBox!.put(morningRoutine.id, morningRoutine);
    await _routinesBox!.put(eveningRoutine.id, eveningRoutine);
    
    _activeRoutines = [morningRoutine, eveningRoutine];
  }
  
  /// Start a daily routine
  Future<DailyRoutine> startRoutine(String routineId) async {
    final routine = _routinesBox!.get(routineId);
    if (routine == null) throw Exception('Routine not found');
    
    // Return the routine to track progress
    return routine;
  }
  
  /// Complete a routine
  Future<void> completeRoutine(String routineId) async {
    final routine = _routinesBox!.get(routineId);
    if (routine == null) return;
    
    final updatedRoutine = routine.markCompleted();
    await _routinesBox!.put(routineId, updatedRoutine);
    
    // Update streaks for all practice types in the routine
    for (final step in routine.steps) {
      await _updateStreak(step.practiceType);
    }
    
    await _loadRoutines();
    notifyListeners();
  }
  
  /// Get practice history for a specific type
  List<DateTime> getPracticeHistory(PracticeType type) {
    return _streaks[type]?.practiceDates ?? [];
  }
  
  /// Calculate total practice points
  int _calculateTotalPoints() {
    int points = 0;
    
    // Points from completed challenges
    for (final challenge in _challengesBox!.values) {
      if (challenge.isCompleted) {
        points += challenge.rewardPoints;
      }
    }
    
    // Bonus points for streaks
    for (final streak in _streaks.values) {
      points += streak.currentStreak * 5;
      if (streak.currentStreak >= 7) points += 50; // Week streak bonus
      if (streak.currentStreak >= 30) points += 200; // Month streak bonus
    }
    
    return points;
  }
  
  /// Calculate overall practice streak
  int _calculateOverallStreak() {
    if (_streaks.isEmpty) return 0;
    
    // Check if any practice was done today
    bool practicedToday = _streaks.values.any((s) => s.isActiveToday);
    if (!practicedToday) return 0;
    
    // Return the minimum streak across all active practices
    return _streaks.values
        .where((s) => s.currentStreak > 0)
        .map((s) => s.currentStreak)
        .fold(999999, (prev, curr) => prev < curr ? prev : curr);
  }
  
  /// Get suggested practices based on user history
  List<String> getSuggestedPractices() {
    final suggestions = <String>[];
    
    // Suggest practices with broken streaks
    for (final type in PracticeType.values) {
      final streak = _streaks[type];
      if (streak == null || !streak.isActiveToday) {
        suggestions.add('Continue your ${type.toString().split('.').last} practice');
      }
    }
    
    // Suggest based on time of day
    final hour = DateTime.now().hour;
    if (hour < 12) {
      suggestions.add('Start your day with morning meditation');
    } else if (hour > 20) {
      suggestions.add('End your day with reflection and gratitude');
    }
    
    return suggestions.take(3).toList();
  }
  
  /// Reset daily challenges (called at midnight or manually)
  Future<void> resetDailyChallenges() async {
    await _generateDailyChallenges();
  }
  
  @override
  void dispose() {
    _challengesBox?.close();
    _streaksBox?.close();
    _routinesBox?.close();
    super.dispose();
  }
}