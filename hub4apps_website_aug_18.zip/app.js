// ===== Hub4Apps Modern JavaScript =====

document.addEventListener('DOMContentLoaded', () => {
  
  // ===== Loading Screen =====
  window.addEventListener('load', () => {
    setTimeout(() => {
      const loadingScreen = document.getElementById('loading-screen');
      if (loadingScreen) {
        loadingScreen.classList.add('hide');
        setTimeout(() => loadingScreen.remove(), 350);
      }
    }, 1500);
  });

  // ===== Navigation =====
  const navbar = document.getElementById('navbar');
  const navToggle = document.getElementById('nav-toggle');
  const navMenu = document.getElementById('nav-menu');
  const navLinks = document.querySelectorAll('.nav-link');

  // Sticky navbar on scroll
  let lastScroll = 0;
  window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;
    
    if (currentScroll > 10) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
    
    lastScroll = currentScroll;
  });

  // Mobile menu toggle
  navToggle?.addEventListener('click', () => {
    navMenu.classList.toggle('active');
    navToggle.setAttribute('aria-expanded', 
      navMenu.classList.contains('active'));
  });

  // Close mobile menu on link click
  navLinks.forEach(link => {
    link.addEventListener('click', () => {
      navMenu.classList.remove('active');
      navToggle?.setAttribute('aria-expanded', 'false');
    });
  });

  // Smooth scroll for anchor links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      const targetId = this.getAttribute('href');
      if (targetId === '#') return;
      
      const targetElement = document.querySelector(targetId);
      if (targetElement) {
        e.preventDefault();
        const offset = navbar.offsetHeight + 20;
        const targetPosition = targetElement.offsetTop - offset;
        
        window.scrollTo({
          top: targetPosition,
          behavior: 'smooth'
        });
      }
    });
  });

  // ===== Hero Animations =====
  
  // Animated counter for stats
  const animateValue = (element, start, end, duration) => {
    const range = end - start;
    const startTime = performance.now();
    
    const step = (currentTime) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      const current = Math.floor(progress * range + start);
      element.textContent = current.toLocaleString();
      
      if (progress < 1) {
        requestAnimationFrame(step);
      } else {
        element.textContent = end.toLocaleString();
      }
    };
    
    requestAnimationFrame(step);
  };

  // Trigger stat animations when in view
  const observerOptions = {
    threshold: 0.5,
    rootMargin: '0px'
  };

  const statsObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting && !entry.target.classList.contains('animated')) {
        const statNumbers = entry.target.querySelectorAll('.stat-number[data-count]');
        statNumbers.forEach(stat => {
          const endValue = parseInt(stat.dataset.count);
          animateValue(stat, 0, endValue, 2000);
        });
        entry.target.classList.add('animated');
      }
    });
  }, observerOptions);

  const heroStats = document.querySelector('.hero-stats');
  if (heroStats) {
    statsObserver.observe(heroStats);
  }

  // ===== App Preview Carousel =====
  const appPreviews = [
    {
      title: 'Gita Wisdom',
      icon: 'om',
      color: '#2da0ad',
      content: `
        <div style="text-align: center; padding: 20px;">
          <i class="fas fa-om" style="font-size: 48px; color: #2da0ad; margin-bottom: 16px;"></i>
          <h4 style="margin-bottom: 12px;">Daily Verse</h4>
          <p style="font-style: italic; color: #6b7280; font-size: 14px;">
            "You have the right to work, but never to the fruit of work."
          </p>
          <span style="font-size: 12px; color: #9ca3af;">- Bhagavad Gita 2.47</span>
        </div>
      `
    },
    {
      title: 'Gospel Wisdom',
      icon: 'cross',
      color: '#f59e0b',
      content: `
        <div style="text-align: center; padding: 20px;">
          <i class="fas fa-cross" style="font-size: 48px; color: #f59e0b; margin-bottom: 16px;"></i>
          <h4 style="margin-bottom: 12px;">Family Devotion</h4>
          <p style="font-style: italic; color: #6b7280; font-size: 14px;">
            "Love one another as I have loved you."
          </p>
          <span style="font-size: 12px; color: #9ca3af;">- John 15:12</span>
        </div>
      `
    },
    {
      title: 'Schoolerz',
      icon: 'graduation-cap',
      color: '#10b981',
      content: `
        <div style="text-align: center; padding: 20px;">
          <i class="fas fa-graduation-cap" style="font-size: 48px; color: #10b981; margin-bottom: 16px;"></i>
          <h4 style="margin-bottom: 12px;">Find Help</h4>
          <div style="display: flex; justify-content: center; gap: 8px; margin-top: 16px;">
            <span style="padding: 4px 8px; background: rgba(16, 185, 129, 0.1); border-radius: 12px; font-size: 12px;">Tutoring</span>
            <span style="padding: 4px 8px; background: rgba(16, 185, 129, 0.1); border-radius: 12px; font-size: 12px;">Babysitting</span>
          </div>
        </div>
      `
    },
    {
      title: 'Family Color Fun',
      icon: 'palette',
      color: '#8b5cf6',
      content: `
        <div style="text-align: center; padding: 20px;">
          <i class="fas fa-palette" style="font-size: 48px; color: #8b5cf6; margin-bottom: 16px;"></i>
          <h4 style="margin-bottom: 12px;">Create Together</h4>
          <div style="display: flex; justify-content: center; gap: 8px; margin-top: 16px;">
            <div style="width: 24px; height: 24px; background: #ef4444; border-radius: 50%;"></div>
            <div style="width: 24px; height: 24px; background: #3b82f6; border-radius: 50%;"></div>
            <div style="width: 24px; height: 24px; background: #eab308; border-radius: 50%;"></div>
            <div style="width: 24px; height: 24px; background: #10b981; border-radius: 50%;"></div>
          </div>
        </div>
      `
    }
  ];

  let currentPreviewIndex = 0;
  const appPreviewElement = document.getElementById('app-preview');
  
  const updatePreview = () => {
    if (!appPreviewElement) return;
    
    appPreviewElement.style.opacity = '0';
    setTimeout(() => {
      appPreviewElement.innerHTML = appPreviews[currentPreviewIndex].content;
      appPreviewElement.style.opacity = '1';
      currentPreviewIndex = (currentPreviewIndex + 1) % appPreviews.length;
    }, 300);
  };

  if (appPreviewElement) {
    appPreviewElement.style.transition = 'opacity 0.3s ease';
    updatePreview();
    setInterval(updatePreview, 3000);
  }

  // ===== Scroll Animations =====
  const animateOnScroll = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.animationPlayState = 'running';
        animateOnScroll.unobserve(entry.target);
      }
    });
  }, {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
  });

  // Observe all animated elements
  document.querySelectorAll('.animate-fade-up, .animate-fade-left, .animate-fade-right, .animate-scale').forEach(el => {
    el.style.animationPlayState = 'paused';
    animateOnScroll.observe(el);
  });

  // ===== App Card Interactions =====
  const appCards = document.querySelectorAll('.app-card');
  
  appCards.forEach(card => {
    card.addEventListener('mouseenter', function() {
      this.style.transform = 'translateY(-5px)';
    });
    
    card.addEventListener('mouseleave', function() {
      this.style.transform = 'translateY(0)';
    });
  });

  // ===== Modal Functions =====
  window.showWaitlist = (appName) => {
    const modalContainer = document.getElementById('modal-container');
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.innerHTML = `
      <div class="modal-backdrop" onclick="closeModal()"></div>
      <div class="modal-content glass-morph animate-scale">
        <button class="modal-close" onclick="closeModal()">
          <i class="fas fa-times"></i>
        </button>
        <h3>Join the ${appName === 'gospel' ? 'Gospel Wisdom' : appName} Waitlist</h3>
        <p>Be the first to know when we launch!</p>
        <form class="modal-form" onsubmit="handleWaitlistSubmit(event)">
          <input type="email" placeholder="your@email.com" required>
          <button type="submit" class="btn btn-primary">
            Join Waitlist
            <i class="fas fa-arrow-right"></i>
          </button>
        </form>
      </div>
    `;
    modalContainer.appendChild(modal);
    document.body.style.overflow = 'hidden';
  };

  window.showBetaSignup = () => {
    const modalContainer = document.getElementById('modal-container');
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.innerHTML = `
      <div class="modal-backdrop" onclick="closeModal()"></div>
      <div class="modal-content glass-morph animate-scale">
        <button class="modal-close" onclick="closeModal()">
          <i class="fas fa-times"></i>
        </button>
        <h3>Join Schoolerz Beta</h3>
        <p>Help us test and improve the platform!</p>
        <form class="modal-form" onsubmit="handleBetaSubmit(event)">
          <input type="text" placeholder="Your name" required>
          <input type="email" placeholder="your@email.com" required>
          <select required>
            <option value="">I am a...</option>
            <option value="parent">Parent</option>
            <option value="teen">Teen (13-18)</option>
            <option value="both">Both</option>
          </select>
          <button type="submit" class="btn btn-primary">
            Join Beta Program
            <i class="fas fa-rocket"></i>
          </button>
        </form>
      </div>
    `;
    modalContainer.appendChild(modal);
    document.body.style.overflow = 'hidden';
  };

  window.showProgress = () => {
    alert('Development progress details coming soon!');
  };

  window.showPrivacy = () => {
    window.open('/privacy', '_blank');
  };

  window.showTerms = () => {
    window.open('/terms', '_blank');
  };

  window.closeModal = () => {
    const modal = document.querySelector('.modal');
    if (modal) {
      modal.remove();
      document.body.style.overflow = '';
    }
  };

  window.handleWaitlistSubmit = (e) => {
    e.preventDefault();
    alert('Thank you for joining our waitlist! We\'ll notify you when the app launches.');
    closeModal();
  };

  window.handleBetaSubmit = (e) => {
    e.preventDefault();
    alert('Welcome to the Schoolerz Beta! Check your email for next steps.');
    closeModal();
  };

  // ===== Newsletter Form =====
  const newsletterForm = document.getElementById('newsletter-form');
  if (newsletterForm) {
    newsletterForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const email = e.target.querySelector('input[type="email"]').value;
      alert(`Thank you for subscribing with ${email}! Stay tuned for updates.`);
      e.target.reset();
    });
  }

  // ===== Progress Bar Animation =====
  const progressObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const progressFill = entry.target.querySelector('.progress-fill');
        if (progressFill) {
          const width = progressFill.style.width;
          progressFill.style.width = '0';
          setTimeout(() => {
            progressFill.style.width = width;
          }, 100);
        }
      }
    });
  }, { threshold: 0.5 });

  document.querySelectorAll('.app-progress').forEach(progress => {
    progressObserver.observe(progress);
  });

  // ===== Add Modal Styles =====
  const style = document.createElement('style');
  style.textContent = `
    .modal {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      z-index: 9999;
      display: flex;
      align-items: center;
      justify-content: center;
      animation: fadeIn 0.3s ease-out;
    }
    
    .modal-backdrop {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.5);
      backdrop-filter: blur(5px);
    }
    
    .modal-content {
      position: relative;
      background: white;
      padding: 2rem;
      border-radius: 1rem;
      max-width: 400px;
      width: 90%;
      max-height: 90vh;
      overflow-y: auto;
    }
    
    .modal-close {
      position: absolute;
      top: 1rem;
      right: 1rem;
      background: none;
      border: none;
      font-size: 1.5rem;
      cursor: pointer;
      color: var(--gray-500);
      transition: color 0.2s;
    }
    
    .modal-close:hover {
      color: var(--gray-700);
    }
    
    .modal-content h3 {
      margin-bottom: 0.5rem;
      color: var(--gray-900);
    }
    
    .modal-content p {
      margin-bottom: 1.5rem;
      color: var(--gray-600);
    }
    
    .modal-form {
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }
    
    .modal-form input,
    .modal-form select {
      padding: 0.75rem;
      border: 1px solid var(--gray-300);
      border-radius: 0.5rem;
      font-size: 1rem;
    }
    
    .modal-form input:focus,
    .modal-form select:focus {
      outline: none;
      border-color: var(--primary);
      box-shadow: 0 0 0 3px rgba(var(--primary-hue), 65%, 45%, 0.1);
    }
    
    @keyframes fadeIn {
      from {
        opacity: 0;
      }
      to {
        opacity: 1;
      }
    }
  `;
  document.head.appendChild(style);

  // ===== Floating Icons Orbits =====
  const floatingIcons = document.querySelectorAll('.floating-icon');
  floatingIcons.forEach((icon, index) => {
    icon.style.setProperty('--delay', `${index * 2.5}s`);
  });

  // ===== Performance Monitoring =====
  if ('performance' in window && 'PerformanceObserver' in window) {
    try {
      const perfObserver = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          if (entry.entryType === 'largest-contentful-paint') {
            console.log('LCP:', entry.renderTime || entry.loadTime);
          }
        }
      });
      perfObserver.observe({ entryTypes: ['largest-contentful-paint'] });
    } catch (e) {
      // PerformanceObserver not supported
    }
  }

  console.log('Hub4Apps Modern Site Initialized ✨');
});